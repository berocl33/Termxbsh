


# This class handles communications with a client.

import threading#,XExtensions;
from XIo import InputOutput 
from XUtil import *
import time

# @author Matthew Kwan
# This class handles communications with a client.
#

Destroy = 0;
RetainPermanent = 1;
RetainTemporary = 2;
class Client(threading.Thread):
	def __init__(self,xServer=null,xSocket=null,resourceIdBase=1<<20,resourceIdMask=0,xResources=null,xInputOutput=null):
		self._inputOutput=xInputOutput if(xInputOutput) else InputOutput(xSocket)
		self._closeConnection = false
		self._isConnected = true;
		self._closeDownMode = Destroy;
		self._imperviousToServerGrabs = false;
		threading.Thread.__init__(self,target=self._run,args=())
		self._formats=[(2,1,0),]
		self._releaseNumber=0
		self._protocolMajorVersion=11
		self._protocolMinorVersion=0
		self._vendor="pyco"
		self._resourceIdBase = int(resourceIdBase)
		self._resourceIdMask = int(resourceIdMask)
		self._resources=Vector(xResources);
		#self.newClient(xServer,xSocket,resourceIdBase,resourceIdMask,xResources)
	def getVendor(self,xserver=None):
		if(not xserver):
		   if(not hasattr(self,"_xServer")):
		      return self._vendor;
		   else:
		      xserver=self._xServer
		return xserver.vendor


	def newClient(self,xserver, socket, resourceIdBase=1<<20, resourceIdMask=0,xResources=None):# throws IOException {
		self._xServer = xserver;
		self._inputOutput = self.getInputOutput() if(not socket) else InputOutput(socket); 
		self._resourceIdBase = resourceIdBase;
		self._resourceIdMask = resourceIdMask;
		self._resources = Vector(xResources);
		self._sequenceNumber = 0;
	
	def getCloseDownMode (self): 
		return( self._closeDownMode);
	

	def getInputOutput (self): 
		return( self._inputOutput);

	def writeFormats(self,io=None,screen=None):
		if(not io):
		    io= self.getInputOutput()

		if(not screen):
		    if(not hasattr(self,"_xServer")):
		       screen=getattr(self,"_screen",self)
		    else:
		       screen=self._xServer.getScreen()
		    #endif
		#endif
		for a in range(len(screen._formats)):
		   for b in range(3):
		      io.writeByte(self._formats[a][b])
		   #endfor
		   io.writePadBytes(5);
		#endfor
	
	def getNumFormats(self,xserver=null):
		if(not xserver):
		    xserver=self._xServer
		#endif
		if(not self._formats):
		    return 0
		#endif
		return len(self._formats)

	def getSequenceNumber (self): 
		return( self._sequenceNumber);

	def getScreen(self,xserver=None):
		if(not xserver):
			if(not hasattr(self,"_xServer")):
			    print("clientNoScreen");return(self)
		        else:
			    xserver=self._xServer
			#endif
		#endif
		return xserver.getScreen()

	def isConnected (self): 
		return( self._isConnected);
	

	def getImperviousToServerGrabs (self): 
		return( self._imperviousToServerGrabs);
	

	def setImperviousToServerGrabs (self,impervious): 
		self._imperviousToServerGrabs = impervious;
	

	def addResource (self,rid,r): 
		self._resources.add (hash(self),rid,r);
	

	def freeResource (self,r): 
		self._resources.remove (r);
	

	def _run (self): 
		try: 
			self.doComms ();
		except (Exception): 
			raise(Exception,"clientComm");
		#endif
		#synchronized (_xServer) {
		self.close ();
		#}
	

	def cancel (self,): 
		self._closeConnection = true;
		self.close ();
	

	def close (self): 
		if (not self._isConnected):
			return()
		#endif
		self._isConnected = false;

		#try: 
		self.getInputOutput().close ();
		self._socket.close ();
		#except (Exception ): 
		#	print(sys.exc_info())

		# Clear the resources associated with self client.
		if (self._closeDownMode == Destroy):
			for r in self._resources:
				if(hasattr(self._resources,"delete")):
					r.delete ();
			#endfor	
		#endif
		self._resources.clear ();
		self._xServer.removeClient(self);
	

	def doComms (self):# throws IOException {
		# Read the connection setup.
		byteOrder = self.getInputOutput().readByte ();

		if (byteOrder == 0x42):
			self.getInputOutput().setMSB (true);
		elif (byteOrder == 0x6c):
			self.getInputOutput().setMSB (false);
		else:
			print("readClientHeader");raise(Exception)
		#endiF
		self.getInputOutput().readByte ();	# Unused.
		self.getInputOutput().readShort ();	# Protocol major version.
		self.getInputOutput().readShort ();	# Protocol minor version.

		nameLength = self.getInputOutput().readShort ();
		dataLength = self.getInputOutput().readShort ();

		self.getInputOutput().readShort ();	# Unused.

		if (nameLength > 0): 
			self.getInputOutput().readSkip (nameLength);	# Authorization protocol name.
			self.getInputOutput().readSkip (-nameLength & 3);	# Padding.
		#endiD

		if (dataLength > 0):
			self.getInputOutput().readSkip (dataLength);	# Authorization protocol data.
			self.getInputOutput().readSkip (-dataLength & 3);	# Padding.
		#endiF

		vend=self.getVendor();
		pad = -len(vend) & 3;
		extra = int(26 + 2 * self.getNumFormats () + (len(vend) + pad) / 4);
		kb = self.getKeyboard ();

		#synchronized (self.getInputOutput()) {
		self.getInputOutput().writeByte (1);		# Success.
		self.getInputOutput().writeByte (0);		# Unused.
		self.getInputOutput().writeShort (self._protocolMajorVersion);
		self.getInputOutput().writeShort (self._protocolMinorVersion);
		self.getInputOutput().writeShort ( extra);	# Length of data.
		self.getInputOutput().writeInt (self._releaseNumber);	# Release number.
		self.getInputOutput().writeInt (self._resourceIdBase);
		self.getInputOutput().writeInt (self._resourceIdMask);
		self.getInputOutput().writeInt (0);		# Motion buffer size.
		self.getInputOutput().writeShort (len(vend));	# Vendor length.
		self.getInputOutput().writeShort ( 0x7fff);	# Max request length.
		self.getInputOutput().writeByte (1);	# Number of screens.
		self.getInputOutput().writeByte (self.getNumFormats ());
		self.getInputOutput().writeByte (0);	# Image byte order (0=LSB, 1=MSB).
		self.getInputOutput().writeByte (1);	# Bitmap bit order (0=LSB, 1=MSB).
		self.getInputOutput().writeByte (8);	# Bitmap format scanline unit.
		self.getInputOutput().writeByte (8);	# Bitmap format scanline pad.
		self.getInputOutput().writeByte (kb.getMinimumKeycode ());
		self.getInputOutput().writeByte (kb.getMaximumKeycode ());
		self.getInputOutput().writePadBytes(4);#padBytes# Unused.

		if (len(vend) > 0): # Write padded vendor string.
			self.getInputOutput().writeBytes (bytes(vend.encode("UTF-8")), 0, len(vend));
			self.getInputOutput().writePadBytes(pad);
		#endiF

		self.writeFormats (self.getInputOutput());
		self.getScreen().write (self.getInputOutput());
		#}
		self.getInputOutput().flush ();
		while (not self._closeConnection):
			#endiF

			# Deal with server grabs.
			#while (not self._xServer.processingAllowed (self)): 
			#	time.sleep(3)
			#endwhilE
			#SynchroniZed (self._xServer) {
			self.processRequest();
			self.processOper();#opcode, arg, self._bytesRemaining);
			#}

		#endwhilR

	def getKeyboard(self,periph=null):
	    if(not self._xServer):
	       kb=getattr(self,"_kb",periph._kb)
	    else:
	       kb=self._xServer.getKeyboard()

	    return(kb)
	def sendMappingNotify(self,client,request,firstKey,keyCount,io=None):
	    if(not io):
	       io=self.getInputOutput()

	    writeReplyHeader(io,MappingNotify,0)
	    io.writeByte(request)
	    io.writeByte(firstKey)
	    io.writeByte(keyCount)
	    io.writePadBytes(25)

	def validResourceId (self,id): 
		return( ((id & ~self._resourceIdMask)) == self._resourceIdBase and not self.resourceExists (id));


	def resourceExists(self,id,host=null,owner=null):
	    return True;

	def processRequest(self,sequenceNumber=None):
		self._opcode = int(self.getInputOutput().readByte());
		self._arg = int(self.getInputOutput().readByte());
		self._requestLength = self.getInputOutput().readShort ();
		self._bytesRemaining=int(0);

		if (self._requestLength == 0):	# Handle big requests.
			self._requestLength = self.getInputOutput().readInt ();
			if (self._requestLength > 2):
				self._bytesRemaining = self._requestLength * 4 - 8;
			else:
				self._bytesRemaining = 0;
			#endiF
		else: 
			self._bytesRemaining = self._requestLength * 4 - 4;

	def processOper(self,opcode=None,arg=None,bytesRemaining=None):# throws IOException {
		if not hasattr(self,"_sequenceNumber"):
			self._sequenceNumber=0
		if not opcode:
			if( hasattr(self,"_opcode") ):
				opcode=self._opcode;
			else:
				print("raise(Exception)notOpCodeInClient");raise()
		if not arg:
			if( hasattr(self,"_arg") ):
				arg=self._arg;
			else:
				print("raise(Exception)notArgInClient");raise()
		if not bytesRemaining:
			if( hasattr(self,"_bytesRemaining") ):
				bytesRemaining=self._bytesRemaining
			else:
				print("raise(Exception)notBytesRemInClient");raise()

		self._sequenceNumber+=1;
		if (opcode == RequestCode.CreateWindow):
			if (bytesRemaining < 28): 
				self.getInputOutput().readSkip (bytesRemaining);
				Err_write (self, ErrorCode.Length, opcode, 0);
			else: 
				id = self.getInputOutput().readInt ();	# Window ID.
				parent = self.getInputOutput().readInt ();	# Parent.
				r = self._xServer.getResource (parent);

				bytesRemaining -= 8;
				if (not self.validResourceId (id)): 
						self.getInputOutput().readSkip (bytesRemaining);
						Err_write (self, ErrorCode.IDChoice, opcode, id);
				elif (r == null or r.getType () != Resource.WINDOW): 
						self.getInputOutput().readSkip (bytesRemaining);
						Err_write (self, ErrorCode.Window, opcode, parent);
				else: 
					w = Window(r);
					w.processCreateWindowRequest (self.getInputOutput(), self, self._sequenceNumber, id, arg, bytesRemaining);
				#endiF
			#endiF
		elif(opcode in (RequestCode.ChangeWindowAttributes, RequestCode.GetWindowAttributes, RequestCode.DestroyWindow, RequestCode.DestroySubwindows, RequestCode.ChangeSaveSet, RequestCode.ReparentWindow, RequestCode.MapWindow, RequestCode.MapSubwindows, RequestCode.UnmapWindow, RequestCode.UnmapSubwindows, RequestCode.ConfigureWindow, RequestCode.CirculateWindow, RequestCode.QueryTree, RequestCode.ChangeProperty, RequestCode.DeleteProperty, RequestCode.GetProperty, RequestCode.ListProperties, RequestCode.QueryPointer, RequestCode.GetMotionEvents, RequestCode.TranslateCoordinates, RequestCode.ClearArea, RequestCode.ListInstalledColormaps, RequestCode.RotateProperties)):
				if (bytesRemaining < 4): 
					Err_write (self, ErrorCode.Length, opcode, 0);
				else: 
					id = self.getInputOutput().readInt ();
					r = self._xServer.getResource (id);

					bytesRemaining -= 4;
					if (r == null or r.getType () != Resource.WINDOW): 
						self.getInputOutput().readSkip (bytesRemaining);
						Err_write (self, ErrorCode.Window, opcode, id);
					else: 
						r.processRequest (self, opcode, arg, bytesRemaining);
					#endiF
			#endif
		elif (opcode in (RequestCode.GetGeometry, RequestCode.CopyArea, RequestCode.CopyPlane, RequestCode.PolyPoint, RequestCode.PolyLine, RequestCode.PolySegment, RequestCode.PolyRectangle, RequestCode.PolyArc, RequestCode.FillPoly, RequestCode.PolyFillRectangle, RequestCode.PolyFillArc, RequestCode.PutImage, RequestCode.GetImage, RequestCode.PolyText8, RequestCode.PolyText16, RequestCode.ImageText8, RequestCode.ImageText16, RequestCode.QueryBestSize)):
			if (bytesRemaining < 4): 
				Err_write (self, ErrorCode.Length, opcode, 0);
			else: 
				id = self.getInputOutput().readInt ();
				r = self._xServer.getResource (id);
				bytesRemaining -= 4;
				if (r == null or not r.isDrawable ()): 
					self.getInputOutput().readSkip (bytesRemaining);
					Err_write (self, ErrorCode.Drawable, opcode, id);
				else: 
					r.processRequest (self, opcode, arg, bytesRemaining);
				#endiF
			#endiF
		elif(opcode == RequestCode.InternAtom):
			Atom.processInternAtomRequest (self._xServer, self, arg, bytesRemaining);
		elif(opcode == RequestCode.GetAtomName):
			Atom.processGetAtomNameRequest (self._xServer, self, bytesRemaining);
			
		elif(opcode in ( RequestCode.GetSelectionOwner, RequestCode.SetSelectionOwner, RequestCode.ConvertSelection)):
			Selection.processRequest (self._xServer, self, opcode, bytesRemaining);
				
		elif(opcode in ( RequestCode.SendEvent, RequestCode.GrabPointer, RequestCode.UngrabPointer, RequestCode.GrabButton, RequestCode.UngrabButton, RequestCode.ChangeActivePointerGrab, RequestCode.GrabKeyboard, RequestCode.UngrabKeyboard, RequestCode.GrabKey, RequestCode.UngrabKey, RequestCode.AllowEvents, RequestCode.SetInputFocus, RequestCode.GetInputFocus)):
			self._xServer.getScreen().processRequest (self._xServer, self, opcode, arg, bytesRemaining);
				
		elif(opcode == RequestCode.GrabServer):
			if (bytesRemaining != 0): 
				self.getInputOutput().readSkip (bytesRemaining);
				Err_write (self, ErrorCode.Length, opcode, 0);
			else: 
				self._xServer.grabServer (self);
			#endiF
		elif(opcode == RequestCode.UngrabServer):
			if (bytesRemaining != 0): 
				self.getInputOutput().readSkip (bytesRemaining);
				Err_write (self, ErrorCode.Length, opcode, 0);
			else: 
				self._xServer.ungrabServer (self);
			#endiF
		elif(opcode in ( RequestCode.WarpPointer, RequestCode.ChangePointerControl, RequestCode.GetPointerControl, RequestCode.SetPointerMapping, RequestCode.GetPointerMapping)):
			self._xServer.getPointer().processRequest (self._xServer, self, opcode, arg, bytesRemaining);
				
		elif(opcode == RequestCode.OpenFont):
			if (bytesRemaining < 8): 
				self.getInputOutput().readSkip (bytesRemaining);
				Err_write (self, ErrorCode.Length, opcode, 0);
			else: 
				id = self.getInputOutput().readInt ();	# Font ID.

				bytesRemaining -= 4;
				if (not validResourceId (id)): 
					self.getInputOutput().readSkip (bytesRemaining);
					Err_write (self, ErrorCode.IDChoice, opcode, id);
				else:  
					Font.processOpenFontRequest (self._xServer, self, id, bytesRemaining);
				#endiF
			#endiF
				
		elif(opcode == RequestCode.CloseFont):
			if (bytesRemaining != 4): 
				self.getInputOutput().readSkip (bytesRemaining);
				Err_write (self, ErrorCode.Length, opcode, 0);
			else: 
				id = self.getInputOutput().readInt ();
				r = self._xServer.getResource (id);

				bytesRemaining -= 4;
				if (r == null or r.getType () != Resource.FONT):
					Err_write (self, ErrorCode.Font, opcode, id);
				else:
					r.processRequest (self, opcode, arg, bytesRemaining);
				#endiF
			#endiF
				
		elif(opcode in ( RequestCode.QueryFont, RequestCode.QueryTextExtents)):
			if (bytesRemaining != 4): 
				self.getInputOutput().readSkip (bytesRemaining);
				Err_write (self, ErrorCode.Length, opcode, 0);
			else: 
				id = self.getInputOutput().readInt ();
				r = self._xServer.getResource (id);

				bytesRemaining -= 4;
				if (r == null or not r.isFontable ()): 
					self.getInputOutput().readSkip (bytesRemaining);
					Err_write (self, ErrorCode.Font, opcode, id);
				else: 
					r.processRequest (self, opcode, arg, bytesRemaining);
				#endiF
			#endiF
		elif(opcode in ( RequestCode.ListFonts, RequestCode.ListFontsWithInfo)):
			Font.processListFonts (self, opcode, bytesRemaining);
			
		elif(opcode == RequestCode.SetFontPath):
			Font.processSetFontPath (self._xServer, self, bytesRemaining);
		elif(opcode == RequestCode.GetFontPath):
			if (bytesRemaining != 0): 
				self.getInputOutput().readSkip (bytesRemaining);
				Err_write (self, ErrorCode.Length, opcode, 0);
			else: 
				Font.processGetFontPath (self._xServer, self);
			#endiF
				
		elif(opcode == RequestCode.CreatePixmap):
			if (bytesRemaining != 12): 
				self.getInputOutput().readSkip (bytesRemaining);
				Err_write (self, ErrorCode.Length, opcode, 0);
			else: 
				id = self.getInputOutput().readInt ();	# Pixmap ID.
				did = self.getInputOutput().readInt ();	# Drawable ID.
				width = self.getInputOutput().readShort ();	# Width.
				height = self.getInputOutput().readShort ();	# Height.
				r = self._xServer.getResource (did);

				if (not validResourceId (id)): 
					Err_write (self, ErrorCode.IDChoice, opcode, id);
				elif (r == null or not r.isDrawable ()): 
					Err_write (self, ErrorCode.Drawable, opcode,did);
				else:
					try:
						Pixmap.processCreatePixmapRequest (self._xServer, self, id, width, height, arg, r);
					except (OutOfMemoryError): 
						Err_write (self, ErrorCode.Alloc, opcode, 0);
					#endexc
				#endiF
			#endiF

		elif(opcode == RequestCode.FreePixmap):
			if (bytesRemaining != 4): 
				self.getInputOutput().readSkip (bytesRemaining);
				Err_write (self, ErrorCode.Length, opcode, 0);
			else: 
				id = self.getInputOutput().readInt ();
				r = self._xServer.getResource (id);

				bytesRemaining -= 4;
				if (r == null or r.getType () != Resource.PIXMAP):
					Err_write (self, ErrorCode.Pixmap, opcode, id);
				else:
					r.processRequest (self, opcode, arg, bytesRemaining);
				#Endif
			#endiF

		elif(opcode == RequestCode.CreateGC):
			if (bytesRemaining < 12): 
				self.getInputOutput().readSkip (bytesRemaining);
				Err_write (self, ErrorCode.Length, opcode, 0);
			else: 
				id = self.getInputOutput().readInt ();	# GContext ID.
				d = self.getInputOutput().readInt ();	# Drawable ID.
				r = self._xServer.getResource (d);

				bytesRemaining -= 8;
				if (not validResourceId (id)): 
					self.getInputOutput().readSkip (bytesRemaining);
					Err_write (self, ErrorCode.IDChoice, opcode, id);
				elif (r == null or not r.isDrawable ()): 
					self.getInputOutput().readSkip (bytesRemaining);
					Err_write (self, ErrorCode.Drawable, opcode, d);
				else: 
					GContext.processCreateGCRequest (self._xServer, self, id, bytesRemaining);
				#endiF
			#endiF
			
		elif(opcode in ( RequestCode.ChangeGC, RequestCode.CopyGC, RequestCode.SetDashes, RequestCode.SetClipRectangles, RequestCode.FreeGC)):
			if (bytesRemaining < 4): 
				Err_write (self, ErrorCode.Length, opcode, 0);
			else: 
				id = self.getInputOutput().readInt ();
				r = self._xServer.getResource (id);

				bytesRemaining -= 4;
				if (r == null or r.getType () != Resource.GCONTEXT): 
					self.getInputOutput().readSkip (bytesRemaining);
					Err_write (self, ErrorCode.GContext, opcode, id);
				else:
					r.processRequest (self, opcode, arg, bytesRemaining);
				#endiF
			#endiF
			
		elif(opcode == RequestCode.CreateColormap):
			if (bytesRemaining != 12): 
				self.getInputOutput().readSkip (bytesRemaining);
				Err_write (self, ErrorCode.Length, opcode, 0);
			else: 
				id = self.getInputOutput().readInt ();	# Colormap ID.

				bytesRemaining -= 4;
				if (not validResourceId (id)): 
					self.getInputOutput().readSkip (bytesRemaining);
					Err_write (self, ErrorCode.IDChoice, opcode, id);
				else: 
					Colormap.processCreateColormapRequest (self._xServer, self, id, arg);
				#endiF
			#endiF
		elif(opcode == RequestCode.CopyColormapAndFree):
			if (bytesRemaining != 8): 
				Err_write (self, ErrorCode.Length, opcode, 0);
			else: 
				id1 = self.getInputOutput().readInt ();
				id2 = self.getInputOutput().readInt ();
				r = self._xServer.getResource (id2);

				if (r == null or r.getType () != Resource.COLORMAP):
					Err_write (self, ErrorCode.Colormap, opcode, id2);
				elif (not validResourceId (id1)):
					Err_write (self, ErrorCode.IDChoice, opcode, id1);
				else:
					r.processCopyColormapAndFree (self, id1);
				#endif
			#endiF
		elif(opcode in (RequestCode.FreeColormap, RequestCode.InstallColormap, RequestCode.UninstallColormap, RequestCode.AllocColor, RequestCode.AllocNamedColor, RequestCode.AllocColorCells, RequestCode.AllocColorPlanes, RequestCode.FreeColors, RequestCode.StoreColors, RequestCode.StoreNamedColor, RequestCode.QueryColors, RequestCode.LookupColor)):
			if (bytesRemaining < 4): 
				Err_write (self, ErrorCode.Length, opcode, 0);
			else: 
				id = self.getInputOutput().readInt ();
				r = self._xServer.getResource (id);

				bytesRemaining -= 4;
				if (r == null or r.getType () != Resource.COLORMAP): 
					self.getInputOutput().readSkip (bytesRemaining);
					Err_write (self, ErrorCode.Colormap, opcode, id);
				else: 
					r.processRequest (self, opcode, arg, bytesRemaining);
				#endiF
			#endif
		elif(opcode in (RequestCode.CreateCursor, RequestCode.CreateGlyphCursor)):
			if (bytesRemaining != 28): 
				self.getInputOutput().readSkip (bytesRemaining);
				Err_write (self, ErrorCode.Length, opcode, 0);
			else: 
				id = self.getInputOutput().readInt ();	# Cursor ID.

				bytesRemaining -= 4;
				if (not validResourceId (id)): 
					self.getInputOutput().readSkip (bytesRemaining);
					Err_write (self, ErrorCode.IDChoice, opcode, id);
				else: 
					Cursor.processCreateRequest (self._xServer, self, opcode, id, bytesRemaining);
				#endiF
			#endif
		elif(opcode in (RequestCode.FreeCursor, RequestCode.RecolorCursor)):
			if (bytesRemaining < 4): 
				Err_write (self, ErrorCode.Length, opcode, 0);
			else: 
				id = self.getInputOutput().readInt ();
				r = self._xServer.getResource (id);

				bytesRemaining -= 4;
				if (r == null or r.getType () != Resource.CURSOR): 
					self.getInputOutput().readSkip (bytesRemaining);
					Err_write (self, ErrorCode.Colormap, opcode, id);
				else: 
					r.processRequest (self, opcode, arg, bytesRemaining);
				#endif
			#endif
		elif(opcode == RequestCode.QueryExtension):
			self._xServer.processQueryExtensionRequest (self, bytesRemaining);
		elif(opcode == RequestCode.ListExtensions):
			if (bytesRemaining != 0): 
				self.getInputOutput().readSkip (bytesRemaining);
				Err_write (self, ErrorCode.Length, opcode, 0);
			else: 
				self._xServer.writeListExtensions (self);
		#endif
		elif(opcode in ( RequestCode.QueryKeymap, RequestCode.ChangeKeyboardMapping, RequestCode.GetKeyboardMapping, RequestCode.ChangeKeyboardControl, RequestCode.SetModifierMapping, RequestCode.GetModifierMapping, RequestCode.GetKeyboardControl, RequestCode.Bell)):
			#if(RequestCode.GetKeyboardMapping):
			#if(self._xServer):
			self._xServer.getKeyboard().processRequest (self._xServer, self, opcode, arg, bytesRemaining);
		elif(opcode == RequestCode.SetScreenSaver):
			if (bytesRemaining != 8): 
				self.getInputOutput().readSkip (bytesRemaining);

				Err_write (self, ErrorCode.Length, opcode, 0);
			else: 
				timeout = self.getInputOutput().readShort ();	# Timeout.
				interval = self.getInputOutput().readShort ();	# Interval
				pb = self.getInputOutput().readByte ();	# Prefer-blanking.
				ae = self.getInputOutput().readByte ();	# Allow-exposures.

				self.getInputOutput().readSkip (2);	# Unused.
				self._xServer.setScreenSaver (timeout, interval, pb, ae);
			#endif
		elif(opcode == RequestCode.GetScreenSaver):
			if (bytesRemaining != 0): 
				self.getInputOutput().readSkip (bytesRemaining);
				Err_write (self, ErrorCode.Length, opcode, 0);
			else: 
				self._xServer.writeScreenSaver (self);
			#endiF
		elif(opcode == RequestCode.ChangeHosts):
			self._xServer.processChangeHostsRequest (self, arg, bytesRemaining);
		elif(opcode == RequestCode.ListHosts):
			if (bytesRemaining != 0): 
				self.getInputOutput().readSkip (bytesRemaining);
				Err_write (self, ErrorCode.Length, opcode, 0);
			else: 
				self._xServer.writeListHosts (self);
			#endi
		elif(opcode == RequestCode.SetAccessControl):
			if (bytesRemaining != 0): 
				self.getInputOutput().readSkip (bytesRemaining);
				Err_write (self, ErrorCode.Length, opcode, 0);
			else: 
				self._xServer.setAccessControl (arg == 1);
			#endiF
		elif(opcode == RequestCode.SetCloseDownMode):
			processSetCloseDownModeRequest (arg, bytesRemaining);
		elif(opcode == RequestCode.KillClient):
			processKillClientRequest (bytesRemaining);
		elif(opcode == RequestCode.ForceScreenSaver):
			if (bytesRemaining != 0): 
				self.getInputOutput().readSkip (bytesRemaining);
				Err_write (self, ErrorCode.Length, opcode, 0);
			else: 
				self._xServer.getScreen().blank (arg == 1);
			#endiF
		elif(opcode == RequestCode.NoOperation):
			self.getInputOutput().readSkip (bytesRemaining);
		else:	# Opcode not implemented.
			if (opcode < 0): 
				Extensions.processRequest (self._xServer, self, opcode, arg, bytesRemaining);
			else: 
				self.getInputOutput().readSkip (bytesRemaining);
				print("raise(Exception)NoOperRequestSupported")
				Err_write (self, ErrorCode.Implementation, opcode, 0);
			#endiF
		#endiF	

	def processSetCloseDownModeRequest (self, mode, bytesRemaining):# throws IOException {
		if (bytesRemaining != 0): 
			self.getInputOutput().readSkip (bytesRemaining);
			Err_write (self, ErrorCode.Length, RequestCode.SetCloseDownMode, 0);
			return()
		#endif

		self._closeDownMode = mode;
		for  r in self._resources:
			r.setCloseDownMode (mode);
		#endfor
 



	def processKillClientRequest (self, bytesRemaining):# throws IOException {
		if (bytesRemaining != 4): 
			self.getInputOutput().readSkip (bytesRemaining);
			Err_write (self, ErrorCode.Length, RequestCode.KillClient, 0);
			return()
		#endiF

		id = self.getInputOutput().readInt ();
		client = Client(null);

		if (id != 0): 
			r = Resource(self._xServer.getResource (id));

			if (r == null): 
				Err_write (self, ErrorCode.Length, RequestCode.KillClient, 0);
				return()
			#endif

			client = r.getClient ();
		#endiF

		if (client != null and client.self._isConnected):
			client._closeConnection = true;
		elif (client == null or client.self._closeDownMode != Destroy):
			self._xServer.destroyClientResources (client);
	#endiF

