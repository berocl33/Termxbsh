

from XUtil import  *

EventBase = 76;
KindBounding = 0;
KindClip = 1;
KindInput = 2;

ShapeQueryVersion = 0;
ShapeRectangles = 1;
ShapeMask = 2;
ShapeCombine = 3;
ShapeOffset = 4;
ShapeQueryExtents = 5;
ShapeSelectInput = 6;
ShapeInputSelected = 7;
ShapeGetRectangles = 8;

OpSet = 0;
OpUnion = 1;
OpIntersect = 2;
OpSubtract = 3;
OpInvert = 4;

class XShape: 
    def processRequest(c, client, opcode, arg, bytesRemaining):#1 throws java.io.IOException {
        io = client.getInputOutput();

        if (opcode==ShapeQueryVersion):
                if (bytesRemaining != 0): 
                    io.readSkip(bytesRemaining);
                    Err_writeWithMinorOpcode(client, ErrorCode.Length, arg, opcode, 0);
                else: 
                    #synchronized (io) {
                    writeReplyHeader(client, arg);
                    io.writeInt(0);    #// Reply length.
                    io.writeShort( 1);    #// Shape major.
                    io.writeShort( 1);    #// Shape minor.
                    io.writePadBytes(20);
                    #}
                    io.flush();
                #endif
        elif(opcode==ShapeRectangles):
                if (bytesRemaining < 12): 
                    io.readSkip(bytesRemaining);
                    Err_writeWithMinorOpcode(client, ErrorCode.Length, arg, opcode, 0);
                else: 
                    shapeOp = signed( io.readByte());
                    shapeKind = signed( io.readByte());

                    io.readByte();    #// Ordering.
                    io.readSkip(1);

                    wid = io.readInt();
                    x = int(io.readShort());
                    y = int(io.readShort());
                    w = c.getResource(wid);

                    bytesRemaining -= 12;

                    nr = bytesRemaining / 8;
                    r = null if(nr == 0) else  Region();
                    i = 0;

                    while(i < nr):
                        rx =int( io.readShort())
                        ry =int( io.readShort())
                        rw =int( io.readShort())
                        rh =int( io.readShort())
                        r.op( Rect(rx, ry, rx + rw, ry + rh), Region.Op.UNION);
                        bytesRemaining -= 8;
                        i+=1
                    #endif

                    if (bytesRemaining != 0): #err 
                        io.readSkip(bytesRemaining);
                    #endif 
                    regionOperate(w, shapeKind, r, shapeOp, x, y);
                    if (shapeKind != KindInput and w.isViewable()):
                        w.invalidate();
                    #endif
                #endif
        elif(opcode==ShapeMask):
                if (bytesRemaining != 16): 
                    io.readSkip(bytesRemaining);
                    Err_writeWithMinorOpcode(client, ErrorCode.Length, arg, opcode, 0);
                else: 
                    shapeOp = signed( io.readByte());
                    shapeKind = signed(io.readByte());

                    io.readSkip(2);

                    wid = io.readInt();
                    x = int(io.readShort());
                    y = int(io.readShort());
                    pid = io.readInt();    #// Pixmap ID.
                    w = c.getResource(wid);
                    p = null if(pid == 0) else c.getResource(pid);
                    r = null if(p == null) else createRegion(p);

                    regionOperate(w, shapeKind, r, shapeOp, x, y);
                    if (shapeKind != KindInput and w.isViewable()):
                        w.invalidate();
                    #end
                #endif
        elif(opcode == ShapeCombine):
                if (bytesRemaining != 16): 
                    io.readSkip(bytesRemaining);
                    Err_writeWithMinorOpcode(client, ErrorCode.Length, arg, opcode, 0);
                else: 
                    shapeOp = signed( io.readByte())
                    dstKind = signed( io.readByte())
                    srcKind = signed( io.readByte())

                    io.readSkip(1);

                    dwid = io.readInt();
                    x = int(io.readShort())
                    y = int(io.readShort())
                    swid = io.readInt();
                    sw = c.getResource(swid);
                    dw = c.getResource(dwid)
                    sr = sw.getShapeRegion(srcKind);
                    irect = sw.getIRect();

                    x -= irect.left;    #// Make region coordinates relative.
                    y -= irect.top;

                    regionOperate(dw, dstKind, sr, shapeOp, x, y);
                    if (dstKind != KindInput and dw.isViewable()):
                        dw.invalidate();
                    #endif
                #endif
        elif(opcode == ShapeOffset):
                if (bytesRemaining != 12): 
                    io.readSkip(bytesRemaining);
                    Err_writeWithMinorOpcode(client, ErrorCode.Length, arg, opcode, 0);
                else: 
                    shapeKind = signed( io.readByte());

                    io.readSkip(3);

                    wid = io.readInt();
                    x = int(io.readShort())
                    y = int(io.readShort())
                    w = c.getResource(wid) 
                    r = Region(w.getShapeRegion(shapeKind));

                    if (r != null and (x != 0 or y != 0)): 
                        r.translate(x, y);
                        w.sendShapeNotify(shapeKind);
                        if (shapeKind != KindInput and w.isViewable()):
                            w.invalidate();
                        #endif
                    #endif
                #endif
        elif(opcode == ShapeQueryExtents):
                if (bytesRemaining != 4): 
                    io.readSkip(bytesRemaining);
                    Err_writeWithMinorOpcode(client, ErrorCode.Length, arg, opcode, 0);
                else: 
                    wid = io.readInt();
                    w = c.getResource(wid) 
                    bs = w.isBoundingShaped();
                    cs = w.isClipShaped();
                    orect=Rect();
                    irect=Rect();

                    if (bs):
                        orect = w.getShapeRegion(KindBounding).getBounds();
                    else:
                        orect = w.getORect();
                    #endif
                    if (cs):
                        irect= w.getShapeRegion(KindClip).getBounds();
                    else:
                        irect = w.getIRect();
                    #endif

                    #synchronized (io) {
                    writeReplyHeader(client, arg);
                    io.writeInt(0);
                    io.writeByte( (1  if(bs ) else  0));    #// Bounding shaped?
                    io.writeByte( (1  if(cs ) else  0));    #// Clip shaped?
                    io.writePadBytes(2);
                    io.writeShort( orect.left);
                    io.writeShort( orect.top);
                    io.writeShort( orect.width());
                    io.writeShort( orect.height());
                    io.writeShort( irect.left);
                    io.writeShort( irect.top);
                    io.writeShort( irect.width());
                    io.writeShort( irect.height());
                    io.writePadBytes(4);
                    #}
                    io.flush();
                #endif
        elif(opcode == ShapeSelectInput):
                if (bytesRemaining != 8): 
                    io.readSkip(bytesRemaining);
                    Err_writeWithMinorOpcode(client, ErrorCode.Length, arg, opcode, 0);
                else: 
                    wid = io.readInt();
                    enable = (io.readByte() == 1);

                    io.readSkip(3);

                    w = c.getResource(wid);

                    if (enable):
                        w.addShapeSelectInput(client);
                    else:
                        w.removeShapeSelectInput(client);
                    #endif
                #endif
        elif(opcode == ShapeInputSelected):
                if (bytesRemaining != 4): 
                    io.readSkip(bytesRemaining);
                    Err_writeWithMinorOpcode(client, ErrorCode.Length, arg, opcode, 0);
                else: 
                    wid = io.readInt();
                    w = c.getResource(wid);
                    enabled = w.shapeSelectInputEnabled(client);

                    #synchronized (io) {
                    writeReplyHeader(client, (byte) (1  if(enabled ) else  0));
                    io.writeInt(0);    #// Reply length.
                    io.writePadBytes(24);
                    #}
                    io.flush();
                #endif
        elif(opcode == ShapeGetRectangles):
                if (bytesRemaining != 8): 
                    io.readSkip(bytesRemaining);
                    Err_writeWithMinorOpcode(client, ErrorCode.Length, arg, opcode, 0);
                else:
                    wid = io.readInt();
                    shapeKind = io.readByte();

                    io.readSkip(3);

                    w = c.getResource(wid);
                    r = w.getShapeRegion(shapeKind);
                    irect = w.getIRect();
                    ordering = 0;    #// Unsorted.
                    rectangles = rectanglesFromRegion(r);
                    nr = rectangles.size();
                    #synchronized (io) {
                    writeReplyHeader(client, ordering);
                    io.writeInt(2 * nr);    #// Reply length.
                    io.writeInt(nr);
                    io.writePadBytes(20);

                    for rect in rectangles: 
                            io.writeShort(rect.left - irect.left);
                            io.writeShort(rect.top - irect.top);
                            io.writeShort(rect.width());
                            io.writeShort(rect.height());
                    #endif
                    #}

                    io.flush();
                #endif
        else:
                io.readSkip(bytesRemaining);
                Err_write(client, ErrorCode.Implementation, opcode, 0);
        #endif
    #endif
     
    def regionOperate(c, w, shapeKind, sr, shapeOp, x, y): 
        if (sr != null):     #// Apply (x, y) offset.
            r = Region();
            irect = w.getIRect();

            sr.translate(x + irect.left, y + irect.top, r);
            sr = r;
        #endif

        dr = w.getShapeRegion(shapeKind);

        #if(shapeOp==OpSet):
        if(shapeOp == OpUnion):
                if (sr == null or dr == null):
                    sr = null;
                else:
                    sr.op(dr, Region.Op.UNION);
                #end
        elif(shapeOp == OpIntersect):
                if (sr == null):
                    sr = dr;
                elif (dr != null):
                    sr.op(dr, Region.Op.INTERSECT);
                #end
        elif(shapeOp == OpSubtract):    #// Subtract source region from dest region.
                if (sr == null):
                    sr = Region();    #// Empty region.
                elif (dr == null):
                    sr.op(w.getORect(), Region.Op.DIFFERENCE);
                else:
                    sr.op(dr, Region.Op.DIFFERENCE);
        elif(shapeOp == OpInvert):    #// Subtract dest region from source region.
                if (dr == null): 
                    sr = Region();    #// Empty region.
                elif (sr == null): 
                    sr = Region(w.getORect());
                    sr.op(dr, Region.Op.REVERSE_DIFFERENCE);
                else: 
                    sr.op(dr, Region.Op.REVERSE_DIFFERENCE);
                #end
        else:
            return;
        #endif

        w.setShapeRegion(shapeKind, sr);
        w.sendShapeNotify(shapeKind);

    def rectanglesFromRegion(c, r):
        rl = ArrayList();

        if (r != null and not r.isEmpty()):
            if (r.isRect()):
                rl.add(r.getBounds());
            else:
                extractRectangles(r, r.getBounds(), rl);
        #endif

        return rl;

    def extractRectangles(c, r, rect, rl): 
        rs = regionRectIntersection(r, rect);

        if (rs == 0):    #// No intersection with rect.
            return;
        #endif
        if (rs == 1):     #// Full intersection with rect.
            rl.add(rect);
            return;
        #endif

        rw = rect.width();
        rh = rect.height();

        if (rw > rh):     #// Split the rectangle horizontally.
            cx = rect.left + rw / 2;

            extractRectangles(r,  Rect(rect.left, rect.top, cx, rect.bottom), rl);
            extractRectangles(r,  Rect(cx, rect.top, rect.right, rect.bottom), rl);
        else:     #// Split it vertically.
            cy = rect.top + rh / 2;

            extractRectangles(r,  Rect(rect.left, rect.top, rect.right, cy), rl);
            extractRectangles(r,  Rect(rect.left, cy, rect.right, rect.bottom), rl);
        #endif
    

    def regionRectIntersection(c, r, rect): 
        if (r.quickReject(rect)):
            return 0;
        #end
        icount = 0;
        ocount = 0;

        y = rect.top;
        while( y < rect.bottom ):
            x = rect.left;
            while( x < rect.right ):
                if (r.contains(x, y)):
                   icount+=1;
                else:
                   ocount+=1;
                #end
                x+=1;
 
            if (icount > 0 and ocount > 0):
                return -1;
            #endif
            y+=1
        #end}

        if (icount == 0):
            return 0;
        elif (ocount == 0):
            return 1;
        #end}

        return -1;
    

    def createRegion(c, p): 
        d = p.getDrawable();
        r = Region();

        extractRegion(r, d.getBitmap(), Rect(0, 0, d.getWidth(), d.getHeight()));

        return r;
     
    def extractRegion(c, region, bitmap, rect): 
        nzp = checkNonZeroPixels(bitmap, rect);

        if (nzp == 1):    #// Empty.
            return;
        #endif
        rw = rect.width();
        rh = rect.height();

        if (nzp == 2):     #// All non-zero. We have a rectangle.
            region.op(rect, Region.Op.UNION);
            return;
        #endif

        if (rw > rh):     #// Split the rectangle horizontally.
            cx = rect.left + rw / 2;

            extractRegion(region, bitmap,  Rect(rect.left, rect.top, cx, rect.bottom));
            extractRegion(region, bitmap,  Rect(cx, rect.top, rect.right, rect.bottom));
        else:     #// Split it vertically.
            cy = rect.top + rh / 2;

            extractRegion(region, bitmap,  Rect(rect.left, rect.top, rect.right, cy));
            extractRegion(region, bitmap,  Rect(rect.left, cy, rect.right, rect.bottom));
        #endif

    
    def checkNonZeroPixels(c, bitmap, rect): 
        width = rect.width();
        height = rect.height();
        pixels = [int()]*width;
        mask = 3;

        i = 0;
        while( i < height):
            bitmap.getPixels(pixels, 0, width, rect.left, rect.top + i, width, 1);

            for  p in pixels:
                mask &= 2  if(p != 0xff000000) else  1;
                if (mask == 0):
                    return 0;
                #endif
            #endif
            i+=1
        #endif

        return mask;
