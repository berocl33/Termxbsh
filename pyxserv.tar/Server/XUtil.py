
REPLACECOMPAT=False#True 
null=None
false=chr(0);true=chr(1)
try:
 assert(long)
except(Exception):
 long=int

def arraycopy(ia,ioff,oa,oaoff,asz):
 for a in range(asz):
  if(len(oa)<oaoff+a):
   oa.append(ia[ioff+a])
  else:
   oa[oaoff+a]=ia[ioff+a]


class boolean():
 def __init__(self,b=None):
  pass


class signed(bytes):
 def __init__(self,byted=null):
  if(byted):
   self.view=abs(byted)%129;
  else:
   self.view=None

 def __abs__(self):
  return abs(self.view if(isinstance(self.view,(short,int,long))) else 0)
 def __int__(self):
  return self.view if(isinstance(self.view,(bytes,short,int,long))) else 0

 def __repr__(self):
  return chr(self.view) if(self.view) else chr(0)
 def __str__(self):
  return(bytes(self.view or [0]).encode("ASCII"))
 def encode(self,n="HEX"):
  if(True in [a in n for a in ("UTF-8","ASCII")]):
   return "".join([chr(a) for a in self.view]) 
  if(True in [a in n for a in ("HEX","BASE16")]):
   return "".join([hex(a) for a in self.view]) 

class bitarr():
 def __init__(self,*views):
  tuple.__init__(self);
  for view in views:
   if(hasattr(view,"__len__")):
    self+=tuple(view); 
   else:
    self+=(view,)
  
 
class short(signed): 
 def __init__(self,*lisp):
  self.view=lisp[0] if(len(lisp)>0) else 0
 def __str__(self):
  return chr((self.view>>8)&0xff)+chr(self.view&0xff)

class String():
 def __init__(self,*losk):
  if(len(losk)==1 and isinstance(losk[0],str)):
   self.view=bytearray([ord(a) for a in losk[0]])
  elif len(losk)>1:
   self.view=bytearray(losk)
 def __int__(self):
  return self.view if(isinstance(self.view,(bytes,short,int,long))) else 0
 def __len__(self):
  return len(self.view) if(isinstance(self.view,(bytes,short,int,long))) else 0
 def __repr__(self):
  return chr(self.view) if(self.view) else chr(0)
 def __str__(self):
  return(bytearray(self.view or [0]).encode("ASCII"))
 def encode(self,n="HEX"):
  if(True in [a in n for a in ("UTF-8","ASCII")]):
   return "".join([chr(a) for a in self.view]) 
  if(True in [a in n for a in ("HEX","BASE16")]):
   return "".join([hex(a) for a in self.view]) 

class Vector(list):
 def __init__(self,objs=None):
  if(isinstance(objs,(self.__class__,list,tuple))):
   [self.append(a) for a in objs] 
  else: 
   self.append(objs)

 def add(self,obj):
  if(obj not in self):
   self.append(obj)
  #else:
  # raise( Exception, "multipleAdd")

 def remove(self,obj):
  if(obj in self):
   self[self.index(obj)]=None
 def size(self):
  return(len(self))

 def get(self,objn):
  return(self[objn])


class Array(list):
 _typeable=["Drawable","Screen","XServer"]
 def __init__(self,*objs):
  self._types=();
  if(len(objs) and not isinstance(objs[0],(list,tuple))):
   objs.insert(0,objs[0])
  else:
   objs.insert(0,(type(objs),))
  for aty in range(len(objs[0])):
   for ty in self._typeable:
    if ty in str(type(objs[0][aty])):
     self._types+=(objs[0].pop(aty),)
  if(len(objs)>1 and Isinstance(objs[1],dict)):
   self+=dict.items()
  else:#if(not isinstance(objs,(list,tuple))):
   self+=list(objs)

 def add(self,p):
  self.append(p)

class Rect():
 def __init__(self,*geom):
  pass
class Region(Rect):
 pass
class Set(Vector):
 pass

class Hashtable(Vector):
 def put(self,server,id,bles):
  self.append((server,id,bles))
 def containsKey(self,id,firstTuple=null):
  for a in self: 
   if(id == a[1]):
    return(true);
class HashSet(Set):
 pass

class ErrorCode:
  NoErr = 0;
  Request = 1;
  Value = 2;
  Window = 3;
  Pixmap = 4;
  Atom = 5;
  Cursor = 6;
  Font = 7;
  Match = 8;
  Drawable = 9;
  Access = 10;
  Alloc = 11;
  Colormap = 12;
  GContext = 13;
  IDChoice = 14;
  Name = 15;
  Length = 16;
  Implementation = 17;

def Err_write(c, error, opcode, resourceId):
        Err_writeWithMinorOpcode(c, error, short(0), opcode, resourceId);
    

def Err_writeWithMinorOpcode(c, error, minorOpcode, opcode, resourceId):
        io = c.getInputOutput();
        sn = short(client.getSequenceNumber() & 0xffff);

        #synchronized (io) {
        io.writeByte(signed(0));    # Indicates an error.
        io.writeByte(error);        # Error code.
        io.writeShort(sn);            # Sequence number.
        io.writeInt(resourceId);    # Bad resource ID.
        io.writeShort(minorOpcode);    # Minor opcode.
        io.writeByte(opcode);        # Major opcode.
        io.writePadBytes(21);        # Unused.
        #}
        io.flush();
    #endif

class Paint():
 def __init__(*objs):
  pass



class EventCode: 
  KeyPress = 2;
  KeyRelease = 3;
  ButtonPress = 4;
  ButtonRelease = 5;
  MotionNotify = 6;
  EnterNotify = 7;
  LeaveNotify = 8;
  FocusIn = 9;
  FocusOut = 10;
  KeymapNotify = 11;
  Expose = 12;
  GraphicsExposure = 13;
  NoExposure = 14;
  VisibilityNotify = 15;
  CreateNotify = 16;
  DestroyNotify = 17;
  UnmapNotify = 18;
  MapNotify = 19;
  MapRequest = 20;
  ReparentNotify = 21;
  ConfigureNotify = 22;
  ConfigureRequest = 23;
  GravityNotify = 24;
  ResizeRequest = 25;
  CirculateNotify = 26;
  CirculateRequest = 27;
  PropertyNotify = 28;
  SelectionClear = 29;
  SelectionRequest = 30;
  SelectionNotify = 31;
  ColormapNotify = 32;
  ClientMessage = 33;
  MappingNotify = 34;
  
  MaskKeyPress = 0x00000001;
  MaskKeyRelease = 0x00000002;
  MaskButtonPress = 0x00000004;
  MaskButtonRelease = 0x00000008;
  MaskEnterWindow = 0x00000010;
  MaskLeaveWindow = 0x00000020;
  MaskPointerMotion = 0x00000040;
  MaskPointerMotionHint = 0x00000080;
  MaskButton1Motion = 0x00000100;
  MaskButton2Motion = 0x00000200;
  MaskButton3Motion = 0x00000400;
  MaskButton4Motion = 0x00000800;
  MaskButton5Motion = 0x00001000;
  MaskButtonMotion = 0x00002000;
  MaskKeymapState = 0x00004000;
  MaskExposure = 0x00008000;
  MaskVisibilityChange = 0x00010000;
  MaskStructureNotify = 0x00020000;
  MaskResizeRedirect = 0x00040000;
  MaskSubstructureNotify = 0x00080000;
  MaskSubstructureRedirect = 0x00100000;
  MaskFocusChange = 0x00200000;
  MaskPropertyChange = 0x00400000;
  MaskColormapChange = 0x00800000;
  MaskOwnerGrabButton = 0x01000000;
  
  MaskAllPointer = MaskButtonPress | MaskButtonRelease | MaskPointerMotion | MaskPointerMotionHint | MaskButton1Motion | MaskButton2Motion | MaskButton3Motion | MaskButton4Motion | MaskButton5Motion | MaskButtonMotion;

class RequestCode:
  CreateWindow = 1;
  ChangeWindowAttributes = 2;
  GetWindowAttributes = 3;
  DestroyWindow = 4;
  DestroySubwindows = 5;
  ChangeSaveSet = 6;
  ReparentWindow = 7;
  MapWindow = 8;
  MapSubwindows = 9;
  UnmapWindow = 10;
  UnmapSubwindows = 11;
  ConfigureWindow = 12;
  CirculateWindow = 13;
  GetGeometry = 14;
  QueryTree = 15;
  InternAtom = 16;
  GetAtomName = 17;
  ChangeProperty = 18;
  DeleteProperty = 19;
  GetProperty = 20;
  ListProperties = 21;
  SetSelectionOwner = 22;
  GetSelectionOwner = 23;
  ConvertSelection = 24;
  SendEvent = 25;
  GrabPointer = 26;
  UngrabPointer = 27;
  GrabButton = 28;
  UngrabButton = 29;
  ChangeActivePointerGrab = 30;
  GrabKeyboard = 31;
  UngrabKeyboard = 32;
  GrabKey = 33;
  UngrabKey = 34;
  AllowEvents = 35;
  GrabServer = 36;
  UngrabServer = 37;
  QueryPointer = 38;
  GetMotionEvents = 39;
  TranslateCoordinates = 40;
  WarpPointer = 41;
  SetInputFocus = 42;
  GetInputFocus = 43;
  QueryKeymap = 44;
  OpenFont = 45;
  CloseFont = 46;
  QueryFont = 47;
  QueryTextExtents = 48;
  ListFonts = 49;
  ListFontsWithInfo = 50;
  SetFontPath = 51;
  GetFontPath = 52;
  CreatePixmap = 53;
  FreePixmap = 54;
  CreateGC = 55;
  ChangeGC = 56;
  CopyGC = 57;
  SetDashes = 58;
  SetClipRectangles = 59;
  FreeGC = 60;
  ClearArea = 61;
  CopyArea = 62;
  CopyPlane = 63;
  PolyPoint = 64;
  PolyLine = 65;
  PolySegment = 66;
  PolyRectangle = 67;
  PolyArc = 68;
  FillPoly = 69;
  PolyFillRectangle = 70;
  PolyFillArc = 71;
  PutImage = 72;
  GetImage = 73;
  PolyText8 = 74;
  PolyText16 = 75;
  ImageText8 = 76;
  ImageText16 = 77;
  CreateColormap = 78;
  FreeColormap = 79;
  CopyColormapAndFree = 80;
  InstallColormap = 81;
  UninstallColormap = 82;
  ListInstalledColormaps = 83;
  AllocColor = 84;
  AllocNamedColor = 85;
  AllocColorCells = 86;
  AllocColorPlanes = 87;
  FreeColors = 88;
  StoreColors = 89;
  StoreNamedColor = 90;
  QueryColors = 91;
  LookupColor = 92;
  CreateCursor = 93;
  CreateGlyphCursor = 94;
  FreeCursor = 95;
  RecolorCursor = 96;
  QueryBestSize = 97;
  QueryExtension = 98;
  ListExtensions = 99;
  ChangeKeyboardMapping = 100;
  GetKeyboardMapping = 101;
  ChangeKeyboardControl = 102;
  GetKeyboardControl = 103;
  Bell = 104;
  ChangePointerControl = 105;
  GetPointerControl = 106;
  SetScreenSaver = 107;
  GetScreenSaver = 108;
  ChangeHosts = 109;

  ListHosts = 110;
  SetAccessControl = 111;
  SetCloseDownMode = 112;
  KillClient = 113;
  RotateProperties = 114;
  ForceScreenSaver = 115;
  SetPointerMapping = 116;
  GetPointerMapping = 117;
  SetModifierMapping = 118;
  GetModifierMapping = 119;

  NoOperation = 127;
  ExtensionStart = -128;
 
  ExtensionEnd = -1;

class Resource():
 WINDOW=1;PIXMAP=2;CURSOR=3;FONT=4;GCONTEXT=5;COLORMAP=6

 def __init__(self,type=0,id=0,server=null,parent=null,client=null,closedownmode=null,*objs):
  self._type=type;
  self._id=id;
  self._xServer=server
  self._parent=parent
  self._client=client
  self._closeDownMode=closedownmode
 def getId(self):
  id = self._id if(hasattr(self,"_id")) else getattr(self,"_idr",None)
  return(id)

 def getType(self):
  return(self._type)

 def getCloseDownMode(self):
  return(self._closeDownMode)
 def delete(self,xServer=None):
  if(not xServer):
   xServer=self._xServer 
  xServer.freeResource(self._id)
 def isFontable(self):
  return(self._type in (self.FONT,self.GCONTEXT))
 def isDrawable(self):
  return(self._type in (self.WINDOW,self.PIXMAP))
 def processRequest(self,*argv):
  pass 

class Font(Resource):
 pass

class Colormap(Resource):
 _white=0xf0f0f0f0;_black=0x000000
 def getWhitePixel(self):
  return(self._white) 
 def getBlackPixel(self):
  return(self._black)

 def setInstalled(self,L):
  if not L and self._id in self._parent._installedColormaps:
   self._parent.removeInstalledColormap(self)
  elif L and self._id not in self._parent._installedColormaps: 
   self._parent.addInstalledColormap(self)

class Cursor(Resource):
 _hotspotX=0;_hotspotY=0
 _foregroundColor=0xff<24
 _backgroundColor=0x0<24
 _bitmap=null
 _glyphs=[(-1,7,9)]

 def __init__(self,xServer=null,xScreen=null,visual=None,obn=null,obp=null,obm=null,width=null,height=null,bitmap=None,mask=None):
  if(obp!=null):
   if not height:
    height=len(obp)/sorted([len(obp)/s<len(obp/2) and s for s in range(3,len(obp)/3)])[-1]
   if(not width):
    width=len(obp)/height 
   #endif
  else:
   obp=bitmap if(bitmap!=null) else Bitmap();

  self.width=width;
  self.height=height;
  if(bitmap==null):
   bitmap=Bitmap.createBitmap(obp,width if(width) else width,height)
  #endif 
  self._bitmap=bitmap;

class Format(Resource):
 _depth=signed()
 _bitsPerPixel=signed()
 _scanlinePad=signed()

 def __init__(self,depth=None,bitsPerPixel=None,scanlinePad=None,_io=null):
  self._depth=depth;self._io=_io
  if(bitsPerPixel!=None):
   self._bitsPerPixel=bitsPerPixel;
  if(scanlinePad!=None):
   self._scanlinePad=scanlinePad;

 def write(c,io=None):
  if(not io):
   print("raise()noIo");io=c._io
  io.writeByte(self._depth);io.writeByte(self._bitsPerPixel);io.writeByte(self._scanlinePad)
  io.writePadBytes(5)

class Visual(Resource):
 _depth=32;_bitmap=null
 _hotspotX=0;_hotspotY=0
 _foregroundColor=0;_backgroundColor=0 
 _param={
    "BackingStoreNever":0,
    "BackingStoreWhenMapped":1,
    "BackingStoreAlways":2,

    "StaticGray":0,
    "GrayScale":1,
    "StaticColor":2,
    "PseudoColor":3,
    "TrueColor":4,
    "DirectColor":5
   }
 _winAttr=[null,null,null,null,null,null,[_param["BackingStoreNever"],_param["BackingStoreWhenMapped"],_param["BackingStoreAlways"]], ]
 _saveUnder=false
 _id=0;_backingStore=_param["BackingStoreNever"]
 _colorspace=_param["TrueColor"]
 def getBitmap(self):
  return(self._bitmap)

 def getBackingStoreInfo(self):
  return(self._backingStore)

 def getSaveUnder(self):
  return(self._saveUnder)
 def getDepth(self):
  return(self._depth)

 def getHotspotX(self):
  return (self._hotspotX)
 def getHotspotY(self):
  return (self._hotspotY)

 def setColor(self,fg,bg):
  self._foregroundColor=fg
  self._backgroundColor=bg

 def processRequest(self,client,opcode,arg,bytesRemaining):
  if (opcode == RequestCode.FreeCursor):
   if(bytesRemaining>0):
    Err_write(client,ErrorCode.Length,opcode,0)
   else:
    if(client==null):
     client=self._client
    client.freeResource(self._id)
    #client.freeResource(self)
    #endif
   #endif
  elif(opcode == RequestCode.RecolorCursor):
   pass
  #endkf

 def processCreateRequest(self,xServer,client,opcode,id,bytesRemaining):
  if(opcode == RequestCode.CreateCursor):
   pass
  elif(opcode == RequestCode.CreateGlyphCursor):
   pass

 def write(self,io=None):
  if(not io):
   io=self.io
  io.writeInt(self.getId())
  io.writeByte(self._colorspace)
  io.writeByte(8)
  io.writeShort(1<<8)
  io.writeInt(0xff0000)
  io.writeInt(0xff00)
  io.writeInt(0xff)
  io.writePadBytes(4)

class PassiveButtonGrab(Cursor):
 pass

class PassiveKeyGrab(Cursor):
 pass

class Bitmap(Colormap):
 def __init__(self,obj=None,width=0,height=0):
  self.width=width;self.height=height 

 def eraseColor(self,objColor):
  pass

 def createBitmap(*objargs):
  return Bitmap(*objargs) 

class Canvas():
 def __init__(self,bitmap=null):
  self._bitmap=bitmap 

class XReply:
 def __init__(self,client=None,io=None,seq=None):
  self._client=client
  self._io=io
  self._seq=seq
 def header(self,code,arg,client=None,seq=None):
  if(not client):
   client=self._client
  if(not seq):
   seq=client.getSequenceNumber()
  for asb in (signed(1),signed(arg),short(seq&0xffff)):
   yield(asb)

def writeReplyHeader(code,arg,client=None,io=None,seq=None):
 nr=XReply(client,io,seq)
 io.write(nr.header())
 return(nr)

