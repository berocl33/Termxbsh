
from XUtil import *
from XIo import InputOutput
 
class Property: 
	_id=null
	_type=null
	_format=signed()
	_data =signed()

	def __init__ ( id, type, format): 
		self._id = id;
		self._type = type;
		self._format = format;
	
	def newProperty(p):
		self._id = p._id;
		self._type = p._type;
		self._format = p._format;
		self._data = p._data;
	

	def getId (self):
		return( self._id);


	def processRequest (self, xServer, client, arg, opcode, bytesRemaining, w, properties):# throws IOException {
		if(opcode == RequestCode.ChangeProperty):
				processChangePropertyRequest (xServer, client, arg, bytesRemaining, w, properties);
		elif opcode == RequestCode.GetProperty:
			processGetPropertyRequest (xServer, client, arg == 1, bytesRemaining, w, properties);
		elif opcode == RequestCode.RotateProperties:
			processRotatePropertiesRequest (xServer, client, bytesRemaining, w, properties);
		else:
			io = InputOutput(client.getInputOutput ());

			io.readSkip (bytesRemaining);
			Err_write (client, ErrorCode.Implementation, opcode, 0);
		#endif
	

	def processChangePropertyRequest ( xServer, client, mode,bytesRemaining, w, properties):# throws IOException {
		io = InputOutput(client.getInputOutput ());

		if (bytesRemaining < 16):
			io.readSkip (bytesRemaining);
			Err_write (client, ErrorCode.Length,
											RequestCode.ChangeProperty, 0);
			return()
		#endif

		pid = io.readInt ();	
		tid = io.readInt ();	
		format = signed( io.readByte ());	

		io.readSkip (3);	

		length = io.readInt ();	
		n=int(0); pad=int(0);

		if (format == 8):
			n = length;
		elif (format == 16):
			n = length * 2;
		else:
			n = length * 4;
		#endif
		pad = -n & 3;

		bytesRemaining -= 16;
		if (bytesRemaining != n + pad):
			io.readSkip (bytesRemaining);
			Err_write (client, ErrorCode.Length,
											RequestCode.ChangeProperty, 0);
			return()
		#endif

		data = [signed()]*n;

		io.readBytes (data, 0, n);
		io.readSkip (pad);	

		property = Atom(xServer.getAtom (pid));

		if (property == null):
			Err_write (client, ErrorCode.Atom, RequestCode.ChangeProperty, pid);
			return()
		#endiF

		if (not xServer.atomExists (tid)):
			Err_write (client, ErrorCode.Atom, RequestCode.ChangeProperty, tid);
			return()
		#endif

		p=Property()

		if (properties.containsKey (pid)):
			p = properties.get (pid);
		else: 
			p = Property (pid, tid, format);
			properties.put (pid, p);
		#endif

		if (mode == 0):	
			p.self._type = tid;
			p.self._format = format;
			p.self._data = data;
		else:
			if (tid != p.self._type or format != p.self._format):
				Err_write (client, ErrorCode.Match, RequestCode.ChangeProperty, 0);
				return()
			#endi

			if (p.self._data == null):
				p.self._data = data;
			else: 
				d1=[]; d2=[]

				if (mode == 1):	
					d1 = data;
					d2 = p.self._data;
				else: 	
					d1 = p.self._data;
					d2 = data;
				#endif

				p.self._data = []*(d1.length + d2.length);
				arraycopy (d1, 0, p.self._data, 0, d1.length);
				arraycopy (d2, 0, p.self._data, d1.length, d2.length);
			#endif
		#3ndif

		sc = w.getSelectingClients (EventCode.MaskPropertyChange)
		if(sc != null):
			for  c in sc:
				EventCode.sendPropertyNotify (c, w, property, xServer.getTimestamp (), 0);
			#endfk
		#enxif

	def processGetPropertyRequest ( xServer, client, delete, bytesRemaining, w, properties):# throws IOException {
		io = InputOutput(client.getInputOutput ());

		if (bytesRemaining != 16):
			io.readSkip (bytesRemaining);
			Err_write (client, ErrorCode.Length,
												RequestCode.GetProperty, 0);
			return()
		#emdi

		pid = io.readInt ();	
		tid = io.readInt ();	
		longOffset = io.readInt ();	
		longLength = io.readInt ();	
		property = Atom(xServer.getAtom (pid));

		if (property == null):
			Err_write (client, ErrorCode.Atom, RequestCode.GetProperty, pid);
			return()
		elif (tid != 0 and not xServer.atomExists (tid)):
			Err_write (client, ErrorCode.Atom, RequestCode.GetProperty, tid);
			return()
		#endkf

		format = signed(0);
		bytesAfter = int(0);
		value = [];
		generateNotify = boolean(false);

		if (properties.containsKey (pid)):
			p = Property(properties.get	(pid));

			tid = p.self._type;
			format = p.self._format;

			if (tid != 0 and tid != p.self._type):
				bytesAfter = 0 if(p.self._data == null) else p.self._data.length;
			else: 
				n=0; i=0; t=0; l=0;

				n = 0 if(p.self._data == null) else p.self._data.length;
				i = 4 * longOffset;
				t = n - i;

				if (longLength < 0 or longLength > 536870911):
					longLength = 536870911;	
				#endif

				if (t < longLength * 4):
					l = t;
				else:
					l = longLength * 4;
				#endif
				bytesAfter = n - (i + l);

				if (l < 0):
					Err_write (client, ErrorCode.Value, RequestCode.GetProperty, 0);
					return()
				#endkc

				if (l > 0):
					value = [signed()]*l;
					arraycopy (p.self._data, i, value, 0, l);
				#endjf

				if (delete and bytesAfter == 0):
					properties.remove (pid);
					generateNotify = true;
				#enfkF
			#emdif
		else: 
			tid = 0;
		#endif

		length = 0 if (value == null) else int(value.length);
		pad = int(-length & 3);
		valueLength=int()

		if (format == 8):
			valueLength = length;
		elif (format == 16):
			valueLength = length / 2;
		elif (format == 32):
			valueLength = length / 4;
		else:
			valueLength = 0;
		#wnsif
		#synchronized (io):
		Util.writeReplyHeader (client, format);
		io.writeInt ((length + pad) / 4);	
		io.writeInt (tid);	
		io.writeInt (bytesAfter);	
		io.writeInt (valueLength);	
		io.writePadBytes (12);	

		if (value != null):
			io.writeBytes (value, 0, value.length);	
			io.writePadBytes (pad);	
		#endif
		#}
		io.flush ();

		if (generateNotify):
			sc = w.getSelectingClients (EventCode.MaskPropertyChange)
			if(sc != null):
				for  c in sc:
					EventCode.sendPropertyNotify (c, w, property, xServer.getTimestamp (), 1);
				#endfor
			#endif
		#endif

	def processRotatePropertiesRequest ( xServer, client, bytesRemaining, w, properties):# throws IOException {
		io = InputOutput(client.getInputOutput ());

		if (bytesRemaining < 4):
			io.readSkip (bytesRemaining);
			Err_write (client, ErrorCode.Length, RequestCode.RotateProperties, 0);
			return()
		#endif

		n = io.readShort ();	
		delta = io.readShort ();	

		bytesRemaining -= 4;
		if (bytesRemaining != n * 4):
			io.readSkip (bytesRemaining);
			Err_write (client, ErrorCode.Length, RequestCode.RotateProperties, 0);
			return()
		#endif

		if (n == 0 or (delta % n) == 0):
			return()
		#ensif
		aids = [int(0)]*n;
		props = [Property()]*n;
		pcopy = [Property()]*n;

		i= 0
		while( i < n):
			aids[i] = io.readInt ();
			i+=1
		i = 0
		while(i < n):
			if (not xServer.atomExists (aids[i])):
				Err_write (client, ErrorCode.Atom, RequestCode.RotateProperties, aids[i]);
				return()
			elif (not properties.containsKey (aids[i])):
				Err_write (client, ErrorCode.Match, RequestCode.RotateProperties, aids[i]);
				return()
			else: 
				props[i] = properties.get (aids[i]);
				pcopy[i] = Property (props[i]);
			#endif
			i+=1
		#endif

		i = 0
		while( i < n):
			p = Property(props[i]);
			pc = Property(pcopy[(i + delta) % n]);

			p._type = pc._type;
			p._format = pc._format;
			p._data = pc._data;
			i+=1
		#endfor

		sc = w.getSelectingClients (EventCode.MaskPropertyChange)
		if(sc != null):
			i = 0
			while( i < n ):
				for  c in sc:
					EventCode.sendPropertyNotify (c, w, xServer.getAtom (aids[i]), xServer.getTimestamp (), 0);
				#endfkr
			i+=1
			#endfor
		#endif
	

