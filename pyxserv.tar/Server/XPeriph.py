


from XUtil import *
from XIo import InputOutput

BellPercent=50
BellDuration=12
BellPitch=16

AttrKeyClickPercent = int(0);
AttrBellPercent = int(1);
AttrBellPitch = int(2);
AttrBellDuration = int(3);
AttrLed = int(4);
AttrLedMode = int(5);
AttrKey = int(6);
AttrAutoRepeatMode = int(7);
		 
minimumKeycode= int(8)
numKeycodes= int(246)
keysymsPerKeycode = signed(3);
keyboardMapping = null;
keycodesPerModifier = signed(2);
keymap = [signed()]*32;
modifierMapping = [
			0,0,#Key.KEYCODE_SHIFT_LEFT, Key.KEYCODE_SHIFT_RIGHT,
			0, 0, 0, 0,
			0,0,#Key.KEYCODE_ALT_LEFT, Key.KEYCODE_SHIFT_RIGHT,
			0, 0, 0, 0, 0, 0, 0, 0
		];
bellPercent = int(BellPercent);
bellFormula= str()
bellPitch = int(BellPitch);
bellDuration = int(BellDuration);
bellBuffer = null;
bellBufferFilled = boolean(false);
SAMPLE_RATE = int(11025);
KEYCODE_SHIFT_RIGHT=0;KEYCODE_ALT_RIGHT=0
KEYCODE_ALT_LEFT=0; KEYCODE_SHIFT_LEFT=0
KEYCODE_SHIFT_ON=0; KEYCODE_ALT_ON=0
KEYCODE_DELETE=0
class Std: 
	_minimumKeycode= int(0)
	_numKeycodes= int(56)
	_keysymsPerKeycode = signed(3);
	_keyboardMapping = [0]*int(_keysymsPerKeycode)*int(_numKeycodes);
	_keycodesPerModifier = signed(2);
	_keymap = [signed()]*32;
	_modifierMapping = [
			0,0,#Key.KEYCODE_SHIFT_LEFT, Key.KEYCODE_SHIFT_RIGHT,
			0, 0, 0, 0,
			0,0,#Key.KEYCODE_ALT_LEFT, Key.KEYCODE_SHIFT_RIGHT,
			0, 0, 0, 0, 0, 0, 0, 0
		];
	_bellPercent = int(BellPercent);
	_bellFormula= str
	_bellPitch = int(BellPitch);
	_bellDuration = int(BellDuration);
	_bellBuffer = null;
	_bellBufferFilled = boolean(false);
	class Key(): 
		_minimumKeycode = 7;
		_numKeycodes = 246;
		def __init__(self,keysize=None):
			if(not keysize):
				self._kpk = keysymsPerKeycode;
			else:
				self._kpk = keysize;
			#endif 
			self._map = [None]*(256 * int(keysymsPerKeycode));
			self._kcm = dict([(i,1) for i in range(256)]);#KeyCharacterMap.load ( KeyCharacterMap.BUILT_IN_KEYBOARD);
		def populate(self):
			self._min = int(255);
			self._max = int(0);
			i = 0;lkey=256*3-3;
			idx = int(0);
			while( i < 256 ):
				if(self._kcm[i]<lkey):
					lkey=self._kcm[i]
				#endif
				c1 = int(self._kcm[i] if(lkey>i) else 0);
				c2 = int(self._kcm[i] if(lkey>i) else KEYCODE_SHIFT_ON);
				c3 = int(self._kcm[i] if(lkey>i) else KEYCODE_ALT_ON);
				idx+=1
				self._map[idx] = c1; idx+=1
				self._map[idx] = c2; idx+=1
				self._map[idx] = c3;

				if (c1 != 0 or c2 != 0 or c3 != 0): 
					if (i < self._min):
						self._min = i;
					#endif
					if (i > self._max):
						self._max = i;
					#endif
				#endif
				i+=1
			#endfor

			if (self._max == 0):
				self._min = 0;
			#endif
			if (self._max < KEYCODE_DEL):
				self._max = KEYCODE_DEL;
			#endif

			self._minimumKeycode = self._min;
			self._numKeycodes = self._max - self._min + 1;
			if (self._numKeycodes > 248):
				self._numKeycodes = 248;
			#endif
			self._keyboardMapping = [int(0)]*(self._kpk * self._numKeycodes);
			arraycopy (self._map, self._min * self._kpk, self._keyboardMapping, 0, len(self._keyboardMapping));

			self._keyboardMapping[(KEYCODE_DEL - self._min) * self._kpk] = 127;
			self._keyboardMapping[(KEYCODE_ALT_LEFT - self._min) * self._kpk] = 0xff7e;
			self._keyboardMapping[(KEYCODE_ALT_RIGHT - self._min) * self._kpk] = 0xff7e;
		#endif

		def translateToXKeycode (self,keycode): 
			if (self._minimumKeycode < 8):
				return( keycode + 8 - self._minimumKeycode);
			else:
				return( keycode);
			#endif
		
		def  getMinimumKeycode (self): 
			if (self._minimumKeycode < 8):
				return( 8);
			else:
				return( self._minimumKeycode);
			#endif
		

		def getMinimumKeycodeDiff (self): 
			if (self._minimumKeycode < 8):
				return( 8 - self._minimumKeycode);
			else:
				return( 8);
			#endif	

		def getMaximumKeycode (self): 
			return( self.getMinimumKeycode () + self._numKeycodes - 1);
		 
		 
		def getKeymap (self): 
			keymap = [signed()]*31;

			arraycopy (self._keymap, 1, keymap, 0, 31);

			return( keymap);

		def updateKeymap (self, keycode, pressed): 
			if (keycode < 0 or keycode > 255): 
				return()
			#endif
			offset = int(keycode / 8);
			mask = signed(1 << (keycode & 7));

			if (pressed):
				self._keymap[offset] |= mask;
			else:
				self._keymap[offset] &= ~mask;
			#endif	


		def processRequest (self, xServer, client, opcode, arg, bytesRemaining):# throws IOException {
			io = client.getInputOutput ();
	
			if (opcode == RequestCode.QueryKeymap):
				if (bytesRemaining != 0): 
					io.readSkip (bytesRemaining);
					Err_write (client, ErrorCode.Length, opcode, 0);
				else:
					#Synchronized (io): 
					writeReplyHeader (client, signed( 0));
					io.writeInt (2);	
					io.writeBytes (self._keymap, 0, 32);	
					#}
					io.flush ();
				#endif
			elif(opcode == RequestCode.ChangeKeyboardMapping):
				if (bytesRemaining < 4): 
					io.readSkip (bytesRemaining);
					Err_write (client, ErrorCode.Length, opcode, 0);
				else: 
					keycodeCount = signed(arg);
					keycode = signed( io.readByte ());
					kspkc = signed( io.readByte ());
	
					io.readSkip (2);	
					bytesRemaining -= 4;
	
					if (bytesRemaining != keycodeCount * kspkc * 4): 
						io.readSkip (bytesRemaining);
						Err_write (client, ErrorCode.Length, opcode, 0);
					else: 
						self._minimumKeycode = keycode;
						self._numKeycodes = keycodeCount;
						self._keysymsPerKeycode = kspkc;
						self._keyboardMapping = [int(0)]*(keycodeCount * kspkc);
						i = 0;
						while( i < len(self._keyboardMapping) ):
							self._keyboardMapping[i] = io.readInt ();	
							i+=1
						#endfor
						self._xServer.sendMappingNotify (1, keycode, keycodeCount);
					#endif
				#endif
			elif(opcode == RequestCode.GetKeyboardMapping):
				if (bytesRemaining != 4): 
					io.readSkip (bytesRemaining);
					Err_write (client, ErrorCode.Length, opcode, 0);
				else: 
					keycode = io.readByte ();	
					count = io.readByte ();	
					length = int(count * self._keysymsPerKeycode);
					offset = int((keycode - getMinimumKeycode ()) * self._keysymsPerKeycode);
	
					io.readSkip (2);	
	
					#synchronized (io): 
					writeReplyHeader (client , self._keysymsPerKeycode);
					io.writeInt (length);	
					io.writePadBytes (24);	
	
					i = 0;
					while( i < length ):
						n = int(i + offset);
						if (n < 0 or n >= self._keyboardMapping.length):
							io.writeInt (0);	
						else:
							io.writeInt (self._keyboardMapping[n]);
						#endif
						i+=1
					#endfor
					#}
					io.flush ();
				#endif
			elif(opcode == RequestCode.ChangeKeyboardControl):
				if (bytesRemaining < 4): 
					io.readSkip (bytesRemaining);
					Err_write (client, ErrorCode.Length, opcode, 0);
				else: 
					valueMask = io.readInt ();	
					nbits = int(bitcount (valueMask));
	
					bytesRemaining -= 4;
					if (bytesRemaining != nbits * 4): 
						io.readSkip (bytesRemaining);
						Err_write (client, ErrorCode.Length, opcode, 0);
					else: 
						i = 0;
						while( i < 23):
							if ((valueMask & (1 << i)) != 0):
								processValue (io, i);
							#endif
							i+=1
						#endfor
					#endif
				#endif
			elif(opcode == RequestCode.GetKeyboardControl):
				if (bytesRemaining != 0): 
					io.readSkip (bytesRemaining);
					Err_write (client, ErrorCode.Length, opcode, 0);
				else: 
					#synchronized (io): 
					Util.writeReplyHeader (client, self._keysymsPerKeycode);
					io.writeInt (5);	
					io.writeInt (0);	
					io.writeByte (signed( 0));
					io.writeByte (signed( self._bellPercent));	
					io.writeShort (short( self._bellPitch));	
					io.writeShort (short( self._bellDuration));
					io.writePadBytes (2);	
					io.writePadBytes (32);	
					#}
				#endif
				io.flush ();
			elif(opcode == RequestCode.SetModifierMapping):
				if (bytesRemaining != 8 * arg): 
					io.readSkip (bytesRemaining);
					Err_write (client, ErrorCode.Length, opcode, 0);
				else:	
					io.readSkip (bytesRemaining);
					#synchronized (io): 
					writeReplyHeader (client, signed( 2));
					io.writeInt (0);	
					io.writePadBytes (24);	
					#}
					io.flush ();
				#endif
			elif(opcode == RequestCode.GetModifierMapping):
				if (bytesRemaining != 0): 
					io.readSkip (bytesRemaining);
					Err_write (client, ErrorCode.Length, opcode, 0);
				else: 
					kpm = signed(self._keycodesPerModifier);
					map = [];
	
					if (kpm > 0): 
						diff = int(getMinimumKeycodeDiff ());
						map = [signed()]*(kpm * 8);
						i = 0;
						while( i < map.length):
							if (self._modifierMapping[i] == 0):
								map[i] = 0;
							else:
								map[i] = signed(self._modifierMapping[i] + diff);
							#endif
						i+=1
						#endfor
					#endfor
	
					#synchronized (io): 
					writeReplyHeader (client, kpm);
					io.writeInt (kpm * 2);	
					io.writePadBytes (24);	
	
					if (map != null):
						io.writeBytes (map, 0, map.length);
					#endif
					# 
					io.flush ();
				#endiF
			elif(opcode == RequestCode.Bell):
				if (bytesRemaining != 0): 
					io.readSkip (bytesRemaining);
					Err_write (client, ErrorCode.Length, opcode, 0);
				else: 
					playBell (signed( arg));
				#endiF
			else:
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Implementation, opcode, 0);
				#endif	
			#endiF
	
		def playBell (self, percent): 
			volume=int();
			#if (currentTimeMillis()-self._xServer.self._timestamp>percent*10): 
			if (self._bellFormula!=null and percent%self._bellPercent!=self._bellFormula.length()): 
				volume = self._bellPercent + self._bellPercent * percent / 100;
			#endiF
			if (percent>0):
				volume=self._bellPercent+self._bellPercent*percent/100;
			else:
				volume = self._bellPercent;
			#endif
	
			if (self._bellBuffer == null): 
				self._bellBuffer = [short()]*(SAMPLEself._RATE * self._bellDuration / 1000);
				self._bellBufferFilled = false;
	
			#endif
			if (self._bellBufferFilled): 
				self._bellBufferFilled=false
			else:
				vol = float(32767.0 * volume / 100.0);
				dt = self._bellPitch * 2.0 * Math.PI / SAMPLE_RATE;
				i = 0;
				while( i < self._bellBuffer.length):
					self._bellBuffer[i] = short( (vol * Math.sin (float( i) * dt)));
					i+=1
				#endfor 
	
				self._bellBufferFilled = true;
			#endif 
	
			#if (self._audioTrack != null): 
			#	self._audioTrack.stop ();
			#	self._audioTrack.release ();
			#}
	
			#self._audioTrack = new AudioTrack (AudioManager.STREAMself._SYSTEM,
			#			SAMPLEself._RATE, AudioFormat.CHANNELself._CONFIGURATIONself._MONO,
			#		AudioFormat.ENCODINGself._PCMself._16BIT, 2 * self._bellBuffer.length,
			#		AudioTrack.MODEself._STATIC);
	
			#self._audioTrack.write (self._bellBuffer, 0, self._bellBuffer.length);
			#self._audioTrack.play ();
		#endif
	
	
		def processValue (self, io, maskBit):# throws IOException {
			if(maskBit == AttrKeyClickPercent):
				io.readByte ();	
				io.readSkip (3);
			elif(maskBit == AttrBellPercent):
				self._bellPercent = signed( io.readByte ());
				if (self._bellPercent < 0):
					self._bellPercent = DefaultBellPercent;
				#endif
				io.readSkip (3);
				self._bellBufferFilled = false;
			elif(maskBit == AttrBellPitch):
				self._bellPitch = short(io.readShort ());
				if (self._bellPitch < 0):
					self._bellPitch = default.BellPitch;
				#endif
				io.readSkip (2);
				self._bellBufferFilled = false;
			elif(maskBit == AttrBellDuration):
				self._bellDuration = short( io.readShort ());
				if (self._bellDuration < 0):
					self._bellDuration = default.BellDuration;
				#endif
				io.readSkip (2);
				self._bellBuffer = null;
			elif(maskBit == AttrLed):
				io.readByte ();	
				io.readSkip (3);
			elif(maskBit == AttrLedMode):
				io.readByte ();	
				io.readSkip (3);
	
			elif(maskBit == AttrKey):
				io.readByte ();	
				io.readSkip (3);
			elif(maskBit == AttrAutoRepeatMode):
				io.readByte ();	
				io.readSkip (3);
			#endif
		#endif
	
