
import XShape#,XTest,XGL  

from XUtil import *

 
class Extensions: 
    GLX = -119 #no reason for thiz valuE
    XGE = -128;
    XTEST = -124;
    Sync = -127;
    BigRequests = -126;
    Shape = -125;

    def __init__(self):# Initialize(){
        XSync.Initialize();
    
    def processRequest(self,client, opcode, arg, bytesRemaining):# throws IOException {
        io = client.getInputOutput();

        if (opcode==self.XGE):
                if (bytesRemaining != 4):
                    io.readSkip(bytesRemaining);
                    Err_write(client, ErrorCode.Length, opcode, 0);
                else:    #// Assume arg == 0 (GEQueryVersion).
                    xgeMajor = short( io.readShort());
                    xgeMinor = short( io.readShort());

                    #synchronized (io):
                    writeReplyHeader(client, arg);
                    io.writeInt(0);    #// Reply length.
                    io.writeShort(xgeMajor);
                    io.writeShort(xgeMinor);
                    io.writePadBytes(20);
                    ##end
                    io.flush();
        elif(opcode==self.BigRequests):
                if (bytesRemaining != 0):
                    io.readSkip(bytesRemaining);
                    Err_write(client, ErrorCode.Length, opcode, 0);
                else:    #// Assume arg == 0 (BigReqEnable).
                    #synchronized (io):
                    writeReplyHeader(client, arg);
                    io.writeInt(0);
                    io.writeInt(1<<32);#INT_VALUE);
                    io.writePadBytes(20);
                    ##end
                    io.flush();
        elif(opcode==self.Shape):
                XShape.processRequest(self, client, opcode, arg, bytesRemaining);
        elif(opcode==self.XTEST):
                XTest.processRequest(self, client, opcode, arg, bytesRemaining);
        elif(opcode==self.Sync):
                pass#//    XSync.processRequest(xServer, client, opcode, arg, bytesRemaining);
        elif(opcode==self.GLX):
                XGL.processRequest(xServer,client,opcode,arg,bytesRemaining)

        else:
                io.readSkip(bytesRemaining);    #// Not implemented.
                Err_write(client, ErrorCode.Implementation, opcode, 0);
        #end
    #end

