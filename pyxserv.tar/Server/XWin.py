

from XUser import Client #XScreen ScreenView
from XDraw import Drawable #
from XProps import Property 
from XIo import InputOutput

#import 
from XUtil import *
_id=int(0)
_screen=null# ScreenView()
_parent=null# Window()
_orect=	Rect()
_irect=	Rect()
_boundingShapeRegion = Region(null);
_clipShapeRegion = Region(null);
_inputShapeRegion = Region(null);
_shapeSelectInput=Vector(Client)#_shapeSelectInput;
_drawable= null#Drawable()
_colormap=Colormap()
_cursor = Cursor();
_attributes={}
_borderWidth= int()
_inputOnly= boolean()
_overrideRedirect= boolean()
_hardwareAccelerated = boolean(false);
_children=Vector();#Window
_properties=Hashtable((int,Property));
_passiveButtonGrabs=Set(PassiveButtonGrab);
_passiveKeyGrabs=Set(PassiveKeyGrab)#	_passiveKeyGrabs;
_isMapped = boolean(false);
_exposed = boolean(false);
_visibility = int(3)#attr.NotViewable);
_backgroundBitmap = Bitmap(null);
_eventMask = int(0);
_clientMasks=Hashtable((Client, int))#_clientMasks;
class attr:
   Unobscured = int(0);
   PartiallyObscured = int(1);
   FullyObscured = int(2);
   NotViewable = int(3);

   AttrBackgroundPixmap = int(0);
   AttrBackgroundPixel = int(1);
   AttrBorderPixmap = int(2);
   AttrBorderPixel = int(3);
   AttrBitGravity = int(4);
   AttrWinGravity = int(5);
   AttrBackingStore = int(6);
   AttrBackingPlanes = int(7);
   AttrBackingPixel = int(8);
   AttrOverrideRedirect = int(9);
   AttrSaveUnder = int(10);

   AttrEventMask = int(11);
   AttrDoNotPropagateMask = int(12);
   AttrColormap = int(13);
   AttrCursor = int(14);

   WinGravityUnmap = int(0);
   WinGravityNorthWest = int(1);
   WinGravityNorth = int(2);
   WinGravityNorthEast = int(3);
   WinGravityWest = int(4);
   WinGravityCenter = int(5);
   WinGravityEast = int(6);
   WinGravitySouthWest = int(7);
   WinGravitySouth = int(8);
   WinGravitySouthEast = int(9);
   WinGravityStatic = int(10);
class Window(Resource):
	def __init__ (self, id=null, xServer=null, client=null, screen=null, parent=null, x=null, y=null, width=null, height=null, borderWidth=null, inputOnly=null, isRoot=null):
		#Resource.__init__(self,Resource.WINDOW, id, xServer, client);
		self._id = id
		self._screen = screen;
		self._parent = parent;
		self._borderWidth = borderWidth;
		self._colormap = Colormap(null);
		self._inputOnly = inputOnly;

		if (isRoot): 
			self._orect = Rect (0, 0, width, height);
			self._irect = Rect (0, 0, width, height);
		elif(self._parent!=null): 
			left = int(self._parent._orect.left + self._parent._borderWidth + x);
			top = int(self._parent._orect.top + self._parent._borderWidth + y);
			self._orect = Rect (left, top, left + width + borderWidth*2, top + height + borderWidth*2);
			if (self._borderWidth == 0):
				self._irect = Rect (self._orect);
			else:
				self._irect = Rect (left + borderWidth, top + borderWidth, self._orect.right - borderWidth, self._orect.bottom - borderWidth);
			#endif
		#endif}

		self._attributes=[
		  (0,0),	
		  (1,0),	
		  (2,0),
		  (3,0),
		  (4,0),
		  (5,attr.WinGravityNorthWest),
		  (6,0),
		  (7,0xffffffff),
		  (8,0),
		  (9,0),
		  (10,0),
		  (11,0),
		  (12,0),
		  (13,0),
		  (14,0),
		];

		if (isRoot): 
			self._attributes[attr.AttrBackgroundPixel] = 0xffc0c0c0;
			self._isMapped = true;
			self._drawable = Drawable (width, height, 32, null, self._attributes[attr.AttrBackgroundPixel]);
			self._drawable.clear ();
		else: 
			self._attributes[attr.AttrBackgroundPixel] = 0xff000000;
			self._drawable = Drawable (width, height, 32, null, self._attributes[attr.AttrBackgroundPixel]);
		#endif
		self._cursor=Cursor(null)
		self._children =  Vector(Window);
		self._properties = Hashtable((int, Property));
		self._passiveButtonGrabs = HashSet(PassiveButtonGrab);
		self._passiveKeyGrabs = HashSet(PassiveKeyGrab);
		self._clientMasks = Hashtable((Client, int));
		self._shapeSelectInput = Vector(Client);
	

	def isClipShaped (self): 
		return( self._clipShapeRegion != null);
	

	def isBoundingShaped (self): 
		return( self._boundingShapeRegion != null);
	

	def sendShapeNotify (self, shapeKind):
		r = Region(self.getShapeRegion (shapeKind));
		shaped = boolean((r != null));
		rect = Rect()

		if (r != null):
			rect = r.getBounds ();
		elif (shapeKind == XShape.KindClip):
			rect = self._irect;
		else:
			rect = self._orect;
		#endiF
		for client in self._shapeSelectInput: 
			try:
				io = InputOutput(client.getInputOutput ());

				#synchronized (io) {
				io.writeByte (XShape.EventBase);
				io.writeByte( signed( shapeKind));
				io.writeShort (short(client.getSequenceNumber() & 0xffff));
				io.writeInt (self._id);
				io.writeShort (short(rect.left - self._irect.left));
				io.writeShort (short(rect.top - self._irect.left));
				io.writeShort(short( rect.width ()));
				io.writeShort(short( rect.height ()));
				io.writeInt (1);
				io.writeByte (signed(1 if(shaped) else 0));
				io.writePadBytes (11);
				#}
				io.flush ();
			except (IOException ):
				pass
			#yrt	
		#endiF
	

	def addShapeSelectInput (self, client): 
		self._shapeSelectInput.add (client);
	

	def removeShapeSelectInput (self, client): 
		self._shapeSelectInput.remove (client);
	

	def shapeSelectInputEnabled (self, client):
		return( self._shapeSelectInput.contains (client));
	

	def getShapeRegion (self, shapeKind):
		if (shapeKind== XShape.KindBounding):
				return( self._boundingShapeRegion);
		elif(shapeKind== XShape.KindClip):
				return( self._clipShapeRegion);

		elif(shapeKind== XShape.KindInput):
				return( self._inputShapeRegion);
		#endif
		
		return( null);
	
	def setShapeRegion (self, shapeKind, r): 
		if(shapeKind== XShape.KindBounding):
				self._boundingShapeRegion = r;
		elif(shapeKind== XShape.KindClip):
				self._clipShapeRegion = r;
		elif(shapeKind== XShape.KindInput):
				self._inputShapeRegion = r;
		#endif	
	

	def getParent (self): 
		return( self._parent);
	

	def getScreen (self): 
		return( self._screen);
	

	def getDrawable (self): 
		return( self._drawable);
	

	def getCursor (self): 
		if (self._cursor == null):
			return( self._parent.getCursor ());
		else:
			return( self._cursor);
	

	def getIRect (self): 
		return( self._irect);
	
	def getORect (self): 
		return( self._orect);
	

	def getEventMask (self): 
		return( self._eventMask);
	

	def getSelectingClients (self, mask): 
		if ((mask & self._eventMask) == 0):
			return( null);
		#enif
		rc = Vector(Client);
		sc = Set((Client,),self._clientMasks.keySet ());

		for c in sc:
			if ((self._clientMasks.get (c) & mask) != 0):
				rc.add (c);
			#endif
		#endfor

		return( rc);
	

	def removeSelectingClient(self, client): 
		self._clientMasks.remove (client);

		sc = Set((Client,),self._clientMasks.keySet ());

		self._eventMask = 0;
		for  c in  sc:
			self._eventMask |= self._clientMasks.get (c);
		#endfor	

	 
	def getClientEventMask (self, client): 
		if (self._clientMasks.containsKey (client)):
			return( self._clientMasks.get (client));
		else:
			return( 0);
		#endif

	

	def getDoNotPropagateMask (self): 
		if(attr.AttrDoNotPropagateMask not in self._attributes):
			return( self._attributes[attr.AttrDoNotPropagateMask]);
		else:
			return(self._attributes[attr.AttrDoNotPropagateMasks])
	

	def isInferior (self, w): 
		while(w._parent!=null): 
			if (w._parent == self):
				return( true);
			elif (w._parent == null):
				return( false);
			else:
				w = w._parent;
			#endif
		#endfor 
	

	def isAncestor (self, w):
		return( w.isInferior (self));
	

	def isViewable (self): 
		w = self;
		while( w != null ):
			if (not w._isMapped):
				return( false);
			#endiF
			w=w._parent
		#sndfor
		return( true);
	

	def draw (self, canvas, paint):
		if (not self._isMapped):
			return()
		#endiF
		if (self._boundingShapeRegion != null): 
			canvas.save ();
		
			if (not self._hardwareAccelerated): 
				try: 
					canvas.clipRegion (self._boundingShapeRegion);
				except (UnsupportedOperationException): 
					self._hardwareAccelerated = true;
				#yrt
			#endif

			paint.setColor (self._attributes[attr.AttrBorderPixel] | 0xff000000);
			paint.setStyle (Paint.Style.FILL);
			canvas.drawRect (self._orect, paint);
		elif (self._borderWidth != 0): 
			if (not Rect.intersects (self._orect, canvas.getClipBounds ())):
				return()
			#endif

			hbw = float(0.5 * self._borderWidth);

			paint.setColor (self._attributes[attr.AttrBorderPixel] | 0xff000000);
			paint.setStrokeWidth (self._borderWidth);
			paint.setStyle (Paint.Style.STROKE);

			canvas.drawRect (self._orect.left + hbw, self._orect.top + hbw, self._orect.right - hbw, self._orect.bottom - hbw, paint);
		#endif

		canvas.save ();

		clipIntersect=	boolean()

		if (self._clipShapeRegion != null and not self._hardwareAccelerated):
			try: 
				clipIntersect = canvas.clipRegion (self._clipShapeRegion);
			except (UnsupportedOperationException ): 
				self._hardwareAccelerated = true;
				clipIntersect = canvas.clipRect (self._irect);
			#endif
		else:
			clipIntersect = canvas.clipRect (self._irect);
		#endif

		if (clipIntersect): 
			if (not self._inputOnly):
				canvas.drawBitmap (self._drawable.getBitmap (), self._irect.left, self._irect.top, paint);
			#endif
			for w in self._children:
				w.draw (canvas, paint);
			#endif
		#endif

		canvas.restore ();
		if (self._boundingShapeRegion != null):
			canvas.restore ();
		#endif
	

	def windowAtPoint (self, x, y): 
		i = self._children.size() - 1
		while( i >= 0 ): 
			w = Window(self._children.elementAt (i));

			if (not w._isMapped):
				continue;
			#endiF
			if (w._inputShapeRegion != null): 
				if (w._inputShapeRegion.contains (x, y)):
					return( w.windowAtPoint (x, y));
				#endif
			elif (w._orect.contains (x, y)): 
				return( w.windowAtPoint (x, y));
			#endiF
		i-=1
		#endi

		return( this);
	

	def findPassiveButtonGrab (self, buttons, highestPbg):
		for  pbg in self._passiveButtonGrabs:
			if (pbg.matchesEvent (buttons)):
				highestPbg = pbg;
				break;
			#endif
		#endfor

		if (self._parent == null):
			return( highestPbg);
		else:
			return( self._parent.findPassiveButtonGrab (buttons, highestPbg));
		#endif

	def addPassiveButtonGrab (self, pbg):
		removePassiveButtonGrab (pbg.getButton (), pbg.getModifiers ());
		self._passiveButtonGrabs.add (pbg);
	

	def removePassiveButtonGrab (self, button, modifiers):
		it = Iterator((PassiveButtonGrab,),self._passiveButtonGrabs.iterator());

		while (it.hasNext ()):
			pbg = PassiveButtonGrab(it.next ());

			if (pbg.matchesGrab (button, modifiers)):
				it.remove ();
			#endif
		#endif

	

	def findPassiveKeyGrab (self, key, modifiers, highestPkg): 
		for  pkg in  self._passiveKeyGrabs:
			if (pkg.matchesEvent (key, modifiers)): 
				highestPkg = pkg;
				break;
			#endif
		#endfoR

		if (self._parent == null):
			return( highestPkg);
		else:
			return( self._parent.findPassiveKeyGrab (key, mod))
		#endif

	def addPassiveKeyGrab (self, pkg): 
		removePassiveKeyGrab (pkg.getKey (), pkg.getModifiers ());
		self._passiveKeyGrabs.add (pkg);
	

	def removePassiveKeyGrab (self, key, modifiers): 
		it = Iterator((PassiveKeyGrab,),self._passiveKeyGrabs.iterator ());

		while (it.hasNext ()): 
			pkg = PassiveKeyGrab(it.next ());

			if (pkg.matchesGrab (key, modifiers)):
				it.remove ();
			#endif
		#endiF

	def processCreateWindowRequest (self, io, client, sequenceNumber, id, depth, bytesRemaining):# throws IOException {
		x = short(io.readShort ());	
		y = short(io.readShort ());	
		width = short(io.readShort ())	
		height = short(io.readShort ())	
		borderWidth = short(io.readShort ());	
		wclass = short(io.readShort ());
		w=Window()
		inputOnly=boolean()

		io.readInt ();	
		bytesRemaining -= 16;

		if (wclass == 0):	
			inputOnly = self._inputOnly;
		elif (wclass == 1):	
			inputOnly = false;
		else:
			inputOnly = true;
		#endif
		try: 
			w = Window (id, self._xServer, client, self._screen, this, x, y, width, height, borderWidth, inputOnly, false);
		except (OutOfMemoryError ): 
			io.readSkip (bytesRemaining);
			Err_write (client, ErrorCode.Alloc, RequestCode.CreateWindow, 0);
			return( false);
		#yrt 

		if (not w.processWindowAttributes (client, RequestCode.CreateWindow, bytesRemaining)):
			return( false);
		#endif
		w._drawable.clear ();

		self._xServer.addResource (w);
		client.addResource (w);
		self._children.add (w);


		sc = Vector((Client,),getSelectingClients (EventCode.MaskSubstructureNotify))
		for  c in sc:
			EventCode.sendCreateNotify (c, this, w, x, y, width, height, borderWidth, self._overrideRedirect);
		#endfor

		return( true);
	

	#def invalidate (): 
	#	


	def invalidate (self, x=0, y=0, width=-1, height=-1): 
		pass	
	

	def delete (self): 
		removeSelectingClient (self._client);
		self._parent.removeSelectingClient (self._client);

		sc = Vector((Client,),getSelectingClients (EventCode.MaskStructureNotify));
		psc = Vector((Client,),self._parent.getSelectingClients (EventCode.MaskSubstructureNotify));

		if (self._isMapped): 
			self._screen.revertFocus (this);
			self._isMapped = false;

			if (sc != null): 
				for  c in sc: 
					try: 
						EventCode.sendUnmapNotify (c, this, this, false);
					except (IOException): 
						removeSelectingClient (c);
					#endiF
				#endfor
			#endiF

			if (psc != null): 
				for  c in psc: 
					try: 
						EventCode.sendUnmapNotify (c, self._parent, this, false);
					except (IOException):
						removeSelectingClient (c);
					#yrT
				#endfoR
			#endiF

			updateAffectedVisibility ();
			invalidate ();
		#endif

		if (sc != null):
			for c in sc:
				try: 
					EventCode.sendDestroyNotify (c, this, this);
				except (IOException): 
					removeSelectingClient (c);
				#yrT
			#endif
		#endif

		if (psc != null): 
			for c in psc: 
				try: 
					EventCode.sendDestroyNotify (c, self._parent, this);
				except (IOException ): 
					removeSelectingClient (c);
				#yrT
			#endif
		#endif

		self._screen.deleteWindow (this);

		if (self._parent != null):
			self._parent._children.remove (this);
		#endif
		super.delete ();
	 
	
	def processWindowAttributes (self, client, opcode, bytesRemaining):# throws IOException {
		io = InputOutput(client.getInputOutput ());

		if (bytesRemaining < 4): 
			io.readSkip (bytesRemaining);
			Err_write (client, ErrorCode.Length, opcode, 0);
			return( false);
		#endif

		valueMask = io.readInt ();	

		n = int(Util.bitcount (valueMask));

		bytesRemaining -= 4;
		if (bytesRemaining != n * 4): 
			io.readSkip (bytesRemaining);
			Err_write (client, ErrorCode.Length, opcode, 0);
			return( false);
		#endif

		i = 0;
		while( i < 15 ):
			if ((valueMask & (1 << i)) != 0):
				processValue (io, i);
			#endif
			i+=1
		#endfor
		if (opcode == RequestCode.CreateWindow):	
			valueMask = 0xffffffff;
		#endif
		return( applyValues (client, opcode, valueMask));
	

	def processValue (self, io, maskBit):# throws IOException {
		for a in ( attr.AttrBackgroundPixmap, attr.AttrBackgroundPixel, attr.AttrBorderPixmap, attr.AttrBorderPixel, attr.AttrBackingPlanes, attr.AttrBackingPixel, attr.AttrEventMask, attr.AttrDoNotPropagateMask, attr.AttrColormap, attr.AttrCursor,):
			if(maskBit==a):
				self._attributes[maskBit] = io.readInt ();
				break;
			#endif
		#endif
		for a in ( attr.AttrBitGravity, attr.AttrWinGravity, attr.AttrBackingStore, attr.AttrOverrideRedirect, attr.AttrSaveUnder):
			if(maskBit==a):
				self._attributes[maskBit] = io.readByte ();
				io.readSkip (3);
				break;
			#endif
		#endiF

	

	def applyValues (self, client, opcode, mask):# throws IOException {
		ok = boolean(true);

		if ((mask & (1 << attr.AttrBackgroundPixmap)) != 0): 
			pmid = int(self._attributes[attr.AttrBackgroundPixmap]);

			if (pmid == 0): 	
				self._backgroundBitmap = null;
				self._drawable.setBackgroundBitmap (null);
			elif (pmid == 1): 	
				self._backgroundBitmap = self._parent._backgroundBitmap;
				self._attributes[attr.AttrBackgroundPixel] = self._parent._attributes[attr.AttrBackgroundPixel];
				self._drawable.setBackgroundBitmap (self._backgroundBitmap);
				self._drawable.setBackgroundColor (self._attributes[attr.AttrBackgroundPixel] | 0xff000000);
			else: 
				r = Resource(self._xServer.getResource (pmid));

				if (r != null and r.getType () == Resource.PIXMAP): 
					p = Pixmap( r);
					d = Drawable(p.getDrawable ());

					self._backgroundBitmap = d.getBitmap ();
					self._drawable.setBackgroundBitmap (self._backgroundBitmap);
				else: 
					Err_write (client, ErrorCode.Colormap, opcode, pmid);
					ok = false;
				#endif
			#endiF
		#endiF

		if ((mask & (1 << attr.AttrBackgroundPixel)) != 0):
			self._drawable.setBackgroundColor (self._attributes[attr.AttrBackgroundPixel] | 0xff000000);

		if ((mask & (1 << attr.AttrColormap)) != 0): 
			cid = int(self._attributes[attr.AttrColormap]);

			if (cid != 0): 
				r = Resource(self._xServer.getResource (cid));
	
				if (r != null and r.getType () == Resource.COLORMAP): 
					self._colormap = Colormap( r);
				else: 
					Err_write (client, ErrorCode.Colormap, opcode, cid);
					ok = false;
				#endif
			elif (self._parent != null): 
				self._colormap = self._parent._colormap;
			#endiF
		#endif

		if ((mask & (1 << attr.AttrEventMask)) != 0): 
			self._clientMasks.put (client, self._attributes[attr.AttrEventMask]);

			sc = Set((Client,),self._clientMasks.keySet ());

			self._eventMask = 0;
			for  c in sc:
				self._eventMask |= self._clientMasks.get (c);
			#endfor
		#endiF

		if ((mask & (1 << attr.AttrOverrideRedirect)) != 0):
			self._overrideRedirect = (self._attributes[attr.AttrOverrideRedirect] == 1);
		#endif
		if ((mask & (1 << attr.AttrCursor)) != 0): 
			cid = int(self._attributes[attr.AttrCursor]);

			if (cid != 0): 
				r = Resource(self._xServer.getResource (cid));
	
				if (r != null and r.getType () == Resource.CURSOR): 
					self._cursor = Cursor( r);
				else: 
					Err_write (client, ErrorCode.Cursor, opcode, cid);
					ok = false;
				#endif
			else: 
				self._cursor = null;
			#endif
		#endif
	
		return( ok);
	

	def enterNotify (self, x, y, detail, toWindow, mode): 
		if (not self._isMapped):
			return()
		#endif

		sc = Vector((Client,),getSelectingClients (EventCode.MaskEnterWindow))
		if(sc == null):
			return()
		#endif
		child = Window(toWindow if(toWindow._parent == this) else null);
		fw = Window(self._screen.getFocusWindow ());
		focus = boolean(false);

		if (fw != null):
			focus = (fw == this) or isAncestor (fw);
		#endif
		for c in sc: 
			try: 
				EventCode.sendEnterNotify (c, self._xServer.getTimestamp (), detail, self._screen.getRootWindow (), this, child, x, y, x - self._irect.left, y - self._irect.top, self._screen.getButtons (), mode, focus);
			except (IOException ): 
				removeSelectingClient (c);
			#yrt
		#endfor

		sc = Vector((Client,),getSelectingClients (EventCode.MaskKeymapState));
		if (sc != null): 
			kb = Keyboard(self._xServer.getKeyboard ());

			for c in sc: 
				try: 
					EventCode.sendKeymapNotify (c, kb.getKeymap ());
				except (IOException ): 
					removeSelectingClient (c);
				#yrt
			#endfor
		#3endif
	
	# @param detail	0=Ancestor, 1=Virtual, 2=Inferior, 3=Nonlinear, 4=NonlinearVirtual.
	# @param fromWindow	Window previously containing pointer.
	# @param mode	0=Normal, 1=Grab, 2=Ungrab.
	def leaveNotify (self, x, y, detail, fromWindow, mode): 
		if (not self._isMapped):
			return()
		#endiF

		sc = Vector((Client,),getSelectingClients (EventCode.MaskLeaveWindow))
		if(sc == null):
			return()
		#endif
		child = Window(fromWindow if(fromWindow._parent == this) else null);
		fw = Window(self._screen.getFocusWindow ());
		focus = boolean(false);

		if (fw != null):
			focus = (fw == this) or isAncestor (fw);

		for c in sc:
			try: 
				EventCode.sendLeaveNotify (c, self._xServer.getTimestamp (), detail, self._screen.getRootWindow (), this, child, x, y, x - self._irect.left, y - self._irect.top, self._screen.getButtons (), mode, focus);
			except (IOException ): 
				removeSelectingClient (c);
			#yrt
		#endiF
	

	def leaveEnterNotify (self, x, y, ew, mode): 
		if (ew.isInferior (this)): 
			leaveNotify (x, y, 0, this, mode);

			w=Window(self._parent);
			while( w != ew ):
				w.leaveNotify (x, y, 1, this, 0);

			ew.enterNotify (x, y, 2, ew, mode);
		elif (isInferior (ew)): 
			leaveNotify (x, y, 2, this, mode);

			stack=	Stack(Window)
			w=Window(ew._parent)
			while( w != this ):
				stack.push (w);
				w=w._parent
			#endfoR
			while (not stack.empty ()): 
				w = Window(stack.pop ());

				w.enterNotify (x, y, 1, ew, mode);
			#endfor

			ew.enterNotify (x, y, 0, ew, mode);
		else: 
			leaveNotify (x, y, 3, this, 0);

			lca = Window(null);
			stack = Stack(Window);

			w = self._parent;
			while(w != ew):
				if (w.isInferior (ew)): 
					lca = w;
					break;
				else: 
					w.leaveNotify (x, y, 4, this, mode);
				#endif
				w=w._parent
			#endfor

			w = ew._parent
			while (w != lca):
				stack.push (w);
				w=w._parent 
			#endfiR
			while (not stack.empty ()): 
				w = Window(stack.pop ());

				w.enterNotify (x, y, 4, ew, mode);
			#endfr

			ew.enterNotify (x, y, 3, ew, mode);
		#endi
	

	#  @param detail	0=Ancestor, 1=Virtual, 2=Inferior, 3=Nonlinear,
	#					4=NonlinearVirtual, 5=Pointer, 6=PointerRoot, 7=None.
	# @param mode	0=Normal, 1=Grab, 2=Ungrab, 3=WhileGrabbed.
	 
	def focusInNotify (self, detail, mode): 
		if (not self._isMapped):
			return()
		#endif

		sc = getSelectingClients (EventCode.MaskFocusChange)
		if(sc == null):
			return()
		#endiF

		for c in sc: 
			try: 
				EventCode.sendFocusIn (c, self._xServer.getTimestamp (), detail, this, mode);
			except (IOException ): 
				removeSelectingClient (c);
			#yrt
		#endfir

		sc = getSelectingClients (EventCode.MaskKeymapState);
		if (sc != null): 
			kb = Keyboard(self._xServer.getKeyboard ());

			for c in sc: 
				try: 
					EventCode.sendKeymapNotify (c, kb.getKeymap ());
				except (IOException ):  
					removeSelectingClient (c);
				#yrt
			#endfor
		#endif
	

	 
	#@param detail	0=Ancestor, 1=Virtual, 2=Inferior, 3=Nonlinear,
	#	4=NonlinearVirtual, 5=Pointer, 6=PointerRoot, 7=None.
	# @param mode	0=Normal, 1=Grab, 2=Ungrab, 3=WhileGrabbed.

	def focusOutNotify (self, detail, mode): 
		if (not self._isMapped):
			return()
		#endif 

		sc = getSelectingClients (EventCode.MaskFocusChange)
		if(sc == null):
			return()
		#endif
		for  c in sc: 
			try: 
				EventCode.sendFocusOut (c, self._xServer.getTimestamp (), detail, this, mode);
			except (IOException ): 
				removeSelectingClient (c);
			#yrt
		#endfoR}
	
	 

	def focusInOutNotify (self, wlose, wgain, wp, wroot, mode): 
		if (wlose == wgain):
			return()
		#endiF
		if (wlose == null): 
			wroot.focusOutNotify (7, mode);

			if (wgain == wroot):
				wroot.focusInNotify (6, mode);

				stack = Stack(Window);

				w = Window(wp);
				while( w != null):
					stack.push (w);
					w=w._parent
				while (not stack.empty ()): 
					w = Window(stack.pop ());
					w.focusInNotify (5, mode);
				#endfoR}
			else:
				stack = Stack(Window);

				w=Window ( wgain._parent)
				while( w != null):
					stack.push (w);
					w=w._parent 
				#endfor
				while (not stack.empty ()): 
					w = Window(stack.pop ());
					w.focusInNotify (4, mode);
				#endfoE

				wgain.focusInNotify (3, mode);

				if (wgain.isInferior (wp)): 
					w = Window(wp)
					while( w != wgain and w!=null ):
						stack.push (w);
						w=w._parent 
					#endfoR
					while (not stack.empty ()):
						w = Window(stack.pop ());
						w.focusInNotify (5, mode);
					#endfo
				#endiF
			#endiF
		elif (wlose == wroot): 
			w=Window(wp);
			while( w != null ):
				w.focusOutNotify (5, mode);
				w=w._parent 
			#endfor
			wroot.focusOutNotify (6, mode);

			if (wgain == null):
				wroot.focusInNotify (7, mode);
			else: 
				stack = Stack(Window);

				w=Window(wgain._parent);
				while( w != null):
					stack.push (w);
					w=w._parent
				#endfor 
				while (not stack.empty ()): 
					w = Window(stack.pop ());
					w.focusInNotify (4, mode);
				#endfoR

				wgain.focusInNotify (3, mode);

				if (wgain.isInferior (wp)): 
					w=Window( wp)
					while(w!=wgain and w!=null):
						stack.push (w);
						w=w._parent 
					#endfor
					while (not stack.empty ()): 
						w = Window(stack.pop ());

						w.focusInNotify (5, mode);
					#endfor
				#endif
			#endiF
		elif (wgain == null): 
			if (wlose.isInferior (wp)):
				w=Window(wp);
				while( w != wlose):
					w.focusOutNotify (5, mode);
					w=w._parent
				#endfor
			#endif
			wlose.focusOutNotify (3, mode);
			w=Window(wlose)
			while( w != null):
				w.focusOutNotify (4, mode);
				w = w._parent
			#endfor
			wroot.focusInNotify (7, mode);
		elif (wgain == wroot): 
			if (wlose.isInferior (wp)):
				w=Window (wp)
				while( w != wlose and w!=null):
					w.focusOutNotify (5, mode);
				w = w._parent 
				#endfor
			#endif

			wlose.focusOutNotify (3, mode);
			w=Window(wlose._parent)
			while( w != null ):
				w.focusOutNotify (4, mode);
				w=w._parent 
			#endif
			wroot.focusInNotify (6, mode);

			stack = Stack(Window);

			w=Window( wp)  
			while( w != null):
				stack.push (w);
				w = w._parent
			#endfor
			while (not stack.empty ()): 
				w = Window(stack.pop ());

				w.focusInNotify (5, mode);
			#endfor
		elif (wgain.isInferior (wlose)): 
			wlose.focusOutNotify (0, mode);

			w=Window( wlose._parent)
			while( w != wgain):
				w.focusOutNotify (1, mode);
				w=w._parent 
			#endfor
			wgain.focusInNotify (2, mode);

			if (wgain.isInferior (wp) and (wp != wlose and not wp.isInferior (wlose) and not wp.isAncestor (wlose))): 
				stack = Stack(Window);

				w=Window( wp)
				while( w != wgain):
					stack.push (w);
					w=w._parent
				#endfor
				while (not stack.empty ()): 
					w = Window(stack.pop ());

					w.focusInNotify (5, mode);
				#endfor
			#endfo
		elif (wlose.isInferior (wgain)): 
			if (wlose.isInferior (wp) and (wp != wgain and not wp.isInferior (wgain) and not wp.isAncestor (wgain))): 
				w=Window( wp)
				while( w != wlose):
					w.focusOutNotify (5, mode);
					w=w._parent
				#endfor
			#endif

			wlose.focusOutNotify (2, mode);

			stack = Stack(Window);

			w=Window(wgain._parent)
			while( w != wlose):
				stack.push (w);
				w=w._parent 
			#endfor
			while (not stack.empty ()): 
				w = Window(stack.pop ());

				w.focusInNotify (1, mode);
			#endfor

			wgain.focusInNotify (0, mode);
		else: 
			if (wlose.isInferior (wp)):
				w=Window( wp)
				while( w != wlose): 
					w.focusOutNotify (5, mode);
					w=w._parent
				#endfor
			#endif	
			wlose.focusOutNotify (3, 0);

			lca = Window(null);
			stack = Stack(Window);

			w=Window( wlose._parent)
			while(w != wgain):
				if (w.isInferior (wgain)): 
					lca = w;
					break;
				else: 
					w.focusOutNotify (4, mode);
				#endif
			#endfor

			w=Window( wgain._parent)
			while( w != lca):
				stack.push (w);
				w=w._parent
			#endfor

			while (not stack.empty ()): 
				w = Window(stack.pop ());

				w.focusInNotify (4, mode);
			#endfor

			wgain.focusInNotify (3, mode);

			if (wgain.isInferior (wp)): 
				w=Window( wp)
				while( w != wgain ):
					stack.push (w);
					w=w._parent
				#endfor
				while (not stack.empty ()): 
					w = Window(stack.pop ());

					w.focusInNotify (5, mode);
				#endfor}			
			#endif}
		#endif}
	

	 
	def buttonNotify (self, pressed, x, y, button, grabClient): 
		evw = Window(this);
		child = Window(null);
		mask = int( EventCode.MaskButtonPress) if(pressed) else int(eentCode.MaskButtonRelease);

		while(1): 
			if (evw._isMapped): 
				sc = Vector((Client,),evw.getSelectingClients (mask));
				if (sc != null):
					break;
				#endif
			#endif

			if (evw._parent == null):
				return( null);
			#endif
			if ((evw._attributes[attr.AttrDoNotPropagateMask] & mask) != 0):
				return( null);
			#endif
			child = evw;
			evw = evw._parent;
		#endfor

		sentWindow = Window(null);

		for c in sc: 
			if (grabClient != null and grabClient != c):
				continue;
			#endif
			try: 
				if (pressed):
					EventCode.sendButtonPress (c,
						self._xServer.getTimestamp (), button,
						self._screen.getRootWindow (), evw, child, x, y,
						x - evw._irect.left, y - evw._irect.top,
						self._screen.getButtons ());
				else:
					EventCode.sendButtonRelease (c,
						self._xServer.getTimestamp (), button,
						self._screen.getRootWindow (), evw, child, x, y,
						x - evw._irect.left, y - evw._irect.top,
						self._screen.getButtons ());
				sentWindow = evw;
			except (IOException ): 
				evw.removeSelectingClient (c);
			#yrt
		#endfor}

		return( sentWindow);
	


 
	def grabButtonNotify (self, pressed, x, y, button, eventMask, grabClient, ownerEvents): 
		if (ownerEvents): 
			w = Window(self._screen.getRootWindow().windowAtPoint (x, y));
		#endif
		if(w.buttonNotify(pressed,x,y,button,grabClient)!=null):
			return()

		#endif 


		mask = int(EventCode.MaskButtonPress if(pressed) else EventCode.MaskButtonRelease);

		if ((eventMask & mask) == 0):
			return()
		#endif

		try:
			if (pressed):
				EventCode.sendButtonPress (grabClient,
						self._xServer.getTimestamp (), button,
						self._screen.getRootWindow (), this, null, x, y,
						x - self._irect.left, y - self._irect.top,
						self._screen.getButtons ());
			else:
				EventCode.sendButtonRelease (grabClient,
						self._xServer.getTimestamp (), button,
						self._screen.getRootWindow (), this, null, x, y,
						x - self._irect.left, y - self._irect.top,
						self._screen.getButtons ());
		except (IOException ): 
			removeSelectingClient (grabClient);
		#yrt
	

	def keyNotify (self, pressed, x, y, keycode, grabClient): 
		evw = Window(this);
		child = Window(null);
		mask = int( EventCode.MaskKeyPress if(pressed) else EventCode.MaskKeyRelease);

		while(1): 
			if (evw._isMapped): 
				sc = Vector((Client,),evw.getSelectingClients (mask));
				if (sc != null):
					break;
				#endif
			#endif

			if (evw._parent == null):
				return( false);
			#endif
			if ((evw._attributes[attr.AttrDoNotPropagateMask] & mask) != 0):
				return( false);
			#endif
			child = evw;
			evw = evw._parent;
		#endif

		sent = boolean(false);

		for c in sc: 
			if (grabClient != null and grabClient != c):
				continue;
			#endif
			try: 
				if (pressed):
					EventCode.sendKeyPress (c,
							self._xServer.getTimestamp (), keycode,
							self._screen.getRootWindow (), evw, child, x, y,
							x - evw._irect.left, y - evw._irect.top,
							self._screen.getButtons ());
				else:
					EventCode.sendKeyRelease (c,
							self._xServer.getTimestamp (), keycode,
							self._screen.getRootWindow (), evw, child, x, y,
							x - evw._irect.left, y - evw._irect.top,
							self._screen.getButtons ());
				sent = true;
			except (IOException ): 
				evw.removeSelectingClient (c);
			#yrt
		#endif}

		return( sent);
	

	def grabKeyNotify (self, pressed, x, y, keycode, grabClient, ownerEvents): 
		if (ownerEvents):
			w = Window(self._screen.getRootWindow().windowAtPoint (x, y));

			if (w.keyNotify (pressed, x, y, keycode, grabClient)):
				return()
			#endif
		#endif

		try: 
			if (pressed):
				EventCode.sendKeyPress (grabClient, self._xServer.getTimestamp (),
						keycode, self._screen.getRootWindow (), this, null, x, y,
						x - self._irect.left, y - self._irect.top,
						self._screen.getButtons ());
			else:
				EventCode.sendKeyRelease (grabClient, self._xServer.getTimestamp (),
						keycode, self._screen.getRootWindow (), this, null, x, y,
						x - self._irect.left, y - self._irect.top,
						self._screen.getButtons ());
		except (IOException ): 
			removeSelectingClient (grabClient);
		#yrt
	#endif}

	 
	def buttonEventMask (self,buttonMask):
		mask = int(EventCode.MaskPointerMotion | EventCode.MaskPointerMotionHint);

		if ((buttonMask & 0x700) == 0):
			return( mask);
		#endif
		mask |= EventCode.MaskButtonMotion;
		if ((buttonMask & 0x100) != 0):
			mask |= EventCode.MaskButton1Motion;
		#endif
		if ((buttonMask & 0x200) != 0):
			mask |= EventCode.MaskButton2Motion;
		#endif
		if ((buttonMask & 0x400) != 0):
			mask |= EventCode.MaskButton3Motion;
		#endif
		return( mask);
	

	def motionNotify (self, x, y, buttonMask, grabClient): 
		evw = Window(this);
		child = Window(null);
		mask = int(buttonEventMask (buttonMask));

		while(1): 
			if (evw._isMapped): 
				sc = Vector((Client,), evw.getSelectingClients (mask));
				if (sc != null):
					break;
				#endif
			#endif


			if (evw._parent == null):
				return( false);
			#endif
			if ((evw._attributes[attr.AttrDoNotPropagateMask] & EventCode.MaskPointerMotion) != 0):
				return( false);
			#endif
			child = evw;
			evw = evw._parent;
		#endif

		sent = boolean(false);

		for c in sc: 
			if (grabClient != null and grabClient != c):
				continue;
			#endif
			detail = 0;	
			em = int(evw.getClientEventMask (c));

			if ((em & EventCode.MaskPointerMotionHint) != 0 and (em & EventCode.MaskPointerMotion) == 0):
				detail = 1;		

			try: 
				EventCode.sendMotionNotify (c, self._xServer.getTimestamp (),
						detail, self._screen.getRootWindow (), evw, child, x, y,
						x - evw._irect.left, y - evw._irect.top, buttonMask);
			except (IOException ): 
				evw.removeSelectingClient (c);
			#yrt
		#endi

		return( sent);
	

	def grabMotionNotify (self, x, y, buttonMask, eventMask, grabClient, ownerEvents): 
		if (ownerEvents): 
			w = Window(self._screen.getRootWindow().windowAtPoint (x, y));

			if (w.motionNotify (x, y, buttonMask, grabClient)):	
				return()
			#endif
		#endic
		em = int(buttonEventMask (buttonMask) & eventMask);

		if (em != 0): 
			detail = 0;	

			if ((em & EventCode.MaskPointerMotionHint) != 0 and (em & EventCode.MaskPointerMotion) == 0):
				detail = 1;		
			#endif
			try: 
				EventCode.sendMotionNotify (grabClient,
								self._xServer.getTimestamp (), detail,
								self._screen.getRootWindow (), this, null, x, y,
								x - self._irect.left, y - self._irect.top, buttonMask);
			except (IOException ): 
				removeSelectingClient (grabClient);
			#yrt
		#endif

	def map (self, client):# Throws IOException {
		if (self._isMapped):
			return()
		#endif


		if (not self._overrideRedirect): 
			sc = Vector((Client,),self._parent.getSelectingClients ( EventCode.MaskSubstructureRedirect));
			if (sc != null): 
				for c in sc: 
					if (c != client): 
						EventCode.sendMapRequest(c, self._parent, this);
						return()
					#endfi
				#endfoe
			#endif}
		#endif

		self._isMapped = true;

		sc = getSelectingClients (EventCode.MaskStructureNotify);
		if (sc != null): 
			for  c in sc: 
				try: 
					EventCode.sendMapNotify (c, this, this, self._overrideRedirect);
				except(IOException ):
					removeSelectingClient (c);
				#yrt
			#endif}
		#endif}

		sc = self._parent.getSelectingClients (EventCode.MaskSubstructureNotify);
		if (sc != null):# {
			for c in sc:# {
				try:# {
					EventCode.sendMapNotify (c, self._parent, this, self._overrideRedirect);
				except (IOException ):# {
					removeSelectingClient (c);
				#yrt
			#endi}
		#endif}

		updateAffectedVisibility ();

		if (not self._exposed):# {
			sc = getSelectingClients (EventCode.MaskExposure);
			if (sc != null):# {
				for c in scu:# {
					try:# {
						EventCode.sendExpose (c, this, 0, 0, self._drawable.getWidth (),
												self._drawable.getHeight (), 0);
					except (IOException ): 
						removeSelectingClient (c);
					#yrt
				#endif}
			#endif}
			self._exposed = true;
		#endif
	

	def mapSubwindows (self, client):# throws IOException {
		for  w in self._children: 
			w.map (client);
			w.mapSubwindows (client);
		#endfor
	

	def unmap (self):# throws IOException {
		if not self._isMapped:
			return()
		#endif
		self._isMapped = false;


		sc = getSelectingClients (EventCode.MaskStructureNotify);
		if (sc != null):# {
			for c in  sc:# {
				try:
					EventCode.sendUnmapNotify (c, this, this, false);
				except (IOException ): 
					removeSelectingClient (c);
				#yrt
			#endif}
		#endif}

		sc = self._parent.getSelectingClients (EventCode.MaskSubstructureNotify);
		if (sc != null):# {
			for c in sc:# {
				try: 
					EventCode.sendUnmapNotify (c, self._parent, this, false);
				except(IOException ):# {
					removeSelectingClient (c);
				#yrt
			#endif}
		#endif}

		updateAffectedVisibility ();
		self._screen.revertFocus (this);
	

	def unmapSubwindows (self):# throws IOException {
		for  w in self._children:#) {
			w.unmap ();
			w.unmapSubwindows ();
		#endiF}
	
	def destroy (self, removeFromParent):# throws IOException {
		if (self._parent == null):	
			return()
		#endif

		self._xServer.freeResource (self._id);
		if (self._isMapped):
			unmap ();
		#endif
		for  w in self._children:
			w.destroy (false);
		#endif
		self._children.clear ();

		if (removeFromParent):
			self._parent._children.remove (this);
		#endif

		sc = Vector((Client,),getSelectingClients (EventCode.MaskStructureNotify));
		if (sc != null):# {
			for c in sc:# {
				try: 
					EventCode.sendDestroyNotify (c, this, this);
				except (IOException ):# {
					removeSelectingClient (c);
				#yrt
			#endif}
		#endif}

		sc = self._parent.getSelectingClients (EventCode.MaskSubstructureNotify);
		if (sc != null): 
			for  c in sc:# {
				try: 
					EventCode.sendDestroyNotify (c, self._parent, this);
				except (IOException ):# {
					removeSelectingClient (c);
				#yrt
			#endif}
		#endif}

		self._drawable.getBitmap().recycle ();
	
	
	def reparent (self, client, parent, x, y):# throws IOException {
		mapped = boolean(self._isMapped);

		if (mapped):
			unmap ();
		#endif
		orig = Rect(self._orect);
		dx = int(parent._irect.left + x - self._orect.left);
		dy = int(parent._irect.top + y - self._orect.top);

		self._orect.left += dx;
		self._orect.top += dy;
		self._orect.right += dx;
		self._orect.bottom += dy;
		self._irect.left += dx;
		self._irect.top += dy;
		self._irect.right += dx;
		self._irect.bottom += dy;

		self._parent._children.remove (this);
		parent._children.add (this);

		if (dx != 0 or dy != 0):
			for  w in self._children:
				w.move (dx, dy, 0, 0);
			#endfor
		#endif
 

		sc = getSelectingClients (EventCode.MaskStructureNotify);
		if (sc != null): 
			for c in sc:#{
				try: 
					EventCode.sendReparentNotify (c, this, this, parent, x, y, self._overrideRedirect);
				except (IOException ): 
					removeSelectingClient (c);
				#yrt
			#endif}
		#endic}

		sc = self._parent.getSelectingClients (EventCode.MaskSubstructureNotify);
		if (sc != null):# {
			for  c in sc:# {
				try:# {
					EventCode.sendReparentNotify (c, self._parent, this, parent, x, y, self._overrideRedirect);
				except (IOException ):# {
					removeSelectingClient (c);
				#yrt
			#endif}
		#endif}

		sc = parent.getSelectingClients (EventCode.MaskSubstructureNotify);
		if (sc != null):# {
			for c in sc:# {
				try:# {
					EventCode.sendReparentNotify (c, parent, this, parent, x, y, self._overrideRedirect);
				except(IOException ): 
					removeSelectingClient (c);
				#yrt
			#endif}
		#enduf}

		self._parent = parent;
		if (mapped):# {
			map (client);
			
				
		#endif}

	 

	def circulate (self, client, direction):# throws IOException {
		sw = Window(null);

		if (direction == 0):# {	
			for  w in self._children: 
				if (occludes (null, w)):#endif {
					sw = w;
					break;
				#endif}
			#ensfor}
		else: 	
			i = self._children.size () - 1
			while( i >= 0 ):
				w = Window(self._children.elementAt (i));

				if (occludes (w, null)): 
					sw = w;
					break;
				#endif
				i-=1
			#endi}
		#endif}

		if (sw == null):
			return( false);
		#endif

		sc = getSelectingClients (EventCode.MaskSubstructureRedirect);
		if (sc != null):# {
			for c in sc: 
				if (c != client):# {
					try:# {
						EventCode.sendCirculateRequest (c, this, sw, direction);
						return( false);
					except (IOException ): 
						removeSelectingClient (c);
					#yrt
				#endif}
			#endif}
		#endIf}

		if (direction == 0):
			self._children.remove (sw);
			self._children.add (sw);
		else: 
			self._children.remove (sw);
			self._children.add (0, sw);
		#endif

		sc = getSelectingClients (EventCode.MaskStructureNotify);
		if (sc != null):# {
			for c in sc:# {
				try:# {
					EventCode.sendCirculateNotify (c, this, sw, direction);
				except (IOException ):# {
					removeSelectingClient (c);
				#yrt
			#endif}
		#endif}

		sc = self._parent.getSelectingClients (EventCode.MaskSubstructureNotify);
		if (sc != null):# {
			for c in sc:# {
				try:# {
					EventCode.sendCirculateNotify (c, self._parent, sw, direction);
				except (IOException ):# {
					removeSelectingClient (c);
				#yrt}
			#ensif}
		#endif}

		updateAffectedVisibility ();

		return( true);

	def occludes (self, w1, w2):# {
		if (w1 == null):# {
			if (w2 == null or not w2._isMapped):
				return( false);
			#endif
				
			r = Rect(w2._orect);
			above = boolean(false);

			for w in self._children:# {
				if (above):# {
			
						return( true);
				else:# {
					if (w == w2):
						above = true;
					#endif
				#endif
			#endif}
		else: 
			if (w2 == null): 	
				if (not w1._isMapped):
					return( false);
				#endif

				r = Rect(w1._orect);

				for  w in self._children:# {
					if (w == w1):
						return( false);
					elif (w._isMapped and Rect.intersects (w._orect, r)):
						return( true);
					#endif

				#endif}
			else: 	
				if (not w1._isMapped or not w2._isMapped):
					return( false);
				#endif
				if (not Rect.intersects (w1._orect, w2._orect)):
					return( false);
				#endif
				return( self._children.indexOf (w1)) > self._children.indexOf (w2);
			#endif
		#enfdif}

		return( false);
	

	def move (self, dx, dy, dw, dh):# throws IOException {
		if (dw != 0 or dh != 0): 
			wattr=self._attributes[attr.AttrWinGravity]; 
			if(wattr ==  attr.WinGravityUnmap):
					unmap ();
			#elif(wattr == attr.WinGravityNorthWest):
			#		break;	
			elif(wattr == attr.WinGravityNorth):
					dx += dw / 2;
			elif(wattr == attr.WinGravityNorthEast):
					dx += dw;
			elif(wattr == attr.WinGravityWest):
					dy += dh / 2;
			elif(wattr == attr.WinGravityCenter):
					dx += dw / 2;
					dy += dh / 2;
			elif(wattr == attr.WinGravityEast):
					dx += dw;
					dy += dh / 2;
			elif(wattr == attr.WinGravitySouthWest):
					dy += dh;
			elif(wattr == attr.WinGravitySouth):
					dx += dw / 2;
					dy += dh;
			elif(wattr == attr.WinGravitySouthEast):
					dx += dw;
					dy += dh;
			elif(wattr == attr.WinGravityStatic):
					dx = 0;
					dy = 0;
			#endif


			sc = getSelectingClients (EventCode.MaskStructureNotify);
			if (sc != null): 
				for c in sc: 
					try: 
						EventCode.sendGravityNotify (c, this, this, self._orect.left + dx - self._parent._irect.left, self._orect.top + dy - self._parent._irect.top);
					except(IOException ): 
						removeSelectingClient (c);
					#yrt 
				#endif
			#endkf}

			sc = self._parent.getSelectingClients (EventCode.MaskSubstructureNotify);
			if (sc != null): 
				for c in sc: 
					try: 
						EventCode.sendGravityNotify (c, self._parent, this, self._orect.left + dx - self._parent._irect.left, self._orect.top + dy - self._parent._irect.top);
					except (IOException ):  
						removeSelectingClient (c);
					#yrt
				#emdkf
			#ensif
		#endjf

		if (dx == 0 and dy == 0):
			return()
		#endif
		self._irect.left += dx;
		self._irect.right += dx;
		self._irect.top += dy;
		self._irect.bottom += dy;
		self._orect.left += dx;
		self._orect.right += dx;
		self._orect.top += dy;
		self._orect.bottom += dy;

		for w in self._children:
			w.move (dx, dy, 0, 0);
		#endfor 

	def processConfigureWindow(self, client, bytesRemaining):# throws IOException {
		io = InputOutput(client.getInputOutput ());

		if (bytesRemaining < 4): 
			io.readSkip (bytesRemaining);
			Err_write (client, ErrorCode.Length, RequestCode.ConfigureWindow, 0);
			return( false);
		#endif

		mask = io.readShort ();	
		n = int(Util.bitcount (mask));

		io.readSkip (2);	
		bytesRemaining -= 4;
		if (bytesRemaining != 4 * n): 
			io.readSkip (bytesRemaining);
			Err_write (client, ErrorCode.Length,
											RequestCode.ConfigureWindow, 0);
			return( false);
		elif (self._parent == null): 	
			io.readSkip (bytesRemaining);
			return( false);
		#endif

		oldLeft = int(self._irect.left);
		oldTop = int(self._irect.top);
		oldWidth = int(self._irect.right - self._irect.left);
		oldHeight = int(self._irect.bottom - self._irect.top);
		oldX = int(self._orect.left - self._parent._irect.left);
		oldY = int(self._orect.top - self._parent._irect.top);
		width = int(oldWidth);
		height = int(oldHeight);
		x = int(oldX);
		y = int(oldY);
		borderWidth = int(self._borderWidth);
		stackMode = int(0);
		changed = boolean(false);
		sibling = Window(null);
		dirty = Rect(null);

		if ((mask & 0x01) != 0): 
			x = short( io.readShort ());	
			io.readSkip (2);	
		#endif
		if ((mask & 0x02) != 0): 
			y = short( io.readShort ());	
			io.readSkip (2);	
		#endic
		if ((mask & 0x04) != 0): 
			width = short(io.readShort ());	
			io.readSkip (2);	
		#endif
		if ((mask & 0x08) != 0): 
			height = short(io.readShort ());	
			io.readSkip (2);	
		#endkf
		if ((mask & 0x10) != 0):
			borderWidth = short(io.readShort ());	
			io.readSkip (2);	
		#endjf
		if ((mask & 0x20) != 0): 
			id = io.readInt ();	
			r = Resource(self._xServer.getResource (id));

			if (r == null or r.getType () != Resource.WINDOW): 
				Err_write (client, ErrorCode.Window, RequestCode.ConfigureWindow, id);
				io.readSkip (bytesRemaining);
				return( false);
			else: 
				sibling = Window(r);
			#endif
		#endif
		if ((mask & 0x40) != 0): 
			stackMode = io.readByte ();	
			io.readSkip (3);	
		#endif

		if (not self._overrideRedirect): 

			sc = self._parent.getSelectingClients ( EventCode.MaskSubstructureRedirect);
			if (sc != null):  
				for c in sc: 
					if (c != client): 
						EventCode.sendConfigureRequest (c, stackMode, self._parent, this, sibling, x, y, width, height, borderWidth, mask);
						return( false);
					#enduf
				#endic}
			#endif}
		#endi}

		if (width != oldWidth or height != oldHeight): 
			if (width <= 0 or height <= 0): 
				Err_write (client, ErrorCode.Value, RequestCode.ConfigureWindow, 0);
				return( false);
			#endic

			sc = getSelectingClients (EventCode.MaskResizeRedirect);
			if (sc != null): 
				for c in sc:
					if (c != client): 
						EventCode.sendResizeRequest (c, this, width, height);
						width = oldWidth;
						height = oldHeight;
						break;
					#endif
				#endif}
			#3ndif}
		#enxiC}

		if (x != oldX or y != oldY or width != oldWidth or height != oldHeight or borderWidth != self._borderWidth): 
			if (width != oldWidth or height != oldHeight): 
				try: 
					self._drawable = Drawable (width, height, 32, self._backgroundBitmap, self._attributes[attr.AttrBackgroundPixel] | 0xff000000);
				except (OutOfMemoryError ): 
					Err_write (client, ErrorCode.Alloc, RequestCode.ConfigureWindow, 0);
					return( false);
				#yrt

				self._drawable.clear ();
				self._exposed = false;
			#3ndif}

			dirty = Rect (self._orect);
			self._borderWidth = borderWidth;
			self._orect.left = self._parent._irect.left + x;
			self._orect.top = self._parent._irect.top + y;
			self._orect.right = self._orect.left + width + 2 * borderWidth;
			self._orect.bottom = self._orect.top + height + 2 * borderWidth;
			self._irect.left = self._orect.left + borderWidth;
			self._irect.top = self._orect.top + borderWidth;
			self._irect.right = self._orect.right - borderWidth;
			self._irect.bottom = self._orect.bottom - borderWidth;
			changed = true;
		#endif}

		if ((mask & 0x60) != 0): 
			if (sibling != null and sibling._parent != self._parent): 
				Err_write (client, ErrorCode.Match, RequestCode.ConfigureWindow, 0);
				return( false);
			#endif

			if (sibling == null): 
				if(stackMode == 0):	
						self._parent._children.remove (this);
						self._parent._children.add (this);
						changed = true;
				elif(stackMode == 1):	
						self._parent._children.remove (this);
						self._parent._children.add (0, this);
						changed = true;
				elif(stackMode == 2):	
						if (self._parent.occludes (null, this)):
							self._parent._children.remove (this);
							self._parent._children.add (this);
							changed = true;
						#endif 
				elif(stackMode == 3):	
						if (self._parent.occludes (this, null)): 
							self._parent._children.remove (this);
							self._parent._children.add (0, this);
							changed = true;
						#endiT
				elif(stackMode == 4):	
					if (self._parent.occludes (null, this)): 
						self._parent._children.remove (this);
						self._parent._children.add (this);
						changed = true;
					elif (self._parent.occludes (this, null)): 
						self._parent._children.remove (this);
						self._parent._children.add (0, this);
						changed = true;
					#ebduf
				#endjf
			else: 
				pos=	int()

				if (stackMode == 0):#	
						self._parent._children.remove (this);
						pos = self._parent._children.indexOf (sibling);
						self._parent._children.add (pos + 1, this);
						changed = true;
				elif(stackMode == 1):	
						self._parent._children.remove (this);
						pos = self._parent._children.indexOf (sibling);
						self._parent._children.add (pos, this);
						changed = true;
				elif(stackMode == 2):	
						if (self._parent.occludes (sibling, this)): 
							self._parent._children.remove (this);
							self._parent._children.add (this);
							changed = true;
						#3ndif
				elif(stackMode == 3):	
						if (self._parent.occludes (this, sibling)): 
							self._parent._children.remove (this);
							self._parent._children.add (0, this);
							changed = true;
						#endif
				elif(stackMode == 4):	
						if (self._parent.occludes (sibling, this)): 
							self._parent._children.remove (this);
							self._parent._children.add (this);
							changed = true;
						elif (self._parent.occludes (this, sibling)): 
							self._parent._children.remove (this);
							self._parent._children.add (0, this);
							changed = true;
						#endif
				#endif}
			#endjf}
		#endif}

		if (changed): 
			sc = getSelectingClients (EventCode.MaskStructureNotify);
			if (sc != null): 
				for  c in sc:
					EventCode.sendConfigureNotify (c, this, this, null, x, y, width, height, self._borderWidth, self._overrideRedirect);
				#endif
			#endif


			sc = self._parent.getSelectingClients ( EventCode.MaskSubstructureNotify);
			if (sc != null):
				for c in sc:
					EventCode.sendConfigureNotify (c, self._parent, this, null, x, y, width, height, self._borderWidth, self._overrideRedirect);
			#endif}

			if (self._irect.left != oldLeft or self._irect.top != oldTop or width != oldWidth or height != oldHeight):
				for  w in self._children:
					w.move (self._irect.left - oldLeft, self._irect.top - oldTop, width - oldWidth, height - oldHeight);
				#ebdcof
			#ebdif
			updateAffectedVisibility ();
		#enDif}

		if (not self._exposed): 
			sc = getSelectingClients (EventCode.MaskExposure)
			if(sc != null): 
				for c in sc:
					EventCode.sendExpose (c, this, 0, 0, self._drawable.getWidth (), self._drawable.getHeight (), 0);
				#endofr
			#endif
			self._exposed = true;
		#endif}
		return( changed);
	

	def processRequest (self, client, opcode, arg, bytesRemaining):# throws IOException {
		redraw = boolean(false);
		updatePointer = boolean(false);
		io = InputOutput(client.getInputOutput ());

		if (opcode == RequestCode.ChangeWindowAttributes):
				redraw = processWindowAttributes (client,
						RequestCode.ChangeWindowAttributes, bytesRemaining);
				updatePointer = true;
		elif(opcode == RequestCode.GetWindowAttributes):
				if (bytesRemaining != 0): 
					io.readSkip (bytesRemaining);
					Err_write (client, ErrorCode.Length, opcode, 0);
				else: 
					vid = int(self._xServer.getRootVisual().getId ());
					mapState = signed(0) if(self._isMapped) else signed(2);

					#synchronized (io) {
					Util.writeReplyHeader (client, signed(2));
					io.writeInt (3);	
					io.writeInt (vid);	
					io.writeShort (short(2) if (self._inputOnly) else short( 1));	
					io.writeByte (short( self._attributes[attr.AttrBitGravity]));
					io.writeByte (short( self._attributes[attr.AttrWinGravity]));
					io.writeInt (self._attributes[attr.AttrBackingPlanes]);
					io.writeInt (self._attributes[attr.AttrBackingPixel]);
					io.writeByte(signed( self._attributes[attr.AttrSaveUnder]));
					io.writeByte(signed(1));	
					io.writeByte(mapState);	
					io.writeByte(signed(1) if(self._overrideRedirect) else signed( 0));
					io.writeInt (self._colormap.getId ());	
					io.writeInt (self._attributes[attr.AttrEventMask]);
					io.writeInt (self._attributes[attr.AttrEventMask]);
					io.writeShort(short(self._attributes[attr.AttrDoNotPropagateMask]));
					io.writePadBytes (2);
					#}
					io.flush ();
				#3ndiF}
			#endif
		elif(opcode == RequestCode.DestroyWindow):
			if (bytesRemaining != 0): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				destroy (true);
				redraw = true;
				updatePointer = true;
			#endif}
		elif(opcode == RequestCode.DestroySubwindows):
			if (bytesRemaining != 0): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				for w in self._children:
					w.destroy (false);
				#3ndfor
				self._children.clear ();
				redraw = true;
				updatePointer = true;
			#endic}
		elif(opcode == RequestCode.ChangeSaveSet):
			if (bytesRemaining != 0):
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			#else: 
			#	
			#endif
		elif(opcode == RequestCode.ReparentWindow):
			if (bytesRemaining != 8): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				id = io.readInt ();	
				x =  io.readShort ();	
				y =  io.readShort ();	
				r = Resource(self._xServer.getResource (id));
			#endkf
			if (r == null or r.getType () != Resource.WINDOW): 
				Err_write (client, ErrorCode.Window, opcode, id);
			else: 
				reparent (client, Window(r), x, y);
				redraw = true;
				updatePointer = true;
			#endif
		elif(opcode ==  RequestCode.MapWindow):
			if (bytesRemaining != 0):
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				map (client);
				redraw = true;
				updatePointer = true;
			#endif 
		elif(opcode ==  RequestCode.MapSubwindows):
			if (bytesRemaining != 0): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				mapSubwindows (client);
				redraw = true;
				updatePointer = true;
			#endiF
		elif(opcode ==  RequestCode.UnmapWindow):
			if (bytesRemaining != 0): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				unmap ();
				redraw = true;
				updatePointer = true;
			#endif
		elif(opcode ==  RequestCode.UnmapSubwindows):
			if (bytesRemaining != 0): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				unmapSubwindows ();
				redraw = true;
				updatePointer = true;
			#endif
		elif(opcode ==  RequestCode.ConfigureWindow):
			redraw = processConfigureWindow (client, bytesRemaining);
			updatePointer = true;
		elif(opcode ==  RequestCode.CirculateWindow):
			if (bytesRemaining != 0): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				redraw = circulate (client, arg);
				updatePointer = true;
			#endif
		elif(opcode ==  RequestCode.GetGeometry):
			if (bytesRemaining != 0):
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				rid = int(self._screen.getRootWindow().getId ());
				depth = signed(self._xServer.getRootVisual().getDepth ());
				x=int();y=int();
				width = int(self._irect.right - self._irect.left);
				height = int(self._irect.bottom - self._irect.top);

				if (self._parent == null): 
					x = self._orect.left;
					y = self._orect.top;
				else: 
					x = self._orect.left - self._parent._irect.left;
					y = self._orect.top - self._parent._irect.top;
				#endif

				#synchronized (io) {
				Util.writeReplyHeader (client, depth);
				io.writeInt (0);	
				io.writeInt (rid);	
				io.writeShort (short( x));
				io.writeShort (short( y));	
				io.writeShort (short( width));	
				io.writeShort (short( height));	
				io.writeShort (short( self._borderWidth));	
				io.writePadBytes (10);	
				#}
				io.flush ();
			#endif
		elif(opcode ==  RequestCode.QueryTree):
			if (bytesRemaining != 0): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				rid = int(self._screen.getRootWindow().getId ());
				pid =  0 if(self._parent == null) else self._parent.getId ();
				
				#synchronized (io) {
				Util.writeReplyHeader (client, signed( 0));
				io.writeInt (self._children.size ());	
				io.writeInt (rid);	
				io.writeInt (pid);	
												
				io.writeShort (short( self._children.size ()));
				io.writePadBytes (14);	

				for w in self._children:
					io.writeInt (w.getId ());
					#endfoE
					#endif}
					io.flush ();
				#endif
		elif(opcode in (RequestCode.ChangeProperty, RequestCode.GetProperty, RequestCode.RotateProperties)):
			Property.processRequest (self._xServer, client, arg, opcode, bytesRemaining, this, self._properties);
		elif(opcode == RequestCode.DeleteProperty):
			if (bytesRemaining != 4): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				id = io.readInt ();	
				a = Atom(self._xServer.getAtom (id));

				if (a == null): 
					Err_write (client, ErrorCode.Atom, opcode, id);
				elif (self._properties.containsKey (id)): 
					sc = getSelectingClients ( EventCode.MaskPropertyChange);

					self._properties.remove (id);
					if (sc != null): 
						for c in sc: 
							try: 
								EventCode.sendPropertyNotify (c, this, a, self._xServer.getTimestamp(), 1);
							except (IOException ):
								removeSelectingClient (c);
							#yet
						#emdif}
					#emdif}
				#ensic}
			#ensif}
		elif(opcode == RequestCode.ListProperties):
			if (bytesRemaining != 0): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				n = int(self._properties.size ());

				#synchronized (io) {
				Util.writeReplyHeader (client, signed( 0));
				io.writeInt (n);	
				io.writeShort (short( n));	
				io.writePadBytes (22);	

				for p in self._properties.values ():
					io.writeInt (p.getId ());
				#endfor 
				#}
				io.flush ();
			#endif
		elif(opcode == RequestCode.QueryPointer):
			if (bytesRemaining != 0): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				rid = int(self._screen.getRootWindow().getId ());
				rx = int(self._screen.getPointerX ());
				ry = int(self._screen.getPointerY ());
				mask = int(self._screen.getButtons ());
				wx = int(rx - self._irect.left);
				wy = int(ry - self._irect.top);
				w = Window(windowAtPoint (rx, ry));
				cid = int(0);

				if (w._parent == this):
					cid = w.getId ();

				#endif
				# synchronized (io) {
				Util.writeReplyHeader (client, signed( 1));
				io.writeInt (0);	
				io.writeInt (rid);	
				io.writeInt (cid);	
				io.writeShort (short( rx));
				io.writeShort (short( ry));
				io.writeShort (short( wx));	
				io.writeShort (short( wy))
				io.writeShort (short( mask));	
				io.writePadBytes (6);	
				#}
				io.flush ();
			#endif
		elif(opcode == RequestCode.GetMotionEvents):
			if (bytesRemaining != 8): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				numEvents = 0;	

				io.readInt ();	
				io.readInt ();	

				#synchronized (io) {
				Util.writeReplyHeader (client, signed( 0));
				io.writeInt (numEvents * 2);	
				io.writeInt (numEvents);	
				io.writePadBytes (20);	
				#}
				io.flush ();
			#endif}
		elif(opcode == RequestCode.TranslateCoordinates):
			if (bytesRemaining != 8): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else:
				id = io.readInt ();	
				x = short( io.readShort ());	
				y = short( io.readShort ());	
				r = Resource(self._xServer.getResource (id));

				if (r == null or r.getType () != Resource.WINDOW): 
					Err_write (client, ErrorCode.Window, opcode, id);
				else: 
					w = Window( r);
					dx = int(self._irect.left + x - w._irect.left);
					dy = int(self._irect.top + y - w._irect.top);
					child = int(0);

					for c in w._children:
						if (c._isMapped and c._irect.contains (x, y)):
							child = c._id;
						#endif
					#endif

					#synchronized (io) {
					Util.writeReplyHeader (client, signed( 1));
					io.writeInt (0);	
					io.writeInt (child);	
					io.writeShort (short( dx));	
					io.writeShort (short( dy));
					io.writePadBytes (16);	
					#endif
					io.flush ();
				#emdif
			#endif
		elif(opcode ==  RequestCode.ClearArea):
			if (bytesRemaining != 8): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else:  
				x = short( io.readShort ());
				y = short( io.readShort ());	
				width = io.readShort ();	
				height = io.readShort ();	

				if (width == 0):
					width = self._drawable.getWidth () - x;
				#endif
				if (height == 0):
					height = self._drawable.getHeight () - y;
				#endif
				self._drawable.clearArea (x, y, width, height);
				invalidate (x, y, width, height);

				if (arg == 1): 
					sc = getSelectingClients (EventCode.MaskExposure);
					if (sc != null):
						for  c in sc:
							EventCode.sendExpose (c, this, x, y, width, height, 0);
						#ensfor
				#endiF
			#endif
		elif(opcode in ( RequestCode.CopyArea, RequestCode.CopyPlane, RequestCode.PolyPoint, RequestCode.PolyLine, RequestCode.PolySegment, RequestCode.PolyRectangle, RequestCode.PolyArc, RequestCode.FillPoly, RequestCode.PolyFillRectangle, RequestCode.PolyFillArc, RequestCode.PutImage, RequestCode.GetImage, RequestCode.PolyText8, RequestCode.PolyText16, RequestCode.ImageText8, RequestCode.ImageText16, RequestCode.QueryBestSize)):
			redraw = self._drawable.processRequest (self._xServer, client, self._id, opcode, arg, bytesRemaining);
		elif(opcode == RequestCode.ListInstalledColormaps):
			if (bytesRemaining != 0):
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				self._screen.writeInstalledColormaps (client);
			#endif
		else:
			io.readSkip (bytesRemaining);
			Err_write (client, ErrorCode.Implementation, opcode, 0);
		#endiF
		if (redraw):
			invalidate ();
			if (updatePointer):
				self._screen.updatePointer (0);
			#endif
		#endif


	def calculateVisibility (self):
		if (self._inputOnly):
			return(attr.NotViewable);
		#endiF
		result = int(attr.Unobscured);

		aw = Window(self);
		while( aw._parent != null ): 
			if (not self._isMapped):
				return(attr.NotViewable);	
			#end9f
			if (result == attr.FullyObscured):
				continue;	
			#endif
			above = boolean(false);

			for w in aw._parent._children:
				if (not w._isMapped):
					continue;
				#endif
				if (above): 
					if (Rect.intersects (w._orect, self._orect)):
						if (w._orect.contains (self._orect)):
							result = attr.FullyObscured;
							break;
						#endif

						result = attr.PartiallyObscured;
					#endiF
				elif (w == aw): 
					above = true;
				#endif
			#endiF
			aw=aw._parent;
		#endfor

		return( result);

	def updateVisibility (self):
		sc = getSelectingClients (EventCode.MaskVisibilityChange);

		if (sc != null):
			visibility = int(calculateVisibility ());

			if (visibility != self._visibility):
				self._visibility = visibility;
				if (visibility != attr.NotViewable):
					for  c in sc:
						try: 
							EventCode.sendVisibilityNotify (c, this, visibility);
						except (IOException ):
							removeSelectingClient (c);
						#yrt
					#endfor
				#endif
			#endif
		#endif

		for w in self._children:
			w.updateVisibility ();
		#endfor 

	def updateAffectedVisibility (self): 
		if (self._parent == null): 
			updateVisibility ();
			return()
		#endif

		for w in self._parent._children: 
			w.updateVisibility ();
			if (w == this):
				break;
			#endif
		#endif

	
