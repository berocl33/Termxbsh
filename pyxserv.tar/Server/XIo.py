
import socket



class InputOutput:
 PadBytes=bytes([0]*0x20)
 _msb=False;_inStream=_outStream=None
 def __init__(self,inp=None,outp=None):
  if(not outp):
   outp=inp;
  self._inStream=inp;self._outStream=outp

 def new(self,inp,outp=None):
  if(not outp):
   outp=inp;
  self._inStream=inp;self._outStream=outp

 def write(self,*x):
  if(not hasattr(self._outStream,"write")):
   return self._outStream.send(bytes(x) if(isinstance(x[0],(int))) else bytes(x) if(len(x)>1) else bytes(x[0]))
  return(self._outStream.write(*x))

 def read(self,*x):
  if(not hasattr(self._inStream,"read")):
   return self._inStream.recv(x[0])
  return(self._inStream.read(*x))
 def setMSB(self,L):
  self._msb=not not L

 def readBytes(self,ba,offset,length):
  if(not isinstance(offset,(int))):
   offset=0
  [ba.insert(offset+a,self.read(1)) for a in range(length)]

 def readByte(self,ba=1,offset=None,length=None,bits=True):
  if not length:
   length=1
   return [chr,ord][[False,True].index(bits)](self.read(1))

 def readBits(self,ba,offset,length=None): 
  if(not isinstance(offset,(int))):
   offset=0;
  for l in range(length):
   x=self.readByte(bits=True)
   for s in range(4):
    ba[s+offset]=1 if x&(1<<s)!=0 else 0;
  return ba;

 def readShort(self):
  n=self.readByte(bits=True)
  if(not self._msb):
   return(n|(self.readByte(bits=True)<<8))
  else:
   return((n<<8)|self.readByte(bits=True))

 def readInt(self):
  return(sum([n<<[24-8*a,8*a][[False,True].index(self._msb)] for a in range(4) for n in (self.readByte(bits=True),)]))
 def readLong(self):
  return(sum([n<<[56-8*a,8*a][[False,True].index(self._msb)] for a in range(8) for n in (self.readByte(bits=True),)]))
 def readSkip(self,length):
  self.read(length);

 def writeBytes(self,ba,offset,length):
  self.write(ba[offset:offset+length])
  return(length);
 def writeByte(self,b):
  self.write(b) 
 def writeShort(self,b):
  if(self._msb):
   self.write((b&0xff00)>>8);
   self.write((b&0xff))
  else:
   self.write(b&0xff);
   self.write((b&0xff00)>>8)
 def writeInt(self,b):
  if(self._msb): 
   self.write((b&0xff000000)>>24);
   self.write((b&0xff0000)>>16);
   self.write((b&0xff00)>>8);
   self.write((b&0xff));
  else:
   self.write((b&0xff));
   self.write((b&0xff00)>>8);
   self.write((b&0xff0000)>>16);
   self.write((b&0xff000000)>>24);
 def writeLong(self,b):
  if(self._msb): 
   self.write((b&0xff000000000000)>>56);
   self.write((b&0xff0000000000)>>48);
   self.write((b&0xff00000000)>>32);
   self.write((b&0xff000000)>>24);
   self.write((b&0xff0000)>>16);
   self.write((b&0xff00)>>8);
   self.write((b&0xff));
  else:
   self.write((b&0xff));
   self.write((b&0xff00)>>8);
   self.write((b&0xff0000)>>16);
   self.write((b&0xff000000)>>24);
   self.write((b&0xff00000000)>>32);
   self.write((b&0xff0000000000)>>48);
   self.write((b&0xff000000000000)>>56);

 def writePadBytes(self,length,b=None):
  if(length>len(self.PadBytes)):
   l=int(length/len(self.PadBytes));
   while(l>0 and qlen(self.PadBytes)==self.writeBytes(self.PadBytes,0,len(self.PadBytes))):
    l-=1;
   #end
  #end
  if(length%len(self.PadBytes)>0):
   self.writeBytes(self.PadBytes,0,length%len(self.PadBytes))
  #endif
 def flush(self):
  if(hasattr(self._outStream,"flush")):
   self._outStream.flush()

