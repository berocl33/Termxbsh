
from XUtil import *

EventBase = 54

class XGL: 
    QueryVersion = 0;


    def processRequest(c, client, opcode, arg, bytesRemaining):
        io = client.getInputOutput();

        if (opcode==QueryVersion):
                if (bytesRemaining != 0): 
                    io.readSkip(bytesRemaining);
                    Err_writeWithMinorOpcode(client, ErrorCode.Length, arg, opcode, 0);
                else: 
                    #synchronized (io) {
                    writeReplyHeader(client, arg);
                    io.writeInt(0);    #// Reply length.
                    io.writeShort( 1);    #// Shape major.
                    io.writeShort( 1);    #// Shape minor.
                    io.writePadBytes(20);
                    #}
                    io.flush();
                #endi
                Err_write(client, ErrorCode.Implementation, opcode, 0);
        
    
