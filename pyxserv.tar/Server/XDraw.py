null=None
from XUtil import * 
from XIo import InputOutput
 
class Drawable(): 
	_bitmap=null#Bitmap();
	_canvas=null#Canvas();
	_depth = int();
	_backgroundBitmap = Bitmap();
	_backgroundColor = int();
	_shapeMask = []#boolean);

	BITMAP_FORMAT= signed(0);
	XY_PIXMAP_FORMAT= signed(1);
	Z_PIXMAP_FORMAT= signed(2);

	 
	def __init__ (self, width, height, depth, bgbitmap, bgcolor): 
		self._bitmap = Bitmap(width=width, height=height);#, Bitmap.Config.ARGB_8888);
		self._canvas = Canvas (self._bitmap);
		self._depth = depth;
		self._backgroundBitmap = bgbitmap;
		self._backgroundColor = bgcolor;
	

	def getWidth (self):
		return( self._bitmap.getWidth ());

	def getHeight (self):
		return( self._bitmap.getHeight ());

	def getDepth (self):
		return( self._depth);

	def getBitmap (self):
		return( self._bitmap);

	def setBackgroundColor (self, color): 
		self._backgroundColor = color;

	def setBackgroundBitmap (self, bitmap): 
		self._backgroundBitmap = bitmap;
	

	def processRequest (self, xServer, client, id, opcode, arg, bytesRemaining):# throws IOException {
		changed= false;
		io= client.getInputOutput ();
		if (opcode == RequestCode.CopyArea):
				if (bytesRemaining != 20): 
					io.readSkip (bytesRemaining);
					Err_write (client, ErrorCode.Length, opcode, 0);
				else: 
					did = io.readInt ();	# Dest drawable.
					gcid = io.readInt ();	# GC.
					sx = short( io.readShort ());	# Src X.
					sy = short( io.readShort ());	# Src Y.
					dx = short( io.readShort ());	# Dst X.
					dy = short( io.readShort ());	# Dst Y.
					width = io.readShort ();	# Width.
					height = io.readShort ();	# Height.
					r1 = xServer.getResource (did);
					r2 = xServer.getResource (gcid);

					if (r1 == null or not r1.isDrawable ()):
						Err_write (client, ErrorCode.Drawable, opcode, did);
					elif (r2 == null or r2.getType () != Resource.GCONTEXT):
						Err_write (client, ErrorCode.GContext, opcode, gcid);
					elif (width > 0 and height > 0):
						copyArea (sx, sy, width, height, r1, dx, dy, GContext( r2));
					#endiF
				#endiF
			#endif
		elif (opcode == RequestCode.CopyPlane):
			if (bytesRemaining != 24):
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, id);
			else: 
				did = io.readInt ();	# Dest drawable.
				gcid = io.readInt ();	# GC.
				sx = short( io.readShort ());	# Src X.
				sy = short( io.readShort ());	# Src Y.
				dx = short( io.readShort ());	# Dst X.
				dy = short( io.readShort ());	# Dst Y.
				width = io.readShort ();	# Width.
				height = io.readShort ();	# Height.
				bitPlane = io.readInt ();	# Bit plane.
				r1 = xServer.getResource (did);
				r2 = xServer.getResource (gcid);

				if (r1 == null or not r1.isDrawable ()):
					Err_write (client, ErrorCode.Drawable, opcode, did);
				elif (r2 == null or r2.getType () != Resource.GCONTEXT):
					Err_write (client, ErrorCode.GContext, opcode, gcid);
				else: 
					if (self._depth != 32):
						copyPlane (sx, sy, width, height, bitPlane, r1, dx, dy, GContext( r2));
					else:
						copyArea (sx, sy, width, height, r1, dx, dy, GContext( r2));
					#endif
				#endiF
			#endiF
		elif opcode == RequestCode.GetImage:
			if (bytesRemaining != 12):
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				processGetImageRequest (client, arg);
			#endiF
		elif opcode == RequestCode.QueryBestSize:
			if (bytesRemaining != 4):
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				width = io.readShort ();	# Width.
				height = io.readShort ();	# Height.

				#synchronized (io) {
				Util.writeReplyHeader (client, signed( 0));
				io.writeInt (0);	# Reply length.
				io.writeShort (short( width));	# Width.
				io.writeShort (short( height));	# Height.
				io.writePadBytes (20);	# UnUsed.
				#}
				io.flush ();
			#endif
		elif (opcode in (RequestCode.PolyPoint, RequestCode.PolyLine, RequestCode.PolySegment, RequestCode.PolyRectangle, RequestCode.PolyArc, RequestCode.FillPoly, RequestCode.PolyFillRectangle, RequestCode.PolyFillArc, RequestCode.PutImage, RequestCode.PolyText8, RequestCode.PolyText16, RequestCode.ImageText8, RequestCode.ImageText16)):
			if (bytesRemaining < 4): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				gcid = io.readInt ();	# GContext.
				r = xServer.getResource (gcid);

				bytesRemaining -= 4;
				if (r == null or r.getType () != Resource.GCONTEXT): 
					io.readSkip (bytesRemaining);
					Err_write (client, ErrorCode.GContext, opcode, 0);

				else: 
					changed = processGCRequest (xServer, client, id, GContext(r), opcode, arg, bytesRemaining);
				#endiF
			#endiF
		else:
			io.readSkip (bytesRemaining);
			Err_write (client, ErrorCode.Implementation, opcode, 0);
		#endiF
		return( changed);


	def processGetImageRequest (self, client, format):# throws IOException {
		io = client.getInputOutput ();
		x = io.readShort ();	# X.
		y = io.readShort ();	# Y.
		width = io.readShort ();	# Width.
		height = io.readShort ();	# Height.
		planeMask = io.readInt ();	# Plane mask.
		wh = width * height;
		n=0; pad=0
		pixels=[]#int);
		bytes = []#signed);

		if (x < 0 or y < 0 or x + width > self._bitmap.getWidth () or y + height > self._bitmap.getHeight ()): 
			Err_write (client, ErrorCode.Match, RequestCode.GetImage, 0);
			return()
		#endiF

		try: 
			pixels = array("i",wh);
		except (OutOfMemoryError): 
			Err_write (client, ErrorCode.Alloc, RequestCode.GetImage, 0);
			return()
		#endif

		self._bitmap.getPixels (pixels, 0, width, x, y, width, height);

		if (format == Z_PIXMAP_FORMAT): 
			n = wh * 3;
		else: # XY_PIXMAP_FORMAT is the only other valid value.
			planes = bitcount (planeMask);
			rightPad = -width & 7;
			xmax = width + rightPad;
			offset = 0;

			n = planes * height * (width + rightPad) / 8;

			try: 
				bytes = array("b",n)#signed();
			except (OutOfMemoryError): 
				Err_write (client, ErrorCode.Alloc, RequestCode.GetImage, 0);
				return()
			

			plane = 31
			while( plane >= 0 ): 
				bit = 1 << plane;

				if ((planeMask & bit) == 0):
					continue;

				b = signed(0);

				yi = 0
				while(yi < height):
					xi=0
					while( xi < xmax):
						b <<= 1;

						if (xi < width and (pixels[yi * width + xi] & bit) != 0):
							b |= 1;

						if ((xi & 7) == 7): 
							offset+=1
							bytes[offset] = b;
							b = 0;
						xi+=1
						#endif 
					yi+=1
					#endif 
				plane-=1
				#endfoR
			#endfoR
		#endiF

		pad = -n & 3;

		#synchronized (io) {
		Util.writeReplyHeader (client, signed( 32));
		io.writeInt ((n + pad) / 4);	# Reply length.
		io.writeInt (0);	# Visual ID.
		io.writePadBytes (20);	# Unused.

		if (format == 2): 
			i = 0
			while( i < wh ):
				n = pixels[i] & planeMask;
				io.writeByte (signed( n & 0xff));
				io.writeByte (signed( (n >> 8) & 0xff));
				io.writeByte (signed((n >> 16) & 0xff));
				i+=1
			#endfor
		else: 
			io.writeBytes (bytes, 0, n);
		#endif

		io.writePadBytes (pad);	# Unused.
		#}
		io.flush ();
	

	def clear (self): 
		if (self._backgroundBitmap == null or self._backgroundBitmap.isRecycled ()): 
			self._bitmap.eraseColor (self._backgroundColor);
		else: 
			width = self._bitmap.getWidth ();
			height = self._bitmap.getHeight ();
			dx = self._backgroundBitmap.getWidth ();
			dy = self._backgroundBitmap.getHeight ();

			y = 0
			while( y < height ): 
				x = 0
				while( x < width ):
					self._canvas.drawBitmap (self._backgroundBitmap, x, y, null);
					x += dx
				#endif
				y+=dy
			#endiF
		#endiF
	

	def clearArea ( x, y, width, height): 
		r = Rect (x, y, x + width, y + height);
		paint = Paint ();

		if (self._backgroundBitmap == null or self._backgroundBitmap.isRecycled ()): 
			paint.setColor (self._backgroundColor);
			paint.setStyle (Paint.Style.FILL);
			self._canvas.drawRect (r, paint);
		else: 
			bw = self._bitmap.getWidth ();
			bh = self._bitmap.getHeight ();
			dx = self._backgroundBitmap.getWidth ();
			dy = self._backgroundBitmap.getHeight ();

			self._canvas.save ();
			self._canvas.clipRect (r);

			iy = 0
			while( iy < bh ): 
				if (iy >= r.bottom):
					break;
				#endiF
				if (iy + dy < r.top):
					continue;
				#endiF

				ix = 0;
				while(ix < bw):
					if (ix >= r.right):
						break;
					#endif
					if (iy + dy < r.left):
						continue;
					#endif

					self._canvas.drawBitmap (self._backgroundBitmap, ix, iy, null);
					ix += dx 
				#endfor
				iy += dy
			#endfor

			self._canvas.restore ();
		#endiF
	

	 
	def copyArea ( sx, sy, width, height, dr, dx, dy, gc):# throws IOException {
		dst=Drawable();

		if (dr.getType () == Resource.PIXMAP):
			dst = Pixmap(dr).getDrawable ();
		else:
			dst = Window( dr).getDrawable ();

		if (sx < 0): 
			width += sx;
			dx -= sx;
			sx = 0;
		#endiF

		if (sy < 0): 
			height += sy;
			dy -= sy;
			sy = 0;
		#endif

		if (sx + width > self._bitmap.getWidth ()): 
			width = self._bitmap.getWidth () - sx;
		#endiF
		if (sy + height > self._bitmap.getHeight ()):
			height = self._bitmap.getHeight () - sy;
		#endif
		if (width <= 0 or height <= 0):
			return()
		#endif
		bm = Bitmap.createBitmap (self._bitmap, sx, sy, width, height);

		dst.self._canvas.drawBitmap (bm, dx, dy, gc.getPaint ());

		if (dr.getType () == Resource.WINDOW):
			Window(dr).invalidate (dx, dy, width, height);

		if (gc.getGraphicsExposure ()):
			EventCode.sendNoExposure (gc.getClient (), dr, RequestCode.CopyArea); 
	
	def copyPlane ( sx, sy, width, height, bitPlane, dr, dx, dy, gc):# throws IOException {
		dst=Drawable();

		if (dr.getType () == Resource.PIXMAP):
			dst = Pixmap(dr).getDrawable ();
		else:
			dst = Window(dr).getDrawable ();

		fg = 0xffffffff if (self._depth == 1) else gc.getForegroundColor ();
		bg = 0 if(self._depth == 1) else gc.getBackgroundColor ();
		pixels = array("i",width * height);

		self._bitmap.getPixels (pixels, 0, width, sx, sy, width, height);
		i = 0
		while( i < pixels.length ):
			pixels[i] = fg if((pixels[i] & bitPlane) != 0) else bg;
		i+=1
		#endfor
		dst.self._canvas.drawBitmap (pixels, 0, width, dx, dy, width, height, true, gc.getPaint ());

		if (dr.getType () == Resource.WINDOW):
			Window(dr).invalidate (dx, dy, width, height);

		if (gc.getGraphicsExposure ()):
			EventCode.sendNoExposure (gc.getClient (), dr, RequestCode.CopyPlane); 
	

	def drawImageText ( s, x, y, gc): 
		paint = gc.getPaint ();
		font = gc.getFont ();
		rect = Rect ();

		font.getTextBounds (s, x, y, rect);
		paint.setColor (gc.getBackgroundColor ());
		paint.setStyle (Paint.Style.FILL);
		self._canvas.drawRect (rect, paint);
		
		paint.setColor (gc.getForegroundColor ());
		self._canvas.drawText (s, x, y, paint);
	

	def processGCRequest ( xServer, client, id, gc, opcode, arg, bytesRemaining):# throws IOException {
		io = client.getInputOutput ();
		paint = gc.getPaint ();
		changed = false;
		originalColor = paint.getColor ();

		self._canvas.save ();
		gc.applyClipRectangles (self._canvas);

		if (opcode == RequestCode.PolyPoint):
			if ((bytesRemaining & 3) != 0): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				points = [float(0)]*(bytesRemaining / 2);
				i = 0;

				while (bytesRemaining > 0): 
					p = float(io.readShort ());
					bytesRemaining -= 2;
					if (arg == 0 or i < 2):# Relative to origin.
						points[i] = p;
					else:
						points[i] = points[i - 2] + p;	# Rel to previous.
					i+=1;
				#endiF

				try: 
					self._canvas.drawPoints (points, paint);
				except (UnsupportedOperationException): 
					i = 0;
					while( i < points.length):
						self._canvas.drawPoint (points[i], points[i + 1], paint);
						i += 2
					#endfor
				#endexc
				changed = true;
			#endif
		elif(opcode == RequestCode.PolyLine):
			if ((bytesRemaining & 3) != 0): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				path = [0.0]*(bytesRemaining/4);#Path ();
				i = 0;

				while (bytesRemaining > 0): 
					x = float(io.readShort ());
					y = float( io.readShort ());

					bytesRemaining -= 4;
					if (i== 0): 
						path[i]=x<<16|int(y);#path.moveTo (x, y);
					elif (arg == 0): 	# Relative to origin.
						path[i]=x<<16|int(y);#path.lineTo (x, y);
					else:	# Relative to previous.
						path[i]=x<<16|int(y);#path.rLineTo (x, y);
					#endiF
					i+=1;
				#endwhile
				paint.setStyle (Paint.Style.STROKE);
				self._canvas.drawPath (path, paint);
				changed = true;
			#endiF
		elif(opcode == RequestCode.PolySegment):
			if ((bytesRemaining & 7) != 0): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				points = [0.0]*(bytesRemaining / 2);
				i = 0;

				while (bytesRemaining > 0): 
					i+=1
					points[i] = short( io.readShort ());
					bytesRemaining -= 2;
				#endwhilE

				self._canvas.drawLines (points, paint);
				changed = true;
			#endiF
		elif(opcode in ( RequestCode.PolyRectangle, RequestCode.PolyFillRectangle)):
			if ((bytesRemaining & 7) != 0): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				if (opcode == RequestCode.PolyRectangle):
					paint.setStyle (Paint.Style.STROKE);
				else:
					paint.setStyle (Paint.Style.FILL);

				while (bytesRemaining > 0): 
					x = float( io.readShort ());
					y = float( io.readShort ());
					width = float(io.readShort ());
					height = fl9at(io.readShort ());

					bytesRemaining -= 8;
					self._canvas.drawRect (x, y, x + width, y + height, paint);
					changed = true;
				#endwhilE
			#endiF
		elif(opcode == RequestCode.FillPoly):
			if (bytesRemaining < 4 or (bytesRemaining & 3) != 0): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				io.readByte ();		# Shape.

				mode = io.readByte ();	# Coordinate mode.
				path=[0]*(bytesRemaining/4-2);
				i = 0;
				io.readSkip (2);	# Unused.
				bytesRemaining -= 4;

				while (bytesRemaining > 0): 
					x = float( io.readShort ());
					y = float( io.readShort ());

					bytesRemaining -= 4;
					if (i == 0):
						path[i]=int(x)<<16|int(y);#path.moveTo (x, y);
					elif (mode == 0):	# Relative to origin.
						path[i]=int(x)<<16|int(y);#path.lineTo (x, y);
					else: 	# Relative to previous.
						path[i]=int(x)<<16|int(y);#path.rLineTo (x, y);
					#endiF
					i+=1;
				#endwhiL

				#path.close ();
				#path.setFillType (gc.getFillType ());
				paint.setStyle (Paint.Style.FILL);
				self._canvas.drawPath (path, paint);
				changed = true;
			#endif
		elif(opcode in ( RequestCode.PolyArc, RequestCode.PolyFillArc)):
			if ((bytesRemaining % 12) != 0): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				useCenter = false;

				if (opcode == RequestCode.PolyArc): 
					paint.setStyle (Paint.Style.STROKE);
				else: 
					paint.setStyle (Paint.Style.FILL);
					if (gc.getArcMode () == 1):		# Pie slice.
						useCenter = true;
					#endiF
				#endiF

				while (bytesRemaining > 0): 
					x = float( io.readShort ());
					y = float( io.readShort ());
					width = float(io.readShort ());
					height = float(io.readShort ());
					angle1 = float( io.readShort ());
					angle2 = float( io.readShort ());
					r = RectF (x, y, x + width, y + height);

					bytesRemaining -= 12;
					self._canvas.drawArc (r, angle1 / -64.0, angle2 / -64.0, useCenter, paint);
					changed = true;
				#endwhilE
			#endiF
		elif(opcode == RequestCode.PutImage):
			changed = processPutImage (client, gc, arg, bytesRemaining);
		elif(opcode in (RequestCode.PolyText8, RequestCode.PolyText16)):
			changed = processPolyText (client, gc, opcode, bytesRemaining);
		elif(opcode == RequestCode.ImageText8):
			if (bytesRemaining != 4 + arg + (-arg & 3)): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				x =  io.readShort ();
				y =  io.readShort ();
				pad = -arg & 3;
				bytes = [signed()]*arg

				io.readBytes (bytes, 0, arg);
				io.readSkip (pad);
				drawImageText (string (bytes), x, y, gc);
				changed = true;
			#endiF
		elif(opcode == RequestCode.ImageText16):
			if (bytesRemaining != 4 + 2 * arg + (-(2 * arg) & 3)): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				x =  io.readShort ();
				y =  io.readShort ();
				pad = (-2 * arg) & 3;
				chars = [string()]*arg;

				i = 0
				while( i < arg ): 
					b1 = io.readByte ();
					b2 = io.readByte ();

					chars[i] = ord((b1 << 8) | b2);
					i+=1
				#endfoR
				io.readSkip (pad);
				drawImageText (string (chars), x, y, gc);
				changed = true;
			#endiF
		else:
			io.readSkip (bytesRemaining);
			Err_write (client, ErrorCode.Implementation, opcode, 0);
		#endif
		if (self._depth == 1):
			paint.setColor (originalColor);
		#endif 
		self._canvas.restore ();		# Undo any clip rectangles.
		return( changed);
	

	def processPutImage (self, client, gc, format, bytesRemaining):# throws IOException {
		io = client.getInputOutput ();

		if (bytesRemaining < 12): 
			io.readSkip (bytesRemaining);
			Err_write (client, ErrorCode.Length, RequestCode.PutImage, 0);
			return( false);
		#endiF

		width = io.readShort ();
		height = io.readShort ();
		dstX = short( io.readShort ());
		dstY = short( io.readShort ());
		leftPad = io.readByte ();
		depth = io.readByte ();
		n=0; pad=0; rightPad=0;

		io.readSkip(2);		# Unused.
		bytesRemaining -= 12;

		badMatch = false;

		if (format == BITMAP_FORMAT):
			if (depth != 1):
				badMatch = true;
		elif (format == XY_PIXMAP_FORMAT):
			if (depth != self._depth):
				badMatch = true;
		elif (format == Z_PIXMAP_FORMAT):
			if (depth != self._depth or leftPad != 0):
				badMatch = true;
		else:	# Invalid format.
			badMatch = true;
		#endiF

		if (badMatch):
			io.readSkip (bytesRemaining);
			Err_write (client, ErrorCode.Match, RequestCode.PutImage, 0);
			return( false);
		#endiF

		isShapeMask = false;

		if (format == Z_PIXMAP_FORMAT):
			rightPad = 0;
			if (depth == 32):
				n = 3 * width * height;
			else: 
				n = (width * height + 7) / 8;
				if (bytesRemaining != n + (-n & 3)):
					isShapeMask = true;
					n = (width + 1) / 2 * height;
				#endiF
			#endiF
		else: 	# XYPixmap or Bitmap.
			rightPad = -(width + leftPad) & 7;
			n = ((width + leftPad + rightPad) * height * depth + 7) / 8;
		#endiF
		pad = -n & 3;

		if (bytesRemaining != n + pad):
			io.readSkip (bytesRemaining);
			Err_write (client, ErrorCode.Length, RequestCode.PutImage, 0);
			return( false);
		#endiF

		colors=[];

		try: 
			colors = array("i",width * height);
		except (OutOfMemoryError ):
			Err_write (client, ErrorCode.Alloc, RequestCode.PutImage, 0);
			return( false);
		#endiF

		if (format == BITMAP_FORMAT):
			fg = gc.getForegroundColor ();
			bg = gc.getBackgroundColor ();
			offset = 0;
			count = 0;
			x = 0;
			y = 0;
			mask = 128;
			val = 0;

			while(1): 
				count+=1
				if ((count & 7) == 0):
					val = io.readByte ();
					mask = 128;
				#endiF

				if (x >= leftPad and x < leftPad + width):
					offset+=1
					colors[offset] = bg if((val & mask) == 0) else fg;

				mask >>= 1;
				x+=1
				if (x == leftPad + width + rightPad):
					x = 0; y+=1;
					if (y == height):
						break;
					#ensif
				#endic
			#endwhilE
		elif (format == XY_PIXMAP_FORMAT):
			planeBit = 1 << (depth - 1);

			i = 0
			while( i < depth):
				offset = 0;
				count = 0;
				x = 0;
				y = 0;
				mask = 128;
				val = 0;
	
				while(1): 
					count+=1
					if ((count & 7) == 0): 
						val = io.readByte ();
						mask = 128;
					#endiF

					if (x >= leftPad and x < leftPad + width):
						offset+=1
						colors[offset] |= 0 if((val & mask) == 0) else planeBit;
	
					mask >>= 1;
					x+=1
					if (x == leftPad + width + rightPad): 
						x = 0;y+=1;
						if (y == height):
							break;
						#endiF
					#endiF
				#endwhilE
				planeBit >>= 1;
				i+=1
			#endwhilE
		elif (depth == 32): 	# 32-bit ZPixmap.
			useShapeMask = (self._shapeMask != null
									and colors.length == self._shapeMask.length);

			i = 0
			while( i < colors.length ):
				b = io.readByte ();
				g = io.readByte ();
				r = io.readByte ();
				alpha = 0 if(useShapeMask and not self._shapeMask[i]) else 0xff000000;
				colors[i] = alpha | (r << 16) | (g << 8) | b;
				i+=1
			#endfoR

			if (useShapeMask):
				self._shapeMask = null;
			#endiF
		elif (isShapeMask): 	# ZPixmap, depth = 1, shape mask.
			self._shapeMask = [boolean()]*colors.length;
			io.readShapeMask (self._shapeMask, width, height);
			io.readSkip (pad);

			return( false);	# Don't redraw.
		else: 	# ZPixmap with depth = 1.
			fg = gc.getForegroundColor ();
			bg = gc.getBackgroundColor ();
			bits = [boolean()]*colors.length;

			io.readBits (bits, 0, colors.length);

			i = 0
			while( i < colors.length):
				colors[i] = fg if(bits[i]) else bg;
				i+=1
			#endfoR
		#endif

		io.readSkip (pad);
		self._canvas.drawBitmap (colors, 0, width, dstX, dstY, width, height, true, gc.getPaint ());

		return( true);
	

	 
	def processPolyText (client, gc, opcode, bytesRemaining):# throws IOException {
		io = client.getInputOutput ();

		if (bytesRemaining < 4): 
			io.readSkip (bytesRemaining);
			Err_write (client, ErrorCode.Length, opcode, 0);
			return( false);
		#endiF

		x = float( io.readShort ());
		y = float( io.readShort ());

		bytesRemaining -= 4;
		while (bytesRemaining > 1): 
			length = io.readByte ();
			minBytes;

			bytesRemaining-=1;
			if (length == 255):		# Font change indicator.
				minBytes = 4;
			elif (opcode == RequestCode.PolyText8):
				minBytes = 1 + length;
			else:
				minBytes = 1 + length * 2;
			#endiF
			if (bytesRemaining < minBytes): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
				return( false);
			#endiF

			if (length == 255): 	# Font change indicator.
				fid = 0;

				i = 0;
				while(i < 4):
					fid = (fid << 8) | io.readByte ();
					i+=1
				#endfoR
				bytesRemaining -= 4;
				if (not gc.setFont (fid)):
					Err_write (client, ErrorCode.Font, opcode, fid);
			else:	# It's a string.
				delta = io.readByte ();
				s=string();

				bytesRemaining-=1;
				if (opcode == RequestCode.PolyText8):
					bytes = [signed()]*length;

					io.readBytes (bytes, 0, length);
					bytesRemaining -= length;
					s = string.join( "",bytes);
				else: 
					chars = [char()]*length;

					i = 0;
					while( i < length):
						b1 = io.readByte ();
						b2 = io.readByte ();

						chars[i] = (char) ((b1 << 8) | b2);
						i+=1
					#endfoR

					bytesRemaining -= length * 2;
					s = string.join ("",chars);
				#endi

				paint = gc.getPaint ();

				x += delta;
				self._canvas.drawText (s, x, y, paint);
				x += paint.measureText (s);
			#endiF
		#endwhilE
		io.readSkip (bytesRemaining);

		return( true);
	

