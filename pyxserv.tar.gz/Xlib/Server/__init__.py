import time,threading;

import XShape,XGL
from XAtom import Atom
from XScreen import Screen
from XUser import Client 
from XIo import InputOutput
from XPeriph import Std
from XExt import Extensions 
from XUtil import *

Keyboard=Std.Key;Pointer=Std

#
# @author Matthew Kwan
#

class XServer: 
	ProtocolMajorVersion = short(11);
	ProtocolMinorVersion = short(0);
	vendor = "Open source";
	ReleaseNumber = int(0);

	_port=int(0)
	_windowManagerClass=String()
	_formats=Hashtable();#Vector(Format)
	_resources=Hashtable();

	_clients=Hashtable();#Vector()
	_clientIdBits = int(20);
	_clientIdStep = int((1 << _clientIdBits));
	_clientIdBase = int(_clientIdStep);
	_host=String()
	_atoms=HashSet();
	_atomNames=HashSet();
	_maxAtomId = int(0);
	_selections=Hashtable();
	_imperviousToServerGrabs=[];
	_keyboard=Std.Key()
	_pointer=Std()
	_defaultFont=Font()
	_rootVisual=Visual()
	_screen = null;
	_fontPath = null;
	_acceptThread = null;
	_timestamp=long()
	_grabClient=null

	_screenSaverTimeout = int(0);
	_screenSaverInterval = int(0);
	_preferBlanking = int(1);
	_allowExposures = int(0);
	_screenSaverTime = long(0);
	

	_accessControlEnabled = boolean(false);
	_accessControlHosts=HashSet()
	_extensions=Vector();

	def __init__( c, host, port, windowManagerClass=""):
		c._host =host;
		c._port = port;
		c._windowManagerClass = windowManagerClass;
		c._formats = Hashtable();#Vector(Format);
		c._resources = Hashtable();
		c._clients = Hashtable();#Vector();
		c._atoms = Hashtable();
		c._atomNames = Hashtable();
		c._selections = Hashtable();
		c._accessControlHosts = HashSet();
		c._extensions = Vector();
		c._extensions.add(("Generic Event Extension", c.Extension(Extensions.XGE, 0, 0)));
		c._extensions.add(("XTEST", c.Extension(Extensions.XTEST, 0, 0)));
		c._extensions.add(("BIG-REQUESTS", c.Extension(Extensions.BigRequests, 0, 0)));
		c._extensions.add(("SHAPE", c.Extension(Extensions.Shape, XShape.EventBase, 0)));
		c._extensions.add(("GLX",c.Extension(Extensions.GLX,XGL.EventBase,0)));
		c._formats.add(Format( 32, 24, 8));

		c._keyboard = Std.Key();
		c._pointer =Std();

		c._defaultFont = Font(1, c, null, null);
		c.addResource(1,c._defaultFont);
		c.addResource(2,Cursor (2, c, null,  null,  null, 0, 1, 0xff000000, 0xffffffff));
		c._screen = Screen(c, 3, c.pixelsPerMillimeter());
		cmap = Colormap (4, c, null, c._screen);
		c._screen.addInstalledColormap(cmap);
		cmap.setInstalled(true);
		c.addResource(4,cmap);
		c.initResources();

		c._rootVisual = Visual(1);
		c._atoms=Atom(-1,"")
		c._atoms.registerPredefinedAtoms(c);
		c._timestamp = time.time();
        
	def initResources(c):
	 c._defaultFont = Font(1, c, null, null);
	 c.addResource(1,c._defaultFont);
	 c.addResource(2,Cursor (2, c, null, null,  null, 0, 1, 0xff000000, 0xffffffff));
	 cmap = Colormap(4,c, null, c._screen);
	 cmap.setInstalled(true);
	 c.addResource(4,map);
	#end

	
	def start(c):
		if (c._acceptThread != null):
			return true;	

		c._acceptThread = threading.Thread (c._host,c._port);
		c._acceptThread.start();
		c.resetScreenSaver();
		return true
	#end

	def stop(c):
		if (c._acceptThread != null):
			c._acceptThread.cancel();
			c._acceptThread = null;
		#end

		c._grabClient = null;
		while (c._clients.size()>0):
			c._clients.get(0).cancel();
		#end

	def resetResources():
	 it = c._resources.keys();
	 while (it.hasMoreElements()): 
	  ik =  it.nextElement();
	  if (ik>c._clientIdBase):
	   c._resources.remove(ik);
	
	 c._resources.entrySet().clear();    
	 c._screen.removeNonDefaultColormaps();
	 if (c._atoms.size() != c._atoms.numPredefinedAtoms()):
	  c._atoms.clear();
	  c._atomNames.clear();
	 #endif
	 c._atoms.registerPredefinedAtoms(c);
	
	 c._selections.clear();
	 c._timestamp = time.time();
	 c.initResources();
	
	def getContext(c):
		return(c._context)

	def getInetAddress(c):
		if (c._acceptThread == null):
			return()

		return c._acceptThread.getInetAddress();
	#end

	 
	def getTimestamp(c):
		diff = long(time.time() - c._timestamp);

		if (diff <= 0):
			return(1)

		return diff;
	#end

	def removeClient (c, client):
		for sel in c._selections.values():
			sel.clearClient(client);
		#end
		c._clients.remove(client);
		if (c._grabClient == client):
			c._grabClient = null;
		#end
		if (client.getCloseDownMode() == Client.Destroy and c._clients.size() == 0):
			c.wakeAgent();	
	#end
	def wakeAgent(c):
	 for c in c._clients:
	  if (c.getCloseDownMode()==Client.Destroy ):
	   c.start(); 
	 #end  

	def grabServer (c, client):
		c._grabClient = client;
	#end

	def ungrabServer (c, client):
		if (c._grabClient == client):
			c._grabClient = null;
	#end

	def processingAllowed (c, client):
		if (c._grabClient == null or client._cid in c._imperviousToServerGrabs):
			return(true)

		return (c._grabClient == client);
	#end

	def getKeyboard(c):
		return c._keyboard;
	#end

	def getPointer(c):
		return c._pointer;
	#end

	def getFontPath(c):
		return c._fontPath
	#end

	def setFontPath (c, path):
		c._fontPath = path;
	#end

	def getScreen(c):
		return c._screen
	#end

	def pixelsPerMillimeter(c):
	 #DisplayMetrics	metrics = DisplayMetrics();
	 #WindowManager	wm =  c._context.getSystemService (Context.WINDOWc._SERVICE);

	 #wm.getDefaultDisplay().getMetrics(metrics);
	 #Font.setDpi ( metrics.ydpi);	
	 return 100; 
	#end

	def getNumFormats(c):
		return c._formats.size()-1;
	#end

	def writeFormats (c, io, f=1):# throws IOException:
		while( f < c._formats.size() ):
		    if(isinstance(c._formats[-f],Format)):
		        c._formats[-f].write(io)
		    else:
		        sf=c._screen._formats.get(1);
		        if(sf): 
		            sf.write(io)
		        #endif
		    #endif
		    f+=1
		#end


	def getDefaultFont(c):
		return c._defaultFont
	#end

	def getRootVisual(c):
		return c._rootVisual
	#end

	def addAtom (c, a):
		c._atoms.put (null,a.getId(), a);
		c._atomNames.put (null,a.getName(), a);

		if (a.getId() > c._maxAtomId):
			c._maxAtomId = a.getId();
		#end

	def getAtom (c, id):
		if (not c._atoms.containsKey(id)):
			return()

		return c._atoms.get(id);
	#end

	def findAtom (c, name):
		if (not c._atomNames.containsKey(name)):
			return()

		return c._atomNames.get(name);
	#end

	def atomExists (c, id):
		return c._atoms.containsKey(id);
	#end

	def nextFreeAtomId(c):
		c._maxAtomId+=1
		return c._maxAtomId;
	#end

	def getSelection (c, id):
		if (not c._selections.containsKey(id))	:
			return 

		return c._selections.get(id);
	#end

	def addSelection (c, sel):
		c._selections.put (sel.getId(), sel);
	#end

	def addResource (c,ri,r):
		c._resources.put (null,ri, r);
	#end

	def getResource (c, id, server=null):
		if (not c.resourceExists(id)):
			return()

		return c._resources.get(id)[2];
	#end

	def resourceExists (c, id):
		return c._resources.containsKey(id);
	#end

	def freeResource (c, id):
		c._resources.remove(id);
	#end

	def destroyClientResources (c, client):
		rc = c._resources.values();
		dl = Vector();

		if (client == null):
			for r in rc: 
				c = Client(r.getClient());
				disconnected = boolean((c == null or not c.isConnected()));

				if (disconnected and r.getCloseDownMode() == Client.RetainTemporary):
					dl.add(r)
			#end
		else: 
			for r in rc:
				if (r.getClient() == client):
					dl.add(r);
		#end

		for r in dl:
			r.delete();
	#end

	def sendMappingNotify (c, request, firstKeycode, keycodeCount):
		for client in c._clients: 
			try: 
				client.sendMappingNotify (c, request, firstKeycode, keycodeCount);
			except(Exception): 
				pass##end
		#end
	#end

	def processQueryExtensionRequest (c, client, bytesRemaining):# throws IOException:
		io = client.getInputOutput();

		if (bytesRemaining < 4):
			io.readSkip(bytesRemaining);
			Err_write (client, ErrorCode.Length, RequestCode.QueryExtension, 0);
			return;
		#end

		length = io.readShort();
		pad = int(-length & 3);

		io.readSkip(2);	
		bytesRemaining -= 4;

		if (bytesRemaining != length + pad):
			io.readSkip(bytesRemaining);
			Err_write (client, ErrorCode.Length, RequestCode.QueryExtension, 0);
			return;
		#end

		bytes = [signed()]*length;

		io.readBytes(bytes, 0, length);
		io.readSkip(pad);	

		s = String(bytes)
		e=c.Extension(null,0,0,0)

		if (c._extensions.containsKey(s)):
			e = c._extensions.get(s);
		else:
			e = null;

		#synchronized(io) {
		writeReplyHeader (client, 0);
		io.writeInt(0);	

		if (e == null):
			io.writeByte(0);	
			io.writeByte(0);	
			io.writeByte(0);	
			io.writeByte(0);	
		else: 
			io.writeByte(1);	
			io.writeByte(e.majorOpcode);	
			io.writeByte(e.firstEvent);	
			io.writeByte(e.firstError);	
		#end
		io.writePadBytes(20);	
		##end
		io.flush();
	#end

	def writeListExtensions (c, client):# throws IOException:
		ss = c._extensions.keySet();
		length = int(0);

		for s in ss:
			length += s.length() + 1;
		#endif
		pad = int(-length & 3);
		io = client.getInputOutput();

		#synchronized(io) {
		writeReplyHeader (client,  ss.size());
		io.writeInt ((length + pad) / 4);	
		io.writePadBytes(24);	

		for s in ss: 
			ba = s.getBytes();
			io.writeByte ( ba.length);
			io.writeBytes (ba, 0, ba.length);
		#end
		io.writePadBytes(pad);	
		##end
		io.flush();
	#end

	def processChangeHostsRequest (c, client, mode, bytesRemaining):# throws IOException:
		io = client.getInputOutput();

		if (bytesRemaining < 4):
			io.readSkip(bytesRemaining);
			Err_write (client, ErrorCode.Length, RequestCode.ChangeHosts, 0);
			return;
		#end

		family = io.readByte();	

		io.readSkip(1);	

		length = io.readShort();	
		pad = int(-length & 3);

		bytesRemaining -= 4;
		if (bytesRemaining != length + pad):
			io.readSkip(bytesRemaining);
			Err_write (client, ErrorCode.Length, RequestCode.ChangeHosts, 0);
			return;
		#end

		if (family != 0 or length != 4):
			io.readSkip(bytesRemaining);
			Err_write (client, ErrorCode.Value, RequestCode.ChangeHosts, 0);
			return;
		#end

		address = int(0);

		i = 0;
		while ( i < length ):
			address = (address << 8) | io.readByte();
			i+=1

		io.readSkip(pad);	

		if (mode == 0):
			c._accessControlHosts.add(address);
		else:
			c._accessControlHosts.remove(address);
	#end

	def writeListHosts (c, client):# throws IOException:
		io = client.getInputOutput();
		n = int(c._accessControlHosts.size());

		#synchronized(io){ 
		writeReplyHeader (client, signed(1) if(c._accessControlEnabled) else signed(0));
		io.writeInt (n * 2);	
		io.writeShort ( n);	
		io.writePadBytes(22);	

		for addr in c._accessControlHosts: 
			io.writeByte ( 0);	
			io.writePadBytes (1);	
			io.writeShort ( 4);	
			io.writeByte ( ((addr >> 24) & 0xff));
			io.writeByte ( ((addr >> 16) & 0xff));
			io.writeByte ( ((addr >> 8) & 0xff));
			io.writeByte ( (addr & 0xff));
		#end
		##end
		io.flush();
	#end

	def setAccessControl (c, enabled):
		c._accessControlEnabled = enabled;
	#end

	def getAccessControlHosts(c):
		return c._accessControlHosts
	#end

	def isAccessAllowed (c, address):
		if (not c._accessControlEnabled):
			return(true)

		return c._accessControlHosts.contains(address);
	#end

	def setScreenSaver (c, timeout, interval, preferBlanking, allowExposures):
		if (timeout == -1):
			c._screenSaverTimeout = 0;	
		else:
			c._screenSaverTimeout = timeout;

		if (interval == -1):
			c._screenSaverInterval = 0;	
		else:
			c._screenSaverInterval = interval;

		c._preferBlanking = preferBlanking;
		c._allowExposures = allowExposures;

		resetScreenSaver();
	#end

	def checkScreenBlank(c):
		if (c._screenSaverTimeout == 0):
			return;

		offset = long(c._screenSaverTime + c._screenSaverTimeout) * 1000 - time.time() / 1000;
		if (offset < 1000):
			c._screen.blank(true);
			return;
		#end

	#end

	def resetScreenSaver(c):
		now = long(time.time() / 1000);

		if (now == c._screenSaverTime):
			return;

		c._screenSaverTime = now;
	#end

	def writeScreenSaver (c, client):# throws IOException:
		io = client.getInputOutput();

		#synchronized(io) {
		writeReplyHeader (client,  0);
		io.writeInt(0);	
		io.writeShort ( c._screenSaverTimeout);	
		io.writeShort ( c._screenSaverInterval);	
		io.writeByte ( c._preferBlanking);	
		io.writeByte ( c._allowExposures);	
		io.writePadBytes(18);	
		##end
		io.flush();
	#end

	class Extension: 
		_majorOpcode=signed()
		_firstEvent=signed()
		_firstError=signed()

		def __init__ (c, pmajorOpcode=null, pfirstEvent=null, pfirstError=null):
			c._majorOpcode = pmajorOpcode if(pmajorOpcode!=null) else c._pmajorOpcode;
			c._firstEvent = pfirstEvent if(pfirstEvent!=null) else c.pfirstEvent;
			c._firstError = pfirstError if(pfirstError!=null) else c.pfirstError;
		#end
	#end

	
	def runClient(c,client,socket=None,clientIdBase=None,clientIdStep=None,inputOutput=None,unGrab=True):
	  if(not clientIdBase):
	    idBase=c._clientIdBase if(not client) else client._resourceIdBase; 
	  else:
	    idBase=clientIdBase
	  #endif
	  if(not clientIdStep):
	    idStep=c._clientIdStep-1 if(not client) else client._resourceIdMask;
	  else:
	    idStep=clientIdStep
	  #endif
	  if(not client):
	    client = Client (c, socket, idBase, idStep);
	    if(not clientIdBase and idBase==c._clientIdBase):
	      c._clientIdBase+=idBase;
	  #endif
	  if(not inputOutput and socket):
	    client._inputOutput=InputOutput(socket)
	  #endif
	  c._clients.add(client);
	  if(unGrab):
	    c._imperviousToServerGrabs.append(client)
	  client._xServer=c
	  if(not client._isConnected):
	    client.doInit()
	  if(client._isConnected):
	    client.doHello()
	  client.doComms();
