
 

from XUtil import *
from XIo import InputOutput



class Atom(Hashtable): 
	_predefinedAtoms = [
		"PRIMARY",
		"SECONDARY",
		"ARC",
		"ATOM",
		"BITMAP",
		"CARDINAL",
		"COLORMAP",
		"CURSOR",
		"CUT_BUFFER0",
		"CUT_BUFFER1",
		"CUT_BUFFER2",
		"CUT_BUFFER3",
		"CUT_BUFFER4",
		"CUT_BUFFER5",
		"CUT_BUFFER6",
		"CUT_BUFFER7",
		"DRAWABLE",
		"FONT",
		"INTEGER",
		"PIXMAP",
		"POINT",
		"RECTANGLE",
		"RESOURCE_MANAGER",
		"RGB_COLOR_MAP",
		"RGB_BEST_MAP",
		"RGB_BLUE_MAP",
		"RGB_DEFAULT_MAP",
		"RGB_GRAY_MAP",
		"RGB_GREEN_MAP",
		"RGB_RED_MAP",
		"STRING",
		"VISUALID",
		"WINDOW",
		"WM_COMMAND",
		"WM_HINTS",
		"WM_CLIENT_MACHINE",
		"WM_ICON_NAME",
		"WM_ICON_SIZE",
		"WM_NAME",
		"WM_NORMAL_HINTS",
		"WM_SIZE_HINTS",
		"WM_ZOOM_HINTS",
		"MIN_SPACE",
		"NORM_SPACE",
		"MAX_SPACE",
		"END_SPACE",
		"SUPERSCRIPT_X",
		"SUPERSCRIPT_Y",
		"SUBSCRIPT_X",
		"SUBSCRIPT_Y",
		"UNDERLINE_POSITION",
		"UNDERLINE_THICKNESS",
		"STRIKEOUT_ASCENT",
		"STRIKEOUT_DESCENT",
		"ITALIC_ANGLE",
		"X_HEIGHT",
		"QUAD_WIDTH",
		"WEIGHT",
		"POINT_SIZE",
		"RESOLUTION",
		"COPYRIGHT",
		"NOTICE",
		"FONT_NAME",
		"FAMILY_NAME",
		"FULL_NAME",
		"CAP_HEIGHT",
		"WM_CLASS",
		"WM_TRANSIENT_FOR"
	];

	_id= int()
	_name=null

	def __init__(self, id, name): 
		self._id = id;
		self._name = name;

	 
	def registerPredefinedAtoms (self, xServer): 
		i = 0;
		while( i < len(self._predefinedAtoms) ): 
			xServer.addAtom (Atom (i + 1, self._predefinedAtoms[i]));
			i+=1
		#endfor	

	
	def numPredefinedAtoms (self): 
		return( len(self._predefinedAtoms));
	

	 
	def getId (self): 
		return( self._id);
	

	def getName (self):
		return( self._name);
	

	def processGetAtomNameRequest (self, xServer, client, bytesRemaining):# throws IOException {
		io = client.getInputOutput ();

		if (bytesRemaining != 4): 
			io.readSkip (bytesRemaining);
			Err_write (client, ErrorCode.Length, RequestCode.GetAtomName, 0);
			return()
		#endif

		id = int(io.readInt ());
		a = xServer.getAtom (id);

		if (a == null): 
			Err_write (client, ErrorCode.Atom, RequestCode.GetAtomName, id);
			return()
		#endif

		bytes = a._name.getBytes ();
		length = int(len(bytes));
		pad = int(-length & 3);

		#synchronized (io) {
		Util.writeReplyHeader (client, signed( 0));
		io.writeInt ((length + pad) / 4);	
		io.writeShort (short( length));	
		io.writePadBytes (22);	
		io.writeBytes (bytes, 0, length);	
		io.writePadBytes (pad);	
		#}
		io.flush ();
	



	def processInternAtomRequest (self, xServer, client, arg, bytesRemaining):#1 throws IOException {
		io = client.getInputOutput ();

		if (bytesRemaining < 4): 
			io.readSkip (bytesRemaining);
			Err_write (client, ErrorCode.Length, RequestCode.InternAtom, 0);
			return()
		#endif

		onlyIfExists = boolean((arg != 0));
		n = io.readShort ();	
		pad = int(-n & 3);

		io.readSkip (2);	
		bytesRemaining -= 4;

		if (bytesRemaining != n + pad): 
			io.readSkip (bytesRemaining);
			Err_write (client, ErrorCode.Length, RequestCode.InternAtom, 0);
			return()
		#endif

		name = [signed()]*n;

		io.readBytes (name, 0, n);	
		io.readSkip (pad);	

		id = int(0);
		a = Atom(xServer.findAtom (name));

		if (a != null): 
			id = a.getId ();
		elif (not onlyIfExists): 
			a = Atom (xServer.nextFreeAtomId (), s);
			xServer.addAtom (a);
			id = a.getId ();
		#ehdif

		#synchronized (io) {
		Util.writeReplyHeader (client, signed( 0));
		io.writeInt (id);	
		io.writePadBytes (20);	
		#}
		io.flush ();

