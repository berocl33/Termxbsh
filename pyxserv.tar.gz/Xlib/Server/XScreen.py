
# It also implements the screen's root window.
from XWin import Window
from XUser import Client
from XIo import InputOutput
from XUtil import * 

class Screen():
	_rootId=null;
	_rootWindow = null;
	_defaultColormap = null;
	_installedColormaps = null#Vector(Colormap)
	_pixelsPerMillimeter = float()
	_currentCursor = Cursor()
	_currentCursorX = int()
	_currentCursorY = int()
	_drawnCursor  = Cursor()
	_drawnCursorX = int()
	_drawnCursorY = int()
	_motionWindow  = null;
	
	_motionX = int()
	_motionY = int()
	_buttons = int(0)
	_isBlanked = boolean(false)
	_paint = Paint()

	_formats=[(1,2,3)]
	_grabPointerClient = null
	_grabPointerWindow  = null
	_grabPointerTime =  int(0)
	_currentPointerVecs = int(0)
	_grabPointerOwnerEvents = boolean(false)
	_grabPointerSynchronous = boolean(false)
	_grabPointerPassive = boolean(false)
	_grabPointerAutomatic = boolean(false)
	_grabKeyboardClient = null 
	_grabKeyboardWindow = null 
	_grabKeyboardTime =  int(0)
	_grabKeyboardOwnerEvents =  boolean(false)
	_grabKeyboardSynchronous =  boolean(false)
	
	_grabCursor = null
	_grabConfineWindow  = null
	_grabEventMask = int(0)
	_grabKeyboardPassiveGrab  = PassiveKeyGrab(null)
	_focusWindow =  null
	_focusRevertTo = signed(0);	# 0=None, 1=Root, 2=Parent.
	_focusLastChangeTime  = int(0)

	def __init__(self, xServer, rootId, pixelsPerMillimeter=null):
		#super (c);
		#setFocusable (true);
		#setFocusableInTouchMode (true);
		self._xServer = xServer
		self._rootId = rootId or 0x3;
		self._defaultColormap = Colormap(4);
		#self.syncResource(self._defaultColormap);
		self._rootWindow = Window(self._rootId,self._xServer,null,self,null,0,0,640,480,0,true,true);
		self._motionWindow = self._rootWindow;
		self._xServer.addResource(self._rootId,self._rootWindow);
		self._installedColormaps = Vector();
		self._pixelsPerMillimeter = pixelsPerMillimeter;
		self._paint = Paint ();


	def newScreen(self,xServer=null,rootId=null,installedColormaps=null,pixelsPerMillimeter=null): 
		#super (c);
		if(xServer):
		    self._xServer = xServer;
		if(rootId):
		    self._rootId = rootId 
		if(installedColormaps):
		    self._installedColormaps = Vector();#installedColormaps if isinstance(installedColormaps,(list,tuple))
		if(pixelsPerMillimeter):
		    self._pixelsPerMillimeter = pixelsPerMillimeter;
		
	def getRootWindow (self):
		return( self._rootWindow);

	def getDefaultColormap (self): 
		return( self._defaultColormap);

	def getCurrentCursor (self):
		return( self._currentCursor);

	def getPointerX (self):
		return( self._currentCursorX);
	
	def getPointerY (self): 
		return( self._currentCursorY);

	def getButtons (self):
		return( self._buttons);

	def getFocusWindow (self): 
		return( self._focusWindow);

	def blank (self,flag): 
		if (self._isBlanked == flag):
			return()
		#endif
		self._isBlanked = flag;
		#postInvalidate ();

		if (not self._isBlanked): 
			self._xServer.resetScreenSaver ();
		#emdif
	def addInstalledColormap(self, cmap):
		self._installedColormaps.add (cmap);
		if (self._defaultColormap == null):
			self._defaultColormap = cmap;
		#endif 

	def removeInstalledColormap (self,cmap):
		self._installedColormaps.remove (cmap);
		if (self._defaultColormap == cmap): 
			if (self._installedColormaps.size () == 0): 
				self._defaultColormap = null;
			else:
				self._defaultColormap = self._installedColormaps[0];#.firstElement ();
			#endif
		#endif1

	def removeNonDefaultColormaps (self):
		if (self._installedColormaps.size () < 2):
			return()
		#endif
		self._installedColormaps.clear ();
		if (self._defaultColormap != null):
			self._installedColormaps.add (self._defaultColormap);
		#endif	

	def deleteWindow (self, w):
		if (self._grabPointerWindow == w or self._grabConfineWindow == w): 
			self._grabPointerClient = null;
			self._grabPointerWindow = null;
			self._grabCursor = null;
			self._grabConfineWindow = null;
			self.updatePointer (2);
		else: 
			self.updatePointer (0);
		#endif1

		self.revertFocus(w);

	def revertFocus (self,w):
		if (w == self._grabKeyboardWindow): 
			pw = self._rootWindow.windowAtPoint (self._motionX, self._motionY);

			self.focusInOutNotify (self._grabKeyboardWindow, self._focusWindow, pw, self._rootWindow, 2);
			self._grabKeyboardClient = null;
			self._grabKeyboardWindow = null;
		#endif1

		if (w == self._focusWindow): 
			pw = self._rootWindow.windowAtPoint (self._motionX, self._motionY);
			if (self._focusRevertTo == 0): 
				self._focusWindow = null;
			elif (self._focusRevertTo == 1): 
				self._focusWindow = self._rootWindow;
			else: 
				self._focusWindow = w.getParent ();
				while (not self._focusWindow.isViewable ()):
					self._focusWindow = self._focusWindow.getParent ();
				#endwhile
			#3ndiF

			self._focusRevertTo = 0;
			self.focusInOutNotify (self._focusWindow, pw, self._rootWindow, 0 if(self._grabKeyboardWindow == null) else 3);
		#wndiF
	
	def getWidth(self):
	 return( 640); 

	def getHeight(self):
	 return( 480); 

	def onDraw (self, canvas):
		if (self._rootWindow == null): 
			#super.onDraw (canvas);
			return()
		#endiF

		#synchronized (self._xServer) {
		if (self._isBlanked): 
				canvas.drawColor (0xff000000);
				return()
		#endiF
	
		self._paint.reset ();
		self._rootWindow.draw (canvas, self._paint);
		canvas.drawBitmap (self._currentCursor.getBitmap (),
				self._currentCursorX - self._currentCursor.getHotspotX (),
				self._currentCursorY - self._currentCursor.getHotspotY (), null);

		self._drawnCursor = self._currentCursor;
		self._drawnCursorX = self._currentCursorX;
		self._drawnCursorY = self._currentCursorY;
		#}

	#def nScrollChanged(int width,int height,int owidth,int oheight){}
	#@Override
	#protected void
	#onConfigurationChanged(Configuration res){ }
	#@Override
	#protected void
	#onScreenStateChanged(int ss){}
	#@Override
	def onSizeChanged (self, width, height, oldWidth, oldHeight): 
		#super.onSizeChanged (width, height, oldWidth, oldHeight);
		if (self._rootWindow==null):
			self._rootWindow = Window (self._rootId, self._xServer, null, self, null, 0, 0, width, height, 0, false, true);
			self._xServer.addResource (self._rootId,self._rootWindow);
		#endif
		self._currentCursor = self._rootWindow.getCursor ();
		self._currentCursorX = width / 2;
		self._currentCursorY = height / 2;
		self._drawnCursorX = self._currentCursorX;
		self._drawnCursorY = self._currentCursorY;
		self._motionX = self._currentCursorX;
		self._motionY = self._currentCursorY;
		self._motionWindow = self._rootWindow;
		self._focusWindow = self._rootWindow;

	def movePointer (self,xServer,x,y,cursor):
		if (self._drawnCursor != null):# 
			left = self._drawnCursorX - self._drawnCursor.getHotspotX ();
			top = self._drawnCursorY - self._drawnCursor.getHotspotY ();
			bm = self._drawnCursor.getBitmap ();

			#postInvalidate (left, top, left + bm.getWidth (), top + bm.getHeight ());
			self._drawnCursor = null;
		#endif

		self._currentCursor = cursor;
		self._currentCursorX = x;
		self._currentCursorY = y;

		left = x - cursor.getHotspotX ();
		top = y - cursor.getHotspotY ();
		bm = cursor.getBitmap ();

		#postInvalidate (left, top, left + bm.getWidth (), top + bm.getHeight ());
	 
	def updatePointerPosition (self, x, y, mode):
		if (self._grabConfineWindow != null): 
			rect = self._grabConfineWindow.getIRect ();

			if (x < rect.left):
				x = rect.left;
			elif (x >= rect.right):
				x = rect.right - 1;
			#endif2
			if (y < rect.top):
				y = rect.top;
			elif (y >= rect.bottom):
				y = rect.bottom - 1;
			#endif2
		#endif1

		if (self._grabPointerWindow != null):
			w = self._grabPointerWindow;
		else:
			w = self._rootWindow.windowAtPoint (x, y);
		#endif1
		if (self._grabCursor != null):
			c = self._grabCursor;
		else:
			c = w.getCursor ();
		#endif1
		if (c != self._currentCursor or x != self._currentCursorX or y != self._currentCursorY):
			self.movePointer (x, y, c);
		#endif
		if (w != self._motionWindow): 
			self._motionWindow.leaveEnterNotify (x, y, w, mode);
			self._motionWindow = w;
			self._motionX = x;
			self._motionY = y;

		elif (x != self._motionX or y != self._motionY): 
			if (self._grabPointerWindow == null):
				w.motionNotify (x, y, self._buttons & 0xff00, null);
			elif (not self._grabPointerSynchronous): 
				w.grabMotionNotify (x, y, self._buttons & 0xff00, self._grabEventMask, self._grabPointerClient, self._grabPointerOwnerEvents);
			#endif2 #Else need to queue the events for later.

			self._motionX = x;
			self._motionY = y;
		#endif1
	

	#
	#Param mode	0=Normal, 1=Grab, 2=Ungrab
	def updatePointer (self, mode):
		self.updatePointerPosition (self._currentCursorX, self._currentCursorY, mode);
	

	def updatePointerButtons (self,button,pressed):
		p = self._xServer.getPointer ();

		button = p.mapButton (button);
		if (button == 0):
			return()
		#endif1
		mask = 0x80 << button;

		if (pressed): 
			if ((self._buttons & mask) != 0):
				return()
			#endif2
			self._buttons |= mask;
		else: 
			if ((self._buttons & mask) == 0):
				return()
			#endif2
			self._buttons &= ~mask;
		#endif1

		if (self._grabPointerWindow == null): 
			w = self._rootWindow.windowAtPoint (self._motionX, self._motionY);
			pbg = PassiveButtonGrab(null);

			if (pressed):
				pbg = w.findPassiveButtonGrab (self._buttons, null);
			#endif2
			if (pressed and pbg != null): 
				self._grabPointerClient = pbg.getGrabClient ();
				self._grabPointerWindow = pbg.getGrabWindow ();
				self._grabPointerPassive = true;
				self._grabPointerAutomatic = false;
				self._grabPointerTime = self._xServer.getTimestamp ();
				self._grabConfineWindow = pbg.getConfineWindow ();
				self._grabEventMask = pbg.getEventMask ();
				self._grabPointerOwnerEvents = pbg.getOwnerEvents ();
				self._grabPointerSynchronous = pbg.getPointerSynchronous ();
				self._grabKeyboardSynchronous = pbg.getKeyboardSynchronous ();

				self._grabCursor = pbg.getCursor ();
				if (self._grabCursor == null):
					self._grabCursor = self._grabPointerWindow.getCursor ();
				# endif4
				self.updatePointer (1);
			else: 
				ew = w.buttonNotify (pressed, self._motionX, self._motionY,
																button, null);
				c = Client(null);

				if (pressed and ew != null): 
					#sc=Vector(Client);

					sc = ew.getSelectingClients(EventCode.MaskButtonPress);
					if (sc != null):
						c = sc.firstElement ();
				#endif4

				# Start an automatic key grab.
				if (c != null): 
					em = ew.getClientEventMask (c);
	
					self._grabPointerClient = c;
					self._grabPointerWindow = ew;
					self._grabPointerPassive = false;
					self._grabPointerAutomatic = true;
					self._grabPointerTime = self._xServer.getTimestamp ();
					self._grabCursor = ew.getCursor ();
					self._grabConfineWindow = null;
					self._grabEventMask = em & EventCode.MaskAllPointer;
					self._grabPointerOwnerEvents = (em & EventCode.MaskOwnerGrabButton) != 0;
					self._grabPointerSynchronous = false;
					self._grabKeyboardSynchronous = false;
					self.updatePointer (1);
				#endif3
			#endif2
		else:  
			if (not self._grabPointerSynchronous): 
				self._grabPointerWindow.grabButtonNotify (pressed, self._motionX, self._motionY, button, self._grabEventMask, self._grabPointerClient, self._grabPointerOwnerEvents);
			#endif2	# Else need to queue the events for later.

			if (self._grabPointerAutomatic and not pressed and (self._buttons & 0xff00) == 0): 
				self._grabPointerClient = null;
				self._grabPointerWindow = null;
				self._grabCursor = null;
				self._grabConfineWindow = null;
				self.updatePointer (2);
			#endif
		#endif1
	

	def updateModifiers (self,pressed,state):
		mask = int(0);

		if ((state & KeyEvent.META_SHIFT_ON) != 0):
			mask |= 1;	# Shift.
		#endif1
		if ((state & KeyEvent.META_ALT_ON) != 0):
			mask |= 8;	# Mod1.
		#endif1
		self._buttons = (self._buttons & 0xff00) | mask;
	

	def notifyKeyPressedReleased (self,keycode,pressed):
		if (self._grabKeyboardWindow == null and self._focusWindow == null):
			return()
		#endif1
		kb = self._xServer.getKeyboard ();

		keycode = kb.translateToXKeycode (keycode);

		if (pressed and self._grabKeyboardWindow == null): 
			pkg = self._focusWindow.findPassiveKeyGrab (keycode, self._buttons & 0xff, null);

			if (pkg == null): 
				w = self._rootWindow.windowAtPoint (self._motionX, self._motionY);

				if (w.isAncestor (self._focusWindow)):
					pkg = w.findPassiveKeyGrab (keycode, self._buttons & 0xff, null);
				#endif3
			#endif2

			if (pkg != null): 
				self._grabKeyboardPassiveGrab = pkg;
				self._grabKeyboardClient = pkg.getGrabClient ();
				self._grabKeyboardWindow = pkg.getGrabWindow ();
				self._grabKeyboardTime = self._xServer.getTimestamp ();
				self._grabKeyboardOwnerEvents = pkg.getOwnerEvents ();
				self._grabPointerSynchronous = pkg.getPointerSynchronous ();
				self._grabKeyboardSynchronous = pkg.getKeyboardSynchronous ();
			#endif2
		#endif1

		if (self._grabKeyboardWindow == null): 
			w = self._rootWindow.windowAtPoint (self._motionX, self._motionY);

			if (w.isAncestor (self._focusWindow)):
				w.keyNotify (pressed, self._motionX, self._motionY, keycode, null);
			else:
				self._focusWindow.keyNotify (pressed, self._motionX, self._motionY, keycode, null);
			#endif2
		elif (not self._grabKeyboardSynchronous): 
			self._grabKeyboardWindow.grabKeyNotify (pressed, self._motionX, self._motionY, keycode, self._grabKeyboardClient, self._grabKeyboardOwnerEvents);
		#endif1	# Else need to queue keyboard events.

		kb.updateKeymap (keycode, pressed);

		if (not pressed and  self._grabKeyboardPassiveGrab != null): 
			rk = self._grabKeyboardPassiveGrab.getKey ();

			if (rk == 0 or rk == keycode): 
				self._grabKeyboardPassiveGrab = null;
				self._grabKeyboardClient = null;
				self._grabKeyboardWindow = null;
			#endif2
		#endif1

	def onTouchEvent(self, event): 
		#synchronized (self._xServer) {
		if (self._rootWindow == null):
			return( false);
		self.blank (false);	# Reset the screen saver.
		#epoints=event.getPointerCount();
		#etime=long(event.getEventTime());
		return( true);
    
	 
	def onKeyUp (self,keycode,event):
		#synchronized (self._xServer) {
		if (self._rootWindow == null):
			return( false);

		blank (false);	# Reset the screen saver.

		sendEvent = false;

		if (keyevent in (KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_HOME)):
			return( true);
		elif(keycode in ( KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_SHIFT_RIGHT, KeyEvent.KEYCODE_ALT_LEFT, KeyEvent.KEYCODE_ALT_RIGHT)):
			updateModifiers (true, event.getMetaState ());
			sendEvent = true;
		else:
			sendEvent = true;
		#endif1

		if (sendEvent):
			self.NotifyKeyPressedReleased (keycode, true);
		#endif
		return( true);
	
	 
	def onKeyDown (self,keycode,event):
		#synchronized (self._xServer) {
		if (self._rootWindow == null):
			return( false);
		#endif
		blank (false);	# Reset the screen saver.

		sendEvent = false;

		if(keycode in ( KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_MENU)):
			return( false);
		elif(keycode in ( KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_VOLUME_UP)):
			updatePointerButtons (1, false);

		elif(keycode in ( KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_SHIFT_RIGHT, KeyEvent.KEYCODE_ALT_LEFT, KeyEvent.KEYCODE_ALT_RIGHT)):
			updateModifiers (false, event.getMetaState ());
			sendEvent = true;
 
		else:
			sendEvent = true;
		#endif

		if (sendEvent):
			notifyKeyPressedReleased (keycode, false);

		#endiF

		return( true);
	
	def write (self,io):
		vis = self._xServer.getRootVisual ()# = Visual()

		io.writeInt (self._rootWindow.getId ());		# Root window ID.
		io.writeInt (self._defaultColormap.getId ());	# Default colormap ID.
		io.writeInt (self._defaultColormap.getWhitePixel ());	# White pixel.
		io.writeInt (self._defaultColormap.getBlackPixel ());	# Black pixel.

		io.writeInt (0);	# Current input masks.
		io.writeShort(int(self.getWidth()));	# Width in pixels.
		io.writeShort(int(self.getHeight()));	# Height in pixels.
		io.writeShort(int(self.getWidth ()
				/ self._pixelsPerMillimeter));	# Width in millimeters.
		io.writeShort(int(self.getHeight ()
				/ self._pixelsPerMillimeter));	# Height in millimeters.
		io.writeShort ( 1);	# Minimum installed maps.
		io.writeShort ( 1);	# Maximum installed maps.
		io.writeInt (vis.getId ());	# Root visual ID.

		io.writeByte (vis.getBackingStoreInfo ());
		io.writeByte ( 1 if(vis.getSaveUnder()) else 0);
		io.writeByte ( vis.getDepth ());	# Root depth.
		io.writeByte ( 1);	# Number of allowed depths.

		# Write the only allowed depth.
		io.writeByte ( vis.getDepth ());	# Depth.

		io.writeByte ( 0);	# Unused.

		io.writeShort ( 1);	# Number of visuals with this depth.
		io.writePadBytes(4);	# Unused.
		vis.write (io);		# The visual at this depth.
	

	def writeInstalledColormaps (self,client):
		io = InputOutput(client.getInputOutput ());
		n = int(self._installedColormaps.size ());

		#synchronized (io) {
		writeReplyHeader (client, signed( 0))
		io.writeInt (n);	# Reply length.
		io.writeShort ( n);	# Number of colormaps.
		io.writePadBytes(22);	# Unused.

		for  cmap in  self._installedColormaps: 
			io.writeInt (cmap.getId ());
		#endfor
		io.flush ();
	

	def processRequest (self, xServer, client, opcode, arg,bytesRemaining):
		io = InputOutput(client.getInputOutput ());

		if (opcode == RequestCode.SendEvent):
			if (bytesRemaining != 40): 
				io.readSkip (bytesRemaining);
				Err_write(client, ErrorCode.Length, opcode, 0);
			else: 
				self.processSendEventRequest (self._xServer, client, arg == 1);
				
			#endif
		elif(opcode == RequestCode.GrabPointer):
			if (bytesRemaining != 20): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				self.processGrabPointerRequest (self._xServer, client, arg == 1);
			#endif
		elif(opcode == RequestCode.UngrabPointer):
			if (bytesRemaining != 4): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				time = io.readInt ();	# Time.
				now = self._xServer.getTimestamp ();
				if (time == 0):
					time = now;

				if (time >= self._grabPointerTime and time <= now and self._grabPointerClient == client): 
					self._grabPointerClient = null;
					self._grabPointerWindow = null;
					self._grabCursor = null;
					self._grabConfineWindow = null;
					self.updatePointer (2);
				#endif31
			#endif2
		elif(opcode == RequestCode.GrabButton):
			if (bytesRemaining != 20): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				self.processGrabButtonRequest (self._xServer, client, arg == 1);
			#endif
		if(opcode == RequestCode.UngrabButton):
			if (bytesRemaining != 8): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				wid = io.readInt ();	# Grab window.
				modifiers = io.readShort ();	# Modifiers.
				r = self._xServer.getResource (wid);

				io.readSkip (2);	# Unused.

				if (r == null or r.getType () != Resource.WINDOW): 
					Err_write (client, ErrorCode.Window, opcode, wid);
				else: 
					w = Window( R);

					w.removePassiveButtonGrab (arg, modifiers);
				#endiF	
			#endiF
				
		elif(opcode == RequestCode.ChangeActivePointerGrab):
			if (bytesRemaining != 12): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				cid = io.readInt ();	# Cursor.
				time = io.readInt ();	# Time.
				mask = io.readShort ();	# Event mask.
			#endiF
			c = null

			io.readSkip (2);	# Unused.

			if (cid != 0): 
				r = self._xServer.getResource (cid);

				if (r == null or r.getType () != Resource.CURSOR):

					Err_write (client, ErrorCode.Cursor, opcode, 0);
				else:
					c = Cursor(r);
				#endif
			#endif
			now = self._xServer.getTimestamp ();

			if (time == 0):
				time = now;
			#endif

			if (self._grabPointerWindow != null and not self._grabPointerPassive and self._grabPointerClient == client and time >= self._grabPointerTime and time <= now and (cid == 0 or c != null)): 
				self._grabEventMask = mask;
				if (c != null):
					self._grabCursor = c;
				else:
					self._grabCursor = self._grabPointerWindow.getCursor ();
				#endif
			#endiF
		elif(opcode == RequestCode.GrabKeyboard):
			if (bytesRemaining != 12): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				self.processGrabKeyboardRequest (self._xServer, client, arg == 1);
			#endif
		elif(opcode == RequestCode.UngrabKeyboard):
			if (bytesRemaining != 4): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				time = io.readInt ();	# Time.
				now = self._xServer.getTimestamp ();

				if (time == 0):
					time = now;
				#endif
				if (time >= self._grabKeyboardTime and time <= now): 
					pw = self._rootWindow.windowAtPoint (self._motionX, self._motionY);

					self.focusInOutNotify (self._grabKeyboardWindow,
					self._focusWindow, pw, self._rootWindow, 2);
					self._grabKeyboardClient = null;
					self._grabKeyboardWindow = null;
				#ensif
				
			#endif 		
		elif(opcode == RequestCode.GrabKey):
			if (bytesRemaining != 12): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				self.processGrabKeyRequest (self._xServer, client, arg == 1);
			#endiF
			
		elif(opcode == RequestCode.UngrabKey):
			if (bytesRemaining != 8): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				wid = io.readInt ();	# Grab window.
				modifiers = io.readShort ();	# Modifiers.
				r = self._xServer.getResource (wid);

				io.readSkip (2);	# Unused.
				if (r == null or r.getType () != Resource.WINDOW): 
					Err_write (client, ErrorCode.Window, opcode, wid);
				else: 
					w = Window( r);

					w.removePassiveKeyGrab (arg, modifiers);
				#endif 
			#endiF
		elif(opcode == RequestCode.AllowEvents):
			if (bytesRemaining != 4): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				time = io.readInt ();	# Time.
				now = self._xServer.getTimestamp ();

				if (time == 0): 
					time = now;
				#endif
				if (time <= now and time >= self._grabPointerTime and time >= self._grabKeyboardTime): 
					pass
					# Release queued events.
				#endiF
			#endiF
		elif(opcode == RequestCode.SetInputFocus):
			if (bytesRemaining != 8): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				self.processSetInputFocusRequest (self._xServer, client, arg);
			#endif
		elif(opcode == RequestCode.GetInputFocus):
			if (bytesRemaining != 0): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				if (self._focusWindow == null):
					wid = int(0);
				elif (self._focusWindow == self._rootWindow):
					wid = int(1);
				else:
					wid = int(self._focusWindow.getId ());

				#Synchronized (io) {
				writeReplyHeader (client, self._focusRevertTo);
				io.writeInt (0);	# Reply length.
				io.writeInt (wid);	# Focus window.
				io.writePadBytes(20);	# Unused.
			#endif
			io.flush ();
		#endif	
		
	

	
	def processSendEventRequest (self,xServer, client,propagate):
		#) throws IOException {
		io = client.getInputOutput ();
		wid = io.readInt ();	# Destination window.
		mask = io.readInt ();	# Event mask.
		event = signed('0'*32);
		#w=Window();

		io.readBytes (event, 0, 32);	# Event.

		if (wid == 0): 		# Pointer window.
			w = self._rootWindow.windowAtPoint (self._motionX, self._motionY);
		elif (wid == 1): 	# Input focus.
			if (self._focusWindow == null): 
				Err_write (client, ErrorCode.Window, RequestCode.SendEvent, wid);
				return()
			#endif

			pw = self._rootWindow.windowAtPoint (self._motionX, self._motionY);

			if (pw.isAncestor (self._focusWindow)):
				w = pw;
			else:
				w = self._focusWindow;
			#endif
		else: 
			r = self._xServer.getResource (wid);

			if (r == null or r.getType () != Resource.WINDOW): 
				Err_write (client, ErrorCode.Window, RequestCode.SendEvent, wid);
				return()
			else:
				w = Window( r);
			#endif
		#endiF

		dc=Vector(Client);

		if (mask == 0): 
			dc.add (w.getClient ());
		elif (not propagate): 
			dc = w.getSelectingClients (mask);
		else: 
			while(1):
				dc = w.getSelectingClients(mask)
				if(dc != null):
					break;
				#endif
				mask &= ~w.getDoNotPropagateMask ();
				if (mask == 0):
					break;
				#endiF
				w = w.getParent ();
				if (w == null):
					break;
				#endif
				if (wid == 1 and w == self._focusWindow):
					break;
				#endif
			#endwhile
		#endif

		if (dc == null):
			return()
		#endif
		for c in dc: 
			dio = c.getInputOutput ();
	
			#synchronized (dio) {
			dio.writeByte(signed(event[0] | 128));
	
			if (event[0] == EventCode.KeymapNotify): 
					dio.writeBytes (event, 1, 31);
			else: 
					dio.writeByte (event[1]);
					dio.writeShort ( (c.getSequenceNumber() & 0xffff));
					dio.writeBytes (event, 4, 28);
			#endif2
			#}
			dio.flush ();
		#endfor1
	

	def processGrabPointerRequest (self, xServer, client, ownerEvents):# throws IOException {
		io = client.getInputOutput ();
		wid = io.readInt ();	# Grab window.
		mask = io.readShort ();	# Event mask.
		psync = (io.readByte () == 0);	# Pointer mode.
		ksync = (io.readByte () == 0);	# Keyboard mode.
		cwid = io.readInt ();	# Confine-to.
		cid = io.readInt ();	# Cursor.
		time = io.readInt ();	# Time.
		r = self._xServer.getResource (wid);

		if (r == null or r.getType () != Resource.WINDOW): 
			Err_write (client, ErrorCode.Window, RequestCode.GrabPointer, wid);
			return()
		#endif1

		w = Window( r);
		c = Cursor(null)
		cw = Window(null)

		if (cwid != 0): 
			r = self._xServer.getResource (cwid);

			if (r == null or r.getType () != Resource.WINDOW): 
				Err_write (client, ErrorCode.Window,
				RequestCode.GrabPointer, cwid);
				return()
			#endif2
			cw = Window( r);
		#endif1

		if (cid != 0): 
			r = self._xServer.getResource (cid);
			if (r != null and r.getType () != Resource.CURSOR): 
				Err_write (client, ErrorCode.Cursor,
				RequestCode.GrabPointer, cid);
				return()
			#endif2

			c = Cursor( r);
		#endif1

		if (c == null):
			c = w.getCursor ();
		#endif
		status = signed(0);	# Success.
		now = self._xServer.getTimestamp ();

		if (time == 0):
			time = now;
		#endif
		if (time < self._grabPointerTime or time > now): 
			status = 2;	# Invalid time.
		elif (self._grabPointerWindow != null
	and self._grabPointerClient != client): 
			status = 1;	# Already grabbed.
		else: 
			self._grabPointerClient = client;
			self._grabPointerWindow = w;
			self._grabPointerPassive = false;
			self._grabPointerAutomatic = false;
			self._grabPointerTime = time;
			self._grabCursor = c;
			self._grabConfineWindow = cw;
			self._grabEventMask = mask;
			self._grabPointerOwnerEvents = ownerEvents;
			self._grabPointerSynchronous = psync;
			self._grabKeyboardSynchronous = ksync;
		#endif2

		#synchronized (io) {
		writeReplyHeader (client, status);
		io.writeInt (0);	# Reply length.
		io.writePadBytes(24);	# Unused.
		#}
		io.flush ();

		if (status == 0):
			updatePointer (1);
		#endif	

	def processGrabButtonRequest (self, xServer, client, ownerEvents):# throws IOException {
		io = client.getInputOutput ();
		wid = io.readInt ();	# Grab window.
		mask = io.readShort ();	# Event mask.
		psync = (io.readByte () == 0);	# Pointer mode.
		ksync = (io.readByte () == 0);	# Keyboard mode.
		cwid = io.readInt ();	# Confine-to.
		cid = io.readInt ();	# Cursor.
		button = signed(io.readByte ());	# Button.
		modifiers=int();
		r = self._xServer.getResource (wid);

		io.readSkip (1);	# Unused.
		modifiers = io.readShort ();	# Modifiers.

		if (r == null or r.getType () != Resource.WINDOW): 
			Err_write (client, ErrorCode.Window,
			RequestCode.GrabPointer, wid);
			return()
		#endif1

		w = Window(r);
		c = Cursor(null)
		cw = Window(null);

		if (cwid != 0): 
			r = self._xServer.getResource (cwid);

			if (r == null or r.getType () != Resource.WINDOW): 
				Err_write (client, ErrorCode.Window,
				RequestCode.GrabPointer, cwid);
				return()
			#endif2
			cw = Window( r);
		#endif1

		if (cid != 0): 
			r = self._xServer.getResource (cid);

			if (r != null and r.getType () != Resource.CURSOR): 
				Err_write (client, ErrorCode.Cursor, RequestCode.GrabPointer, cid);
				return()
			#endif2
			c = Cursor( r);
		#endif1

		w.addPassiveButtonGrab (PassiveButtonGrab (client, w, button, modifiers, ownerEvents, mask, psync, ksync, cw, c));
	

	def processGrabKeyboardRequest (self, xServer, client, ownerEvents):# throws IOException {
		io = client.getInputOutput ();
		wid = io.readInt ();	# Grab window.
		time = io.readInt ();	# Time.
		psync = (io.readByte () == 0);	# Pointer mode.
		ksync = (io.readByte () == 0);	# Keyboard mode.
		r = self._xServer.getResource (wid);

		io.readSkip (2);	# Unused.

		if (r == null or r.getType () != Resource.WINDOW):
			Err_write (client, ErrorCode.Window,
			RequestCode.GrabKeyboard, wid);
			return()
		#endif1

		w = Window( r);
		status = signed(0);	# Success.
		now = self._xServer.getTimestamp ();

		if (time == 0):
			time = now;
		#endif
		if (time < self._grabKeyboardTime or time > now): 
			status = 2;	# Invalid time.
		elif (self._grabKeyboardWindow != null): 
			status = 1;	# Already grabbed.
		else:
			self._grabKeyboardClient = client;
			self._grabKeyboardWindow = w;
			self._grabKeyboardTime = time;
			self._grabKeyboardOwnerEvents = ownerEvents;
			self._grabPointerSynchronous = psync;
			self._grabKeyboardSynchronous = ksync;
		#endif1

		#synchronized (io) {
		writeReplyHeader (client, status);
		io.writeInt (0);	# Reply length.
		io.writePadBytes(24);	# Unused.
		#}
		io.flush ();

		if (status == 0):
			focusInOutNotify (self._focusWindow, w, self._rootWindow.windowAtPoint (self._motionX, self._motionY), self._rootWindow, 1);
	

	def processGrabKeyRequest (self, xServer, client, ownerEvents):# throws IOException {
		io = client.getInputOutput ();
		wid = io.readInt ();	# Grab window.
		modifiers = io.readShort ();	# Modifiers.
		keycode = io.readByte ();	# Key.
		psync = (io.readByte () == 0);	# Pointer mode.
		ksync = (io.readByte () == 0);	# Keyboard mode.
		r = self._xServer.getResource (wid);

		io.readSkip (3);	# Unused.

		if (r == null or r.getType () != Resource.WINDOW):
			Err_write (client, ErrorCode.Window, RequestCode.GrabPointer, wid);
			return()
		#endif1

		w = Window( r);

		w.addPassiveKeyGrab (PassiveKeyGrab (client, w, keycode, modifiers, ownerEvents, psync, ksync));
	

	def processSetInputFocusRequest (self, xServer, client, revertTo):# throws IOException {
		io = client.getInputOutput ();
		io.readInt ();	# Focus window.
		time = io.readInt ();	# Time.

		if (wid == 0):
			w = Window(null);
			revertTo = 0;
		elif (wid == 1):
			w = self._rootWindow;
			revertTo = 0;
		else: 
			r = xServer.getResource (wid);

			if (r == null or r.getType () != Resource.WINDOW):
				Err_write (client, ErrorCode.Window, RequestCode.GrabPointer, wid);
				return()
			#endif2

			w = Windows( r);
			#endif1

		now = xServer.getTimestamp ();

		if (time == 0):
			time = now;
		#endif

		if (time < self._focusLastChangeTime or time > now):
			return()
		#endiF
		focusInOutNotify (self._focusWindow, w, self._rootWindow.windowAtPoint (self._motionX, self._motionY), self._rootWindow,0 if(self._grabKeyboardWindow == null) else 3);

		self._focusWindow = w;
		self._focusRevertTo = revertTo;
		self._focusLastChangeTime = time;
	

