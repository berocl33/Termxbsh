
import socket
from XUtil import *


class InputOutput:
 PadBytes=bytes([0]*0x20);_os=0
 _buf=[];_len=0;_pktsize=65536;_pend=False
 _msb=False;_inStream=_outStream=None
 def __init__(self,inp=None,outp=None):
  if(not outp):
   outp=inp;
  self._inStream=inp;self._outStream=outp

 def new(self,inp,outp=None):
  if(not outp):
   outp=inp;
  self._inStream=inp;self._outStream=outp

 def write(self,*x):
  self._lalen=sum([len(self._buf[a]) for a in range(len(self._buf))])
  self._len+=sum([self._buf.append(bytes().join(a) if(isinstance(a,(list,tuple))) else bytes([a]) if(isinstance(a,(int,float))) else bytes(a)) or len(self._buf[-1]) for a in x])
  if(self._pend==False):
   self.flush()
  return(self._len-self._lalen)
 def _writeall(self,x):
  if(not hasattr(self._outStream,"write")):
   res=self._outStream.send(bytes().join(x) if(isinstance(x,(list,tuple))) else bytes(x))
  else:
   res=self._outStream.write(bytes.join(x) if(isinstance(x,(list,tuple))) else bytes(x))
  self._len-=res if(isinstance(res,int)) else len(x) if(not self._os) else self._os 
  return(res)
 def read(self,*x):
  if(not hasattr(self._inStream,"read")):
   return self._inStream.recv(x[0])
  return(self._inStream.read(*x))
 def setMSB(self,L):
  self._msb=L!=false;
 def getMSB(self):
  return(self._msb==true)
 def readBytes(self,ba,offset,length):
  if(not isinstance(offset,(int))):
   offset=0
  [ba.insert(offset+a,self.read(1)) for a in range(length)]

 def readByte(self,ba=1,offset=None,length=None,bits=True):
  if not length:
   length=1
   return [chr,ord][[False,True].index(bits)](self.read(1))

 def readBits(self,ba,offset,length=None): 
  if(not isinstance(offset,(int))):
   offset=0;
  for l in range(length):
   x=self.readByte(bits=True)
   for s in range(4):
    ba[s+offset]=1 if x&(1<<s)!=0 else 0;
  return ba;

 def readShort(self):
  n=self.readByte(bits=True)
  if(not self._msb):
   return(n|(self.readByte(bits=True)<<8))
  else:
   return((n<<8)|self.readByte(bits=True))

 def readInt(self):
  return(sum([n<<[24-8*a,8*a][[False,True].index(self.getMSB())] for a in range(4) for n in (self.readByte(bits=True),)]))
 def readLong(self):
  return(sum([n<<[56-8*a,8*a][[False,True].index(self.getMSB())] for a in range(8) for n in (self.readByte(bits=True),)]))
 def readSkip(self,length):
  self.read(length);

 def writeBytes(self,ba,offset,length):
  self.write(ba[offset:offset+length])
  return(length);
 def writeByte(self,b):
  self.write(b) 
 def writeShort(self,b):
  b=int(b)
  if(self.getMSB()):
   self.write((b&0xff00)>>8);
   self.write(b&0xff)
  else:
   self.write(b&0xff);
   self.write((b&0xff00)>>8);
 def writeInt(self,b):
  b=int(b)
  if(self.getMSB()): 
   self.write((b&0xff000000)>>24);
   self.write((b&0xff0000)>>16);
   self.write((b&0xff00)>>8);
   self.write(b&0xff);
  else:
   self.write(b&0xff);
   self.write((b&0xff00)>>8);
   self.write((b&0xff0000)>>16);
   self.write((b&0xff000000)>>24);
 def writeLong(self,b):
  if(self.getMSB()): 
   self.write((b&0xff000000000000)>>56);
   self.write((b&0xff0000000000)>>48);
   self.write((b&0xff00000000)>>32);
   self.write((b&0xff000000)>>24);
   self.write((b&0xff0000)>>16);
   self.write((b&0xff00)>>8);
   self.write(b&0xff);
  else:
   self.write(b&0xff);
   self.write((b&0xff00)>>8);
   self.write((b&0xff0000)>>16);
   self.write((b&0xff000000)>>24);
   self.write((b&0xff00000000)>>32);
   self.write((b&0xff0000000000)>>48);
   self.write((b&0xff000000000000)>>56);

 def writePadBytes(self,length,b=None):
  if(length>len(self.PadBytes)):
   l=int(length/len(self.PadBytes));
   while(l>0 and qlen(self.PadBytes)==self.writeBytes(self.PadBytes,0,len(self.PadBytes))):
    l-=1;
   #end
  #end
  if(length%len(self.PadBytes)>0):
   self.writeBytes(self.PadBytes,0,length%len(self.PadBytes))
  #endif

 def flush(self):
  self._writeall(bytes().join([bytes([int(b)]) if(isinstance(b,(int,float))) else bytes().join(b) if(isinstance(b,(list,tuple))) else bytes(b) for a in range(len(self._buf)) for b in (self._buf.pop(0),)]));
  if(hasattr(self._outStream,"flush")):
   self._outStream.flush()
