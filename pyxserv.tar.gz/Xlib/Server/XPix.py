
from XUtil import *
from XDraw import Drawable
from XIo import InputOutput

class Pixmap(Resource): 
	_drawable= null#Drawable()
	_screen= null#Screen()
	def __init__(self, id, xServer, client, screen, width, height, depth):
		#Resource.__init__(self, id, xServer, client);

		self._drawable = Drawable (width, height, depth, null, 0xff000000);
		self._screen = screen;
	

	def getScreen (self): 
		return( self._screen);
	
	def getDrawable (self): 
		return(self._drawable);
	

	def getDepth (self): 
		return(self._drawable.getDepth ());
	

	 
	def processRequest (self, client, opcode, arg, bytesRemaining):# throws IOException {
		io = client.getInputOutput ();

		if (opcode == RequestCode.FreePixmap):
			if (bytesRemaining != 0): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				self._xServer.freeResource (self._id);
				if (self._client != null):
					self._client.freeResource (this);
				#endif 
				self._drawable.getBitmap().recycle ();
			#endif
		elif(opcode ==  RequestCode.GetGeometry):
			if (bytesRemaining != 0): 
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				writeGeometry (client);
			#endif
		elif((opcode<=78 and opcode>=62) or opcode==RequestCode.QueryBestSize):# RequestCode.CopyArea || RequestCode.CopyPlane || RequestCode.PolyPoint || RequestCode.PolyLine || RequestCode.PolySegment || RequestCode.PolyRectangle || RequestCode.PolyArc || RequestCode.FillPoly || RequestCode.PolyFillRectangle || RequestCode.PolyFillArc || RequestCode.PutImage || RequestCode.GetImage || RequestCode.PolyText8 || RequestCode.PolyText16 || RequestCode.ImageText8 || RequestCode.ImageText16 ||
			self._drawable.processRequest (self._xServer, client, self._id, opcode, arg, bytesRemaining);
			return()
		else:
			io.readSkip (bytesRemaining);
			bytesRemaining = 0;
			Err_write (client, ErrorCode.Implementation, opcode, 0);
		#endiF


	def writeGeometry (self, client):# throws IOException {
		io = client.getInputOutput ();

		#synchronized (io) {
		Util.writeReplyHeader (client, signed( 32));
		io.writeInt (0);	
		io.writeInt (self._screen.getRootWindow().getId ());	
		io.writeShort (short( 0));	
		io.writeShort (short( 0));
		io.writeShort (short( self._drawable.getWidth ()));	
		io.writeShort (short( self._drawable.getHeight ()));	
		io.writeShort (short( 0));
		io.flush ();
		#}
	 

	def processCreatePixmapRequest (self, xServer, client, id, width, height, depth, drawable):# throws IOException {
		p=Pixmap()

		if (drawable.getType () == Resource.PIXMAP):
			screen = Pixmap( drawable).getScreen ();
		else:
			screen = Window( drawable).getScreen ();
		#endif
		try: 
			p = Pixmap (id, xServer, client, screen, width, height, depth);
		except (OutOfMemoryError ): 
			Err_write (client, ErrorCode.Alloc, RequestCode.CreatePixmap, 0);
			return()
		#yrt

		xServer.addResource (p);
		client.addResource (p);
		

