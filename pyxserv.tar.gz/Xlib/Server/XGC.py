#*
#* This class implements an X graphics context.
from XUtil import * 
from XIo import InputOutput
AttrFunction = 0;
AttrPlaneMask = 1;
AttrForeground = 2;
AttrBackground = 3;
AttrLineWidth = 4;
AttrLineStyle = 5;
AttrCapStyle = 6;
AttrJoinStyle = 7;
AttrFillStyle = 8;
AttrFillRule = 9;
AttrTile = 10;
AttrStipple = 11;
AttrTileStippleXOrigin = 12;
AttrTileStippleYOrigin = 13;
AttrFont = 14;
AttrSubwindowMode = 15;
AttrGraphicsExposures = 16;
AttrClipXOrigin = 17;
AttrClipYOrigin = 18;
AttrClipMask = 19;
AttrDashOffset = 20;
AttrDashes = 21;
AttrArcMode = 22;

class GContext(): 
	_paint = Paint();
	_font = Font( null);
	_fillType = null  
	_attributes=[];
	_clipRectangles = [];
	_foregroundColor = 0xff000000;
	_backgroundColor = 0x00fffff;

	def __init__ (self, id, xServer, client): 
		#super (GCONTEXT, id, xServer, client);

		self._paint = Paint ();
		self._attributes = [
			3,	
			0xffffffff,	
			0,	
			1,	
			0,	
			0,	
			1,	
			0,	
			0,	
			0,	
			0,	
			0,	
			0,	
			0,	
			0,	
			0,	
			1,	
			0,	
			0,	
			0,	
			0,	
			4,	
			1	
		];
	

	def getPaint (self):
		return( self._paint);
	
	def getBackgroundColor (self):
		return( self._backgroundColor);
	

	def getForegroundColor (self):
		return( self._foregroundColor);
	

	def getFillType (self):
		return( self._fillType);


	# 0 = chord, 1 = pie slice.
	def getArcMode (self):
		return( self._attributes[AttrArcMode]);
	

	def getGraphicsExposure (self):
		return( (self._attributes[AttrGraphicsExposures] != 0));
	

	def getFont (self):
		return( self._font);
	

	def setFont (self, id): 
		r = Resource(self._xServer.getResource (id));

		if (r == null or r.getType () != Resource.FONT):
			return( false);

		self._font = Font(r);
		self._paint.setTypeface (self._font.getTypeface ());
		self._paint.setTextSize (self._font.getSize ());

		return( true);
	

	def applyClipRectangles (self, canvas): 
		if (self._clipRectangles == null):
			return()
		#ensif
		if (self._clipRectangles.length == 0):
			canvas.clipRect (0, 0, 0, 0);
		else:
			for r in self._clipRectangles:
				canvas.clipRect (r, Region.Op.UNION);
			#endfor
		#endif

	def processRequest (self, client, opcode, arg, bytesRemaining):# throws IOException {
		io = InputOutput(client.getInputOutput ());

		if(opcode in ( RequestCode.QueryFont, RequestCode.QueryTextExtents)):
			self._font.processRequest (client, opcode, arg, bytesRemaining);
			return()
		elif(opcode == RequestCode.ChangeGC):
			processValues (client, opcode, bytesRemaining);
		elif(opcode == RequestCode.CopyGC):
			if (bytesRemaining != 8):
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				id = io.readInt ();	
				mask = io.readInt ();	
				r = Resource(self._xServer.getResource (id));

				if (r == null or r.getType () != Resource.GCONTEXT): 
					Err_write (client, ErrorCode.GContext, opcode, id);
				else: 
					gc = GContext( r);
					i = 0;
					while( i < 23 ):
						if ((mask & (1 << i)) != 0):
							gc.self._attributes[i] = self._attributes[i];
						#endif
						i+=1
					#endif
					gc.applyValues (null, opcode);
				#endif
			#endif
		elif(opcode == RequestCode.SetDashes):
			if (bytesRemaining < 4):
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				io.readShort ();	

				n = io.readShort ();	
				pad = int(-n & 3);

				bytesRemaining -= 4;
				if (bytesRemaining != n + pad):
					Err_write (client, ErrorCode.Length, opcode, 0);

				io.readSkip (n + pad);	
			#endif
		elif(opcode == RequestCode.SetClipRectangles):
			if (bytesRemaining < 4):
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				clipXOrigin = int(short( io.readShort ()));
				clipYOrigin = int(short( io.readShort ()));

				bytesRemaining -= 4;
				if ((bytesRemaining & 7) != 0):
					io.readSkip (bytesRemaining);
					Err_write (client, ErrorCode.Length, opcode, 0);
				else: 
					i = int(0);

					self._clipRectangles = []*(bytesRemaining / 8);
					while (bytesRemaining > 0):
						x = int(short( io.readShort ()));
						y = int(short( io.readShort ()));
						width = int(io.readShort ());
						height = int(io.readShort ());

						bytesRemaining -= 8;
						i+=1
						self._clipRectangles[i] = Rect (x + clipXOrigin, y + clipYOrigin, x + clipXOrigin + width, y + clipYOrigin + height);
					#endiC
				#3ndif
			#ensif
		elif(opcode == RequestCode.FreeGC):
			if (bytesRemaining != 0):
				io.readSkip (bytesRemaining);
				Err_write (client, ErrorCode.Length, opcode, 0);
			else: 
				self._xServer.freeResource (self._id);
				if (self._client != null):
					self._client.freeResource (this);
				#endif
			#endkC
		else:
			io.readSkip (bytesRemaining);
			Err_write (client, ErrorCode.Implementation, opcode, 0);
		#endif

	def processCreateGCRequest (self, xServer, client, id, bytesRemaining):# throws IOException {
		gc = GContext(id, xServer, client);

		if (gc.processValues (client, RequestCode.CreateGC, bytesRemaining)):
			xServer.addResource (gc);
			client.addResource (gc);
		#endif
	

	def processValues (self, client, opcode, bytesRemaining):# throws IOException {
		io = InputOutput(client.getInputOutput ());

		if (bytesRemaining < 4):
			io.readSkip (bytesRemaining);
			Err_write (client, ErrorCode.Length, opcode, 0);
			return( false);
		#endif

		valueMask = io.readInt ();	
		n = int(Util.bitcount (valueMask));

		bytesRemaining -= 4;
		if (bytesRemaining != n * 4):
			io.readSkip (bytesRemaining);
			Err_write (client, ErrorCode.Length, opcode, 0);
			return( false);
		#endkf

		i = 0;
		while( i < 23 ):
			if ((valueMask & (1 << i)) != 0):
				processValue (io, i);
			#endif
			i+=1
		#ensif

		return( applyValues (client, opcode));

	 
	def processValue ( io, maskBit):# throws IOException {
		if(maskBit in ( AttrFunction, AttrLineStyle, AttrCapStyle, AttrJoinStyle, AttrFillStyle, AttrFillRule, AttrSubwindowMode, AttrGraphicsExposures, AttrDashes, AttrArcMode)):
			self._attributes[maskBit] = io.readByte ();
			io.readSkip (3);
		elif(maskBit in (AttrPlaneMask, AttrForeground, AttrBackground, AttrTile, AttrStipple, AttrFont, AttrClipMask)):
			self._attributes[maskBit] = io.readInt ();
		elif(maskBit in (AttrLineWidth, AttrDashOffset)):
			self._attributes[maskBit] = io.readShort ();
			io.readSkip (2);
		elif(maskBit in (AttrTileStippleXOrigin, AttrTileStippleYOrigin, AttrClipXOrigin, attrClipYOrigin)):
			self._attributes[maskBit] = short( io.readShort ());
			io.readSkip (2);
		#endif
	


	def applyValues (self, client, opcode):# throws IOException {
		ok = boolean(true);

		self._foregroundColor = self._attributes[AttrForeground] | 0xff000000;
		self._backgroundColor = self._attributes[AttrBackground] | 0xff000000;

		self._paint.setColor (self._foregroundColor);
		self._paint.setStrokeWidth (self._attributes[AttrLineWidth]);

		if (self._attributes[AttrFunction] == 6):
			self._paint.setXfermode(); 
		else:
			self._paint.setXfermode (null);
		#endif
		fs=self._attributes[AttrCapStyle] 
		if(fs == 0 or fs == 1):
				self._paint.setStrokeCap (Paint.Cap.BUTT);
		elif(fs == 2):
				self._paint.setStrokeCap (Paint.Cap.ROUND);
		elif(fs == 3):
				self._paint.setStrokeCap (Paint.Cap.SQUARE);
		#endif
		bs= self._attributes[AttrJoinStyle]
		if(bs == 0):	
				self._paint.setStrokeJoin (Paint.Join.MITER);
		elif(bs == 1):	
				self._paint.setStrokeJoin (Paint.Join.ROUND);

		elif(bs == 2):	
				self._paint.setStrokeJoin (Paint.Join.BEVEL);
		#endif

		if (self._attributes[AttrFillRule] == 1):
			self._fillType =0 
		else:
			self._fillType =null 
		#endif
		fid = int(self._attributes[AttrFont]);

		if (self._font == null or fid == 0):
			self._font = self._xServer.getDefaultFont ();
		#end
		if (fid != 0 and not setFont (fid)):
			ok = false;
			Err_write (client, ErrorCode.Font, opcode, fid);
		#endif
	
		return( ok);
	#endif

